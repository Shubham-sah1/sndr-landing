// auth-redirect.js — content script injected on the SNDR OAuth success page.
//
// A page cannot open the extension or close its own tab (Chrome blocks
// window.close() for tabs it didn't script-open). This content script runs in
// the page and messages the background, which reliably opens the SNDR dashboard
// and closes this tab. Drives both the countdown and the "Return to SNDR" button.
(function () {
  if (!location.pathname.includes('/auth/callback')) return;

  var done = false;
  function returnToExtension() {
    if (done) return;
    done = true;
    try { chrome.runtime.sendMessage({ type: 'GMAIL_CONNECTED' }); } catch (e) {}
  }

  // Make the "Return to SNDR" button actually work (its inline window.close() is
  // blocked by Chrome for this tab).
  document.addEventListener('click', function (e) {
    var el = e.target && e.target.closest ? e.target.closest('button, .btn') : null;
    if (el) returnToExtension();
  }, true);

  // Auto-redirect when the on-page countdown finishes (~4s).
  setTimeout(returnToExtension, 4000);
})();
