(function(){
  var API = window.location.hostname === 'localhost' ? window.location.origin : 'https://api.sndr.co.in';

  async function initApi() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise(function(resolve) {
        chrome.storage.local.get(['custom_api_url'], async function(data) {
          // Retired Render host (saved by a pre-AWS build) — ignore it.
          if (data.custom_api_url && data.custom_api_url.indexOf('onrender.com') !== -1) {
            chrome.storage.local.remove('custom_api_url');
          } else if (data.custom_api_url) {
            API = data.custom_api_url;
            console.log('[SNDR] Bot using API URL:', API);
          } else if (window.location.hostname === 'localhost') {
            // Only probe a local backend during local dev. Normal installs run on a
            // chrome-extension:// page where this probe would just waste up to 800ms
            // failing on every load before the AI bot can be used.
            try {
              var localCheck = await fetch('http://localhost:3000/health', { signal: AbortSignal.timeout(800) });
              if (localCheck.ok) API = 'http://localhost:3000';
            } catch(e) {}
          }
          resolve();
        });
      });
    } else {
      if (window.location.hostname === 'localhost') {
        API = window.location.origin;
      }
      // Non-extension, non-localhost context: keep the production default (no probe).
    }
  }
  initApi();

  var cvPhase = 'role', isLoading = false, convHistory = [];
  var panelOpen = false, currentView = 'home';
  var uploadedCVText = ''; // persists across all views

  var fab   = document.getElementById('sbot-fab');
  var panel = document.getElementById('sbot-panel');
  var pulse = document.getElementById('sbot-pulse');

  // The bot's instructions live on the server (backend/prompts/sndr-advisor-
  // system.txt), including how answers are structured and how long they are.
  // /api/ai/cv-chat ignores any instructions sent from here.

  // ── DRAGGABLE FAB LOGIC ──
  var isDragging = false;
  var startX, startY;
  var startLeft, startTop;

  fab.addEventListener('mousedown', function(e) {
    e.preventDefault();
    startX = e.clientX;
    startY = e.clientY;
    var rect = fab.getBoundingClientRect();
    startLeft = rect.left;
    startTop = rect.top;
    isDragging = false;

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  });

  function onMouseMove(e) {
    var dx = e.clientX - startX;
    var dy = e.clientY - startY;

    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
      isDragging = true;
    }

    if (isDragging) {
      var newLeft = startLeft + dx;
      var newTop = startTop + dy;

      var vw = window.innerWidth;
      var vh = window.innerHeight;
      newLeft = Math.max(10, Math.min(newLeft, vw - 62));
      newTop = Math.max(10, Math.min(newTop, vh - 62));

      fab.style.left = newLeft + 'px';
      fab.style.top = newTop + 'px';
      fab.style.bottom = 'auto';
      fab.style.right = 'auto';

      if (pulse) {
        pulse.style.left = (newLeft - 6) + 'px';
        pulse.style.top = (newTop - 6) + 'px';
        pulse.style.bottom = 'auto';
        pulse.style.right = 'auto';
      }

      var panelWidth = 380;
      var panelHeight = 560;
      var panelLeft = newLeft - panelWidth + 52;
      var panelTop = newTop - panelHeight - 12;

      if (panelLeft < 10) panelLeft = newLeft + 12;
      if (panelTop < 10) panelTop = newTop + 64;

      panel.style.left = panelLeft + 'px';
      panel.style.top = panelTop + 'px';
      panel.style.bottom = 'auto';
      panel.style.right = 'auto';
    }
  }

  function onMouseUp(e) {
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);

    if (!isDragging) {
      panelOpen = !panelOpen;
      if (!panelOpen) { currentView = 'home'; }
      togglePanel();
    }
  }

  // The sidebar's "SNDR AI" item opens the panel through this (the button
  // itself opens on mouseup so it can also be dragged).
  window.sndrOpenAI = function () { if (!panelOpen) { panelOpen = true; togglePanel(); } };

  function togglePanel(){
    if(panelOpen){
      panel.style.display = 'flex';
      panel.style.flexDirection = 'column';
      pulse.style.display = 'none';
      fab.classList.add('open');
      fab.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 2l12 12M14 2L2 14" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round"/></svg>';

      if (fab.style.left) {
        var rect = fab.getBoundingClientRect();
        var panelWidth = 380;
        var panelHeight = 560;
        var panelLeft = rect.left - panelWidth + rect.width;
        var panelTop = rect.top - panelHeight - 12;

        if (panelLeft < 10) panelLeft = rect.left + 12;
        if (panelTop < 10) panelTop = rect.top + rect.height + 12;

        panel.style.left = panelLeft + 'px';
        panel.style.top = panelTop + 'px';
        panel.style.bottom = 'auto';
        panel.style.right = 'auto';
      } else {
        panel.style.bottom = '90px';
        panel.style.right = '24px';
        panel.style.left = 'auto';
        panel.style.top = 'auto';
      }

      setTimeout(function(){ panel.classList.add('open'); }, 10);
      if(currentView==='home') renderHome();
    } else {
      panel.classList.remove('open');
      pulse.style.display = 'block';
      fab.classList.remove('open');
      fab.innerHTML = '<span class="sbot-fab-text">Ask SNDR AI</span><span class="mi" style="font-size:18px;color:#fff">auto_awesome</span>';
      setTimeout(function(){ panel.style.display='none'; }, 220);
    }
  }

  function renderHome(){
    var iconCV        = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><rect x="2" y="1" width="10" height="13" rx="1.5" stroke="#ffffff" stroke-width="1.3"/><path d="M5 5h5M5 7.5h5M5 10h3" stroke="#ffffff" stroke-width="1.2" stroke-linecap="round"/></svg>';
    var iconCompanies = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M1.5 14.5V1.5h10v13h-10zM11.5 5.5h3v9h-3M4 4.5h2v2H4v-2zm0 4h2v2H4v-2z" stroke="#ffffff" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    var iconTemplates = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><rect x="1.5" y="3.5" width="13" height="9" rx="1.5" stroke="#ffffff" stroke-width="1.3"/><path d="M1.5 5.5l6.5 4 6.5-4" stroke="#ffffff" stroke-width="1.3" stroke-linecap="round"/></svg>';
    var iconLinkedin  = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="5" r="3" stroke="#ffffff" stroke-width="1.3"/><path d="M2.5 13.5a5.5 5.5 0 0111 0" stroke="#ffffff" stroke-width="1.3" stroke-linecap="round"/></svg>';
    var iconPrep      = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M8 2.5a5.5 5.5 0 00-5.5 5.5c0 1.25.4 2.4 1.1 3.35L2.5 14.5l3.5-.8c.6.25 1.3.35 2 .35a5.5 5.5 0 100-11z" stroke="#ffffff" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>';

    panel.innerHTML =
      '<div class="sbot-hdr">' +
        '<div class="sbot-logo"><svg width="16" height="16" viewBox="0 0 18 18" fill="none"><path d="M9 1.5l2 6h6.2l-5 3.6 1.9 5.9L9 13.5l-5.1 3.5 1.9-5.9-5-3.6H7L9 1.5z" fill="#ffffff"/></svg></div>' +
        '<div class="sbot-brand"><div class="sbot-brand-name">SNDR AI</div><div class="sbot-brand-sub">Career Co-Pilot</div></div>' +
        '<button class="sbot-x" id="sb-x">&#x2715;</button>' +
      '</div>' +
      '<div class="sbot-greet">' +
        '<div class="sbot-greet-h">Welcome.<br>How may I assist you today?</div>' +
        '<div class="sbot-greet-s"><span class="sbot-sdot"></span>SNDR Placement Engine &middot; Online</div>' +
      '</div>' +
      '<div class="sbot-actions">' +
        mkAct('sb-cv', 'Analyze Resume / CV', 'Upload your CV for a tailored, specific benchmark analysis', iconCV) +
        mkAct('sb-companies', 'Target Companies', 'Identify target companies tailored to your profile and sector', iconCompanies) +
        mkAct('sb-templates', 'Cold Outreach Templates', 'Generate sector-specific, CV-tailored outreach drafts', iconTemplates) +
        mkAct('sb-linkedin', 'LinkedIn Profile Optimizer', 'Generate profile enhancement recommendations', iconLinkedin) +
        mkAct('sb-interview', 'Interview Preparation', 'Practice customized interview questions by sector', iconPrep) +
      '</div>' +
      '<div class="sbot-foot">' +
        '<div class="sbot-inp-row">' +
          '<input class="sbot-inp" id="sb-hi" placeholder="Ask a career question...">' +
          '<button class="sbot-go" id="sb-hgo"><svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M1 5h8M6 2l3 3-3 3" stroke="#ffffff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
        '</div>' +
        '<div class="sbot-toast" id="sb-toast"></div>' +
      '</div>';

    document.getElementById('sb-x').onclick = function(){ panelOpen=false; togglePanel(); };
    document.getElementById('sb-cv').onclick = function(){ currentView='cv'; renderCV(); };

    // "Ask a question" → navigate to general chat AND send the typed question
    function goChat() {
      var q = (document.getElementById('sb-hi') || {}).value || '';
      q = q.trim();
      currentView = 'cv';
      renderCV(q || null);
    }
    document.getElementById('sb-hgo').onclick = goChat;
    document.getElementById('sb-hi').onkeydown = function(e){ if(e.key==='Enter') goChat(); };

    // Feature cards → chip-only feature panels (no free text input)
    var featureMap = {
      'sb-companies': 'companies',
      'sb-templates': 'templates',
      'sb-linkedin':  'linkedin',
      'sb-interview': 'interview'
    };
    Object.keys(featureMap).forEach(function(btnId) {
      var el = document.getElementById(btnId);
      if (el) {
        el.onclick = function() { renderFeaturePanel(featureMap[btnId]); };
      }
    });
  }

  // ── FEATURE PANEL (sector chips to start, then a real chat like CV analysis) ──
  function renderFeaturePanel(action) {
    currentView = 'feature';
    // Local to this panel's session — a fresh conversation each time the
    // panel opens, separate from the CV-analysis chat's own history.
    var featureHistory = [];

    var titles = {
      companies: 'Target Companies',
      templates: 'Cold Outreach',
      linkedin:  'LinkedIn Optimizer',
      interview: 'Interview Prep'
    };

    var chipLabels = {
      companies: ['Investment Banking', 'Management Consulting', 'VC / PE', 'Marketing', 'Tech / Product'],
      templates: ['Investment Banking', 'Management Consulting', 'VC / PE', 'Marketing', 'Tech / Product'],
      linkedin:  ['Investment Banking', 'Management Consulting', 'VC / PE', 'Marketing', 'Tech / Product'],
      interview: ['Investment Banking', 'Management Consulting', 'VC / PE', 'Marketing', 'Tech / Product']
    };

    panel.innerHTML =
      '<div class="sbot-chat-hdr">' +
        '<button class="sbot-back" id="sb-back">&#x2039; Back</button>' +
        '<div class="sbot-chat-title">' + (titles[action] || '').toUpperCase() + '</div>' +
      '</div>' +
      '<div class="sbot-msgs" id="sb-msgs"></div>' +
      inputAreaHtml('sb-fta', 'sb-fsend', '');

    document.getElementById('sb-back').onclick = function(){ currentView='home'; renderHome(); };

    var msgsEl = document.getElementById('sb-msgs');

    var intro;
    if (action === 'linkedin') {
      intro = (uploadedCVText ? '' : 'Attach your CV with the 📎 below for the most tailored review. ') +
        'To review your LinkedIn profile, paste your headline, About section, and experience bullets below as text — that\'s what lets me give specific, quotable feedback instead of generic tips. Or pick a sector below for a general checklist to start.';
    } else {
      intro = uploadedCVText
        ? 'Select your target sector below. Recommendations will be tailored specifically to your uploaded CV, skills, and internships.'
        : 'For tailored recommendations, attach your CV with the 📎 below. Then pick a sector:';
    }

    addFeatureChips(msgsEl, intro, chipLabels[action], action, featureHistory);

    // A CV attached here is used straight away: mid-conversation, the bot
    // continues what it was doing (e.g. the draft it asked the CV for).
    wireAttach(function(fileName, cvText) {
      if (!featureHistory.length) {
        addBub(msgsEl, 'bot', 'Got your CV (' + fileName + '). Now pick a sector above and I\'ll tailor it to you.');
        return;
      }
      sendFeatureChatMsg(msgsEl, 'CV attached: ' + fileName,
        'Here is my CV:\n\n' + cvText + '\n\nUse it to continue with what you were helping me with.', featureHistory, action);
    });

    // Free-text follow-ups — same pattern as the CV analysis chat, so a
    // sector pick isn't a dead end; the conversation can continue.
    function doFeatureSend() {
      var ta = document.getElementById('sb-fta');
      var v = (ta || {}).value || '';
      v = v.trim();
      if (!v || isLoading) return;
      ta.value = '';
      ta.style.height = 'auto';
      sendFeatureChatMsg(msgsEl, v, v, featureHistory, action);
    }
    var fsend = document.getElementById('sb-fsend');
    if (fsend) fsend.onclick = doFeatureSend;
    var fta = document.getElementById('sb-fta');
    if (fta) {
      fta.addEventListener('input', function(){ fta.style.height='auto'; fta.style.height=Math.min(fta.scrollHeight,80)+'px'; });
      fta.onkeydown = function(e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doFeatureSend(); }
      };
    }
  }

  function addFeatureChips(msgsEl, introText, chips, action, featureHistory) {
    var d = document.createElement('div'); d.className = 'sbot-msg bot';
    var b = document.createElement('div'); b.className = 'sbot-bub';
    b.innerHTML = mdToChat(introText);
    d.appendChild(b);

    var row = document.createElement('div'); row.className = 'sbot-chips';
    chips.forEach(function(label) {
      var ch = document.createElement('div'); ch.className = 'sbot-chip';
      ch.textContent = label;
      ch.onclick = function() {
        // Remove all chips after selection — further turns go through the
        // free-text input instead, same as any other chat.
        row.remove();
        sendFeatureChatMsg(msgsEl, label, buildFeatureQuery(action, label), featureHistory, action);
      };
      row.appendChild(ch);
    });
    d.appendChild(row);
    msgsEl.appendChild(d);
    msgsEl.scrollTop = msgsEl.scrollHeight;
  }

  // Each ask names exactly what to return, so answers stay short and scannable
  // (the server prompt sets the overall format and length budget).
  function buildFeatureQuery(action, domain) {
    var cvContext = uploadedCVText ? '\n\nMy CV for reference:\n' + uploadedCVText : '';
    if (action === 'companies') {
      return 'Give me a tiered target list for the ' + domain + ' sector (Stretch / Core / Safety, 6-8 companies in total) that fits my background, with one line on why each fits me.' + cvContext;
    } else if (action === 'templates') {
      return 'Draft one cold outreach email for the ' + domain + ' sector that uses my specific skills, projects and internships.' + cvContext;
    } else if (action === 'linkedin') {
      return 'What are the 5 highest-impact changes to my LinkedIn profile for the ' + domain + ' sector? Show the rewrite for each.' + cvContext;
    } else if (action === 'interview') {
      return 'Give me the 5 interview questions I\'m most likely to get for the ' + domain + ' sector, each with a one-line answer angle drawn from my actual experience.' + cvContext;
    }
    return '';
  }

  // Chat-with-history version used by feature panels — same shape as
  // sendMsg() (the CV-analysis chat), but keeps its own local history so
  // each feature panel is its own conversation thread.
  async function sendFeatureChatMsg(msgsEl, displayText, apiText, featureHistory, action) {
    if (isLoading) return;
    addBub(msgsEl, 'user', displayText);
    featureHistory.push({ role: 'user', content: apiText });
    isLoading = true;

    var d = document.createElement('div'); d.className = 'sbot-msg bot'; d.id = 'sb-typing';
    d.innerHTML = '<div class="sbot-bub"><div class="sbot-ty"><div class="sbot-td"></div><div class="sbot-td"></div><div class="sbot-td"></div></div></div>';
    msgsEl.appendChild(d); msgsEl.scrollTop = msgsEl.scrollHeight;

    try {
      var reply = await callAI(featureHistory);
      featureHistory.push({ role: 'assistant', content: reply });
      var t = document.getElementById('sb-typing'); if (t) t.remove();
      addBub(msgsEl, 'bot', reply || 'No response received.');
    } catch (e) {
      var t2 = document.getElementById('sb-typing'); if (t2) t2.remove();
      addBub(msgsEl, 'bot', 'AI error: ' + e.message);
    }
    isLoading = false;
  }

  // ── Attach a CV (both chat screens) ──
  // The message bar's 📎 reads a PDF/Word CV through the server. One CV is
  // kept for the whole session, so every chat and feature panel can use it.
  var uploadedCVName = '';
  var ATTACH_ICON = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M13.5 7.5l-5.6 5.6a3.5 3.5 0 01-5-5l5.9-5.9a2.3 2.3 0 013.3 3.3L6.3 11.3a1.2 1.2 0 01-1.7-1.7l5.3-5.3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var SEND_ICON = '<svg width="11" height="11" viewBox="0 0 11 11" fill="none"><path d="M1.5 5.5h8M7 2l3 3.5L7 9" stroke="#ffffff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function inputAreaHtml(taId, sendId, extraTop) {
    return '<div class="sbot-inp-area">' +
        extraTop +
        '<div class="sbot-attached" id="sb-attached"></div>' +
        '<div class="sbot-ta-wrap">' +
          '<input type="file" id="sb-attach-file" accept=".pdf,.doc,.docx" style="display:none">' +
          '<button type="button" class="sbot-attach" id="sb-attach" title="Attach your CV (PDF or Word)" aria-label="Attach your CV">' + ATTACH_ICON + '</button>' +
          '<textarea class="sbot-ta" id="' + taId + '" rows="1" placeholder="Type your message here..."></textarea>' +
          '<button class="sbot-send" id="' + sendId + '">' + SEND_ICON + '</button>' +
        '</div>' +
      '</div>';
  }

  // Shows which CV is attached (with × to remove it), or an upload state.
  function renderAttached(msg, cls) {
    var el = document.getElementById('sb-attached');
    if (!el) return;
    el.className = 'sbot-attached' + (cls ? ' ' + cls : '');
    if (msg) { el.textContent = msg; el.style.display = 'flex'; return; }
    if (!uploadedCVName) { el.style.display = 'none'; el.textContent = ''; return; }
    el.innerHTML = '';
    var name = document.createElement('span');
    name.textContent = '📎 ' + uploadedCVName + ' · attached';
    var x = document.createElement('button');
    x.type = 'button'; x.className = 'sbot-attached-x'; x.title = 'Remove CV'; x.textContent = '×';
    x.onclick = function() {
      uploadedCVText = ''; uploadedCVName = '';
      var big = document.getElementById('sb-upload'); // the CV screen's main upload button
      if (big) big.style.display = '';
      renderAttached();
    };
    el.appendChild(name); el.appendChild(x);
    el.style.display = 'flex';
  }

  function uploadCVFile(file) {
    var formData = new FormData();
    formData.append('cv', file);
    return fetch(API + '/api/cv/upload', { method: 'POST', body: formData })
      .then(function(r) { return r.json(); })
      .then(function(data) {
        if (!data.ok || !data.cvText) throw new Error(data.error || 'No text could be read from this file');
        uploadedCVText = data.cvText;
        uploadedCVName = file.name;
        return data.cvText;
      });
  }

  // Wires the 📎 button (and any extra trigger, like the CV screen's big
  // upload button) to read the file, then hands the text to onUploaded.
  function wireAttach(onUploaded, extraTrigger) {
    var btn = document.getElementById('sb-attach');
    var inp = document.getElementById('sb-attach-file');
    if (!btn || !inp) return;
    renderAttached();
    function pick() { if (!isLoading) inp.click(); }
    btn.onclick = pick;
    if (extraTrigger) extraTrigger.onclick = pick;
    inp.onchange = function(e) {
      var file = e.target.files[0];
      inp.value = '';
      if (!file) return;
      if (!/\.(pdf|docx?)$/i.test(file.name)) { renderAttached('Please attach a PDF or Word file.', 'err'); return; }
      if (file.size > 10 * 1024 * 1024) { renderAttached('That file is over 10 MB — try a smaller one.', 'err'); return; }
      btn.disabled = true;
      if (extraTrigger) extraTrigger.disabled = true;
      renderAttached('Reading ' + file.name + '…', 'busy');
      uploadCVFile(file).then(function(text) {
        btn.disabled = false;
        if (extraTrigger) { extraTrigger.disabled = false; extraTrigger.style.display = 'none'; }
        renderAttached();
        onUploaded(file.name, text);
      }).catch(function(err) {
        btn.disabled = false;
        if (extraTrigger) extraTrigger.disabled = false;
        renderAttached('Couldn\'t read that file: ' + (err && err.message ? err.message : 'please try again.'), 'err');
      });
    };
  }

  // All AI calls go through the backend, which holds the provider keys in env.
  // (Direct provider calls from the extension are not allowed — they would ship
  // a secret to every user.)
  async function executeAIQuery(history) {
    var resp = await fetch(API + '/api/ai/cv-chat', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ messages: history })
    });
    var data = await resp.json().catch(function() { return {}; });
    if (!resp.ok) throw new Error(data.error || 'AI request failed');
    return data.reply || '';
  }

  function mkAct(id, title, sub, iconSvg) {
    return '<div class="sbot-act sbot-live" id="' + id + '">' +
             '<div class="sbot-act-ico">' + iconSvg + '</div>' +
             '<div class="sbot-act-txt">' +
               '<div class="sbot-act-t">' + title + '</div>' +
               '<div class="sbot-act-s">' + sub + '</div>' +
             '</div>' +
             '<span class="sbot-arr">&#x203A;</span>' +
           '</div>';
  }

  // ── CV ANALYSIS + GENERAL CHAT ──
  function renderCV(initialQuestion){
    panel.innerHTML =
      '<div class="sbot-chat-hdr">' +
        '<button class="sbot-back" id="sb-back">&#x2039; Back</button>' +
        '<div class="sbot-chat-title">CAREER CO-PILOT</div>' +
      '</div>' +
      '<div class="sbot-msgs" id="sb-msgs"></div>' +
      inputAreaHtml('sb-ta', 'sb-send',
        '<button class="sbot-upload-btn" id="sb-upload"' + (uploadedCVName ? ' style="display:none"' : '') + '>Upload Resume / CV (PDF or Word)</button>');

    document.getElementById('sb-back').onclick = function(){ currentView='home'; renderHome(); };

    var msgsEl = document.getElementById('sb-msgs');
    convHistory.forEach(function(m){ addBub(msgsEl, m.role==='assistant'?'bot':'user', m._d||m.content); });

    if(convHistory.length===0 && !initialQuestion){
      addBub(msgsEl,'bot',
        'Welcome to the SNDR AI Career Advisor.\n\nUpload your CV for a highly tailored benchmark analysis, or ask me anything about your career transition, target companies, or outreach strategy.',
        ['Investment Banking','Consulting','VC / PE','Marketing','Tech / Product']);
    }

    var ta = document.getElementById('sb-ta');
    var sb = document.getElementById('sb-send');
    if(ta){
      ta.addEventListener('input',function(){ ta.style.height='auto'; ta.style.height=Math.min(ta.scrollHeight,80)+'px'; });
      ta.onkeydown = function(e){ if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();doSend();} };
    }
    if(sb) sb.onclick = doSend;

    // CV upload — the 📎 in the message bar and the big button do the same.
    // Uploading here asks for the CV review this screen is for.
    wireAttach(function(fileName) {
      cvPhase = 'cv';
      sendMsg('I have uploaded my CV (' + fileName + '). Here is the content:\n\n' + uploadedCVText, fileName);
    }, document.getElementById('sb-upload'));

    // If navigated here from home "Ask a question", auto-send the typed question
    if (initialQuestion) {
      setTimeout(function(){ sendMsg(initialQuestion); }, 80);
    }

    function doSend(){ var v=(document.getElementById('sb-ta')||{}).value||''; v=v.trim(); if(!v||isLoading) return; document.getElementById('sb-ta').value=''; document.getElementById('sb-ta').style.height='auto'; sendMsg(v); }
  }

  // Renders the small formatting set the server prompt allows — a bold label on
  // its own line, "- " bullets, "1." steps, **bold** — as real structure:
  // section labels, spaced lists and paragraphs, with the closing
  // "Next step:" line set apart. Text is HTML-escaped before any tags are
  // added. Anything else the model slips in (# headings, *italics*,
  // backticks) is shown as plain text rather than raw symbols.
  function mdToChat(text){
    var esc = String(text || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    function inline(s){
      return s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
              .replace(/(^|[^*])\*([^*\s][^*]*?)\*(?!\*)/g, '$1$2')
              .replace(/`/g, '');
    }
    var html = [], list = null, para = [];
    function closeList(){ if (list) { html.push('</' + list + '>'); list = null; } }
    function closePara(){ if (para.length) { html.push('<p>' + para.join('<br>') + '</p>'); para = []; } }
    function openList(tag){ closePara(); if (list !== tag) { closeList(); html.push('<' + tag + '>'); list = tag; } }

    esc.split('\n').forEach(function(raw){
      var line = raw.trim(), m;
      if (!line) { closePara(); closeList(); return; }
      if ((m = line.match(/^#{1,6}\s+(.*)$/)) || (m = line.match(/^\*\*([^*]+?)\*\*:?$/))) {
        closePara(); closeList();
        html.push('<div class="sbot-h">' + inline(m[1].replace(/\*\*/g, '')) + '</div>');
      } else if ((m = line.match(/^[-*•]\s+(.*)$/))) {
        openList('ul'); html.push('<li>' + inline(m[1]) + '</li>');
      } else if ((m = line.match(/^(\d{1,2})[.)]\s+(.*)$/))) {
        openList('ol'); html.push('<li value="' + m[1] + '">' + inline(m[2]) + '</li>');
      } else if (/^(\*\*)?next step:?/i.test(line)) {
        closePara(); closeList();
        html.push('<div class="sbot-next">' + inline(line) + '</div>');
      } else {
        closeList(); para.push(inline(line));
      }
    });
    closePara(); closeList();
    return html.join('');
  }

  function addBub(container, role, text, chips){
    var d=document.createElement('div'); d.className='sbot-msg '+role;
    var b=document.createElement('div'); b.className='sbot-bub';
    b.innerHTML=mdToChat(text);
    d.appendChild(b);
    if(chips&&chips.length){
      var row=document.createElement('div'); row.className='sbot-chips';
      chips.forEach(function(c){ var ch=document.createElement('div'); ch.className='sbot-chip'; ch.textContent=c; ch.onclick=function(){ sendMsg(c); }; row.appendChild(ch); });
      d.appendChild(row);
    }
    container.appendChild(d); container.scrollTop=container.scrollHeight;
  }

  function addTyping(){
    var msgsEl=document.getElementById('sb-msgs'); if(!msgsEl) return;
    var d=document.createElement('div'); d.className='sbot-msg bot'; d.id='sb-typing';
    d.innerHTML='<div class="sbot-bub"><div class="sbot-ty"><div class="sbot-td"></div><div class="sbot-td"></div><div class="sbot-td"></div></div></div>';
    msgsEl.appendChild(d); msgsEl.scrollTop=msgsEl.scrollHeight;
  }

  async function callAI(history){
    return await executeAIQuery(history);
  }

  async function sendMsg(text, displayName){
    if(!text||isLoading) return;
    var apiText = text;

    // If this is a CV upload (long text), trigger deep tailored analysis
    if(text.length > 100 && (cvPhase === 'cv' || cvPhase === 'role')){
      cvPhase = 'chat';
      apiText = 'Here is my CV:\n\n' + text + '\n\nReview it. Rewrite my 3 weakest bullets with quantified impact, then flag any quick formatting fixes. Be specific to my CV, not generic.';
    }

    // For freeform questions, append CV context if available and not already included
    if (uploadedCVText && text.length < 500 && apiText.indexOf(uploadedCVText) === -1) {
      apiText = apiText + '\n\n[My CV for context]:\n' + uploadedCVText;
    }

    var msgsEl = document.getElementById('sb-msgs'); if(!msgsEl) return;
    var displayText = displayName ? 'CV Uploaded: ' + displayName : text;
    addBub(msgsEl,'user',displayText);
    convHistory.push({role:'user',content:apiText,_d:displayText});
    isLoading=true; addTyping();
    var sb=document.getElementById('sb-send'); if(sb) sb.disabled=true;
    try{
      var history=convHistory.map(function(m){return{role:m.role,content:m.content};});
      var reply=await callAI(history);
      var t=document.getElementById('sb-typing'); if(t) t.remove();
      convHistory.push({role:'assistant',content:reply,_d:reply});
      var msgsEl2=document.getElementById('sb-msgs');
      if(msgsEl2) addBub(msgsEl2,'bot',reply);
      if(cvPhase==='role') cvPhase='cv';
    }catch(e){
      var t2=document.getElementById('sb-typing'); if(t2) t2.remove();
      var msgsEl3=document.getElementById('sb-msgs');
      if(msgsEl3) addBub(msgsEl3,'bot','AI error: ' + e.message);
    }
    isLoading=false;
    var sb2=document.getElementById('sb-send'); if(sb2) sb2.disabled=false;
  }

  function showToast(msg){
    var t=document.getElementById('sb-toast'); if(!t) return;
    t.innerHTML=msg; t.classList.add('show');
    setTimeout(function(){ t.classList.remove('show'); },2500);
  }

})();