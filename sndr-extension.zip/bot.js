(function(){
  var API = window.location.hostname === 'localhost' ? window.location.origin : 'https://sndr-f4rg.onrender.com';

  async function initApi() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise(function(resolve) {
        chrome.storage.local.get(['custom_api_url'], async function(data) {
          if (data.custom_api_url) {
            API = data.custom_api_url;
            console.log('[SNDR] Bot using API URL:', API);
          } else {
            try {
              var localCheck = await fetch('http://localhost:3000/health', { signal: AbortSignal.timeout(800) });
              if (localCheck.ok) {
                API = 'http://localhost:3000';
                console.log('[SNDR] Bot autodetected local backend:', API);
              }
            } catch(e) {}
          }
          resolve();
        });
      });
    } else {
      if (window.location.hostname === 'localhost') {
        API = window.location.origin;
      } else {
        try {
          var localCheck = await fetch('http://localhost:3000/health', { signal: AbortSignal.timeout(800) });
          if (localCheck.ok) {
            API = 'http://localhost:3000';
            console.log('[SNDR] Bot autodetected local backend:', API);
          }
        } catch(e) {}
      }
    }
  }
  initApi();

  var cvPhase = 'role', isLoading = false, convHistory = [];
  var panelOpen = false, currentView = 'home';
  var uploadedCVText = ''; // persists across all views

  var fab   = document.getElementById('sbot-fab');
  var panel = document.getElementById('sbot-panel');
  var pulse = document.getElementById('sbot-pulse');

  var SYSTEM = 'You are the SNDR AI Lead Placement Advisor, an elite, formal, and precise career co-pilot. RULES: ' +
    '1) ONLY discuss resumes, cover letters, career outbounds, target companies, placements, and interview prep. Politely decline unrelated topics. ' +
    '2) NEVER give generic advice. Every recommendation must be unique and highly tailored to the candidate\'s specific CV, skills, projects, and internships. ' +
    '3) Provide creative, CV-specific guidance: quote the exact weak bullet point from the CV, explain why it requires improvement, and show a highly tailored, high-impact redrafted version. ' +
    '4) Apply the CAR (Context, Action, Result) framework. Every redrafted bullet must begin with a strong, active verb and end with a quantified metric. ' +
    '5) NEVER suggest changing the table/column format of the educational qualifications section, as university guidelines mandate a column/table layout. ' +
    '6) When a candidate asks about switching careers or domains (e.g., from Marketing to Consulting), conduct a gap analysis using their CV: identify transferable skills from their specific projects/internships, highlight precise skill gaps, and suggest a realistic 3-6 month action plan to bridge those gaps tailored to their background. ' +
    '7) Use professional industry-specific vocabulary (e.g., MECE, DCF, CAC/LTV). Keep responses concise (under 400 words) and beautifully formatted with bold subheadings and markdown. Leave empty lines (double line breaks) between different pointers, recommendations, and sections for readability. No emojis. ' +
    '8) CRITICAL COLD OUTREACH REALISM: For consulting, NEVER recommend MBB (McKinsey, BCG, Bain) or Kearney, Roland Berger, Oliver Wyman, ADL, LEK. Instead suggest India-based boutiques like Redseer, Praxis Global Alliance, Whitespace Strategy, BC Strategy, Avalon Consulting, Feedback Consulting, EY-Parthenon, KPMG Advisory, Deloitte Consulting, PwC Strategy&. For finance, NEVER suggest Bulge Bracket Banks (Goldman, JP Morgan, Morgan Stanley, PE/VC top-tier like Peak XV/Sequoia). Instead suggest boutique investment banks (Avendus, JM Financial, IIFL, Edelweiss, o3, Spark) or Family Offices, Micro VCs/Angel Networks (100X.VC, LetsVenture, Titan Capital, Blume Ventures). ' +
    '9) CRITICAL TAILORING RULE: NEVER give generic advice, templates, or company lists. You must carefully analyze the specific CV in the conversation history (college, GPA, internships, skills, projects) and make every recommendation and draft 100% personalized. Reference their specific experiences and project names directly in your response to prove it is tailored.';

  // ── DRAGGABLE FAB LOGIC ──
  var isDragging = false;
  var startX, startY;
  var startLeft, startTop;

  fab.addEventListener('mousedown', function(e) {
    e.preventDefault();
    startX = e.clientX;
    startY = e.clientY;
    var rect = fab.getBoundingClientRect();
    startLeft = rect.left;
    startTop = rect.top;
    isDragging = false;

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  });

  function onMouseMove(e) {
    var dx = e.clientX - startX;
    var dy = e.clientY - startY;

    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
      isDragging = true;
    }

    if (isDragging) {
      var newLeft = startLeft + dx;
      var newTop = startTop + dy;

      var vw = window.innerWidth;
      var vh = window.innerHeight;
      newLeft = Math.max(10, Math.min(newLeft, vw - 62));
      newTop = Math.max(10, Math.min(newTop, vh - 62));

      fab.style.left = newLeft + 'px';
      fab.style.top = newTop + 'px';
      fab.style.bottom = 'auto';
      fab.style.right = 'auto';

      if (pulse) {
        pulse.style.left = (newLeft - 6) + 'px';
        pulse.style.top = (newTop - 6) + 'px';
        pulse.style.bottom = 'auto';
        pulse.style.right = 'auto';
      }

      var panelWidth = 380;
      var panelHeight = 560;
      var panelLeft = newLeft - panelWidth + 52;
      var panelTop = newTop - panelHeight - 12;

      if (panelLeft < 10) panelLeft = newLeft + 12;
      if (panelTop < 10) panelTop = newTop + 64;

      panel.style.left = panelLeft + 'px';
      panel.style.top = panelTop + 'px';
      panel.style.bottom = 'auto';
      panel.style.right = 'auto';
    }
  }

  function onMouseUp(e) {
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);

    if (!isDragging) {
      panelOpen = !panelOpen;
      if (!panelOpen) { currentView = 'home'; }
      togglePanel();
    }
  }

  function togglePanel(){
    if(panelOpen){
      panel.style.display = 'flex';
      panel.style.flexDirection = 'column';
      pulse.style.display = 'none';
      fab.classList.add('open');
      fab.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 2l12 12M14 2L2 14" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round"/></svg>';

      if (fab.style.left) {
        var rect = fab.getBoundingClientRect();
        var panelWidth = 380;
        var panelHeight = 560;
        var panelLeft = rect.left - panelWidth + rect.width;
        var panelTop = rect.top - panelHeight - 12;

        if (panelLeft < 10) panelLeft = rect.left + 12;
        if (panelTop < 10) panelTop = rect.top + rect.height + 12;

        panel.style.left = panelLeft + 'px';
        panel.style.top = panelTop + 'px';
        panel.style.bottom = 'auto';
        panel.style.right = 'auto';
      } else {
        panel.style.bottom = '90px';
        panel.style.right = '24px';
        panel.style.left = 'auto';
        panel.style.top = 'auto';
      }

      setTimeout(function(){ panel.classList.add('open'); }, 10);
      if(currentView==='home') renderHome();
    } else {
      panel.classList.remove('open');
      pulse.style.display = 'block';
      fab.classList.remove('open');
      fab.innerHTML = '<span class="sbot-fab-text">Ask SNDR AI</span><span class="mi" style="font-size:18px;color:#fff">auto_awesome</span>';
      setTimeout(function(){ panel.style.display='none'; }, 220);
    }
  }

  function renderHome(){
    var iconCV        = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><rect x="2" y="1" width="10" height="13" rx="1.5" stroke="#ffffff" stroke-width="1.3"/><path d="M5 5h5M5 7.5h5M5 10h3" stroke="#ffffff" stroke-width="1.2" stroke-linecap="round"/></svg>';
    var iconCompanies = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M1.5 14.5V1.5h10v13h-10zM11.5 5.5h3v9h-3M4 4.5h2v2H4v-2zm0 4h2v2H4v-2z" stroke="#ffffff" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    var iconTemplates = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><rect x="1.5" y="3.5" width="13" height="9" rx="1.5" stroke="#ffffff" stroke-width="1.3"/><path d="M1.5 5.5l6.5 4 6.5-4" stroke="#ffffff" stroke-width="1.3" stroke-linecap="round"/></svg>';
    var iconLinkedin  = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="5" r="3" stroke="#ffffff" stroke-width="1.3"/><path d="M2.5 13.5a5.5 5.5 0 0111 0" stroke="#ffffff" stroke-width="1.3" stroke-linecap="round"/></svg>';
    var iconPrep      = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M8 2.5a5.5 5.5 0 00-5.5 5.5c0 1.25.4 2.4 1.1 3.35L2.5 14.5l3.5-.8c.6.25 1.3.35 2 .35a5.5 5.5 0 100-11z" stroke="#ffffff" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>';

    panel.innerHTML =
      '<div class="sbot-hdr">' +
        '<div class="sbot-logo"><svg width="16" height="16" viewBox="0 0 18 18" fill="none"><path d="M9 1.5l2 6h6.2l-5 3.6 1.9 5.9L9 13.5l-5.1 3.5 1.9-5.9-5-3.6H7L9 1.5z" fill="#ffffff"/></svg></div>' +
        '<div class="sbot-brand"><div class="sbot-brand-name">SNDR AI</div><div class="sbot-brand-sub">Career Co-Pilot</div></div>' +
        '<button class="sbot-x" id="sb-x">&#x2715;</button>' +
      '</div>' +
      '<div class="sbot-greet">' +
        '<div class="sbot-greet-h">Welcome.<br>How may I assist you today?</div>' +
        '<div class="sbot-greet-s"><span class="sbot-sdot"></span>SNDR Placement Engine &middot; Online</div>' +
      '</div>' +
      '<div class="sbot-actions">' +
        mkAct('sb-cv', 'Analyze Resume / CV', 'Upload your CV for a tailored, specific benchmark analysis', iconCV) +
        mkAct('sb-companies', 'Target Companies', 'Identify target companies tailored to your profile and sector', iconCompanies) +
        mkAct('sb-templates', 'Cold Outreach Templates', 'Generate sector-specific, CV-tailored outreach drafts', iconTemplates) +
        mkAct('sb-linkedin', 'LinkedIn Profile Optimizer', 'Generate profile enhancement recommendations', iconLinkedin) +
        mkAct('sb-interview', 'Interview Preparation', 'Practice customized interview questions by sector', iconPrep) +
      '</div>' +
      '<div class="sbot-foot">' +
        '<div class="sbot-inp-row">' +
          '<input class="sbot-inp" id="sb-hi" placeholder="Ask a career question...">' +
          '<button class="sbot-go" id="sb-hgo"><svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M1 5h8M6 2l3 3-3 3" stroke="#ffffff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
        '</div>' +
        '<div class="sbot-toast" id="sb-toast"></div>' +
      '</div>';

    document.getElementById('sb-x').onclick = function(){ panelOpen=false; togglePanel(); };
    document.getElementById('sb-cv').onclick = function(){ currentView='cv'; renderCV(); };

    // "Ask a question" → navigate to general chat AND send the typed question
    function goChat() {
      var q = (document.getElementById('sb-hi') || {}).value || '';
      q = q.trim();
      currentView = 'cv';
      renderCV(q || null);
    }
    document.getElementById('sb-hgo').onclick = goChat;
    document.getElementById('sb-hi').onkeydown = function(e){ if(e.key==='Enter') goChat(); };

    // Feature cards → chip-only feature panels (no free text input)
    var featureMap = {
      'sb-companies': 'companies',
      'sb-templates': 'templates',
      'sb-linkedin':  'linkedin',
      'sb-interview': 'interview'
    };
    Object.keys(featureMap).forEach(function(btnId) {
      var el = document.getElementById(btnId);
      if (el) {
        el.onclick = function() { renderFeaturePanel(featureMap[btnId]); };
      }
    });
  }

  // ── FEATURE PANEL (chip-only, no free text) ──
  function renderFeaturePanel(action) {
    currentView = 'feature';

    var titles = {
      companies: 'Target Companies',
      templates: 'Cold Outreach',
      linkedin:  'LinkedIn Optimizer',
      interview: 'Interview Prep'
    };

    var chipLabels = {
      companies: ['Investment Banking', 'Management Consulting', 'VC / PE', 'Marketing', 'Tech / Product'],
      templates: ['Investment Banking', 'Management Consulting', 'VC / PE', 'Marketing', 'Tech / Product'],
      linkedin:  ['Investment Banking', 'Management Consulting', 'VC / PE', 'Marketing', 'Tech / Product'],
      interview: ['Investment Banking', 'Management Consulting', 'VC / PE', 'Marketing', 'Tech / Product']
    };

    panel.innerHTML =
      '<div class="sbot-chat-hdr">' +
        '<button class="sbot-back" id="sb-back">&#x2039; Back</button>' +
        '<div class="sbot-chat-title">' + (titles[action] || '').toUpperCase() + '</div>' +
      '</div>' +
      '<div class="sbot-msgs" id="sb-msgs"></div>';

    document.getElementById('sb-back').onclick = function(){ currentView='home'; renderHome(); };

    var msgsEl = document.getElementById('sb-msgs');

    var intro = uploadedCVText
      ? 'Select your target sector below. Recommendations will be tailored specifically to your uploaded CV, skills, and internships.'
      : 'For highly tailored recommendations, upload your CV via the "Analyze Resume / CV" option first. Select a sector below to proceed:';

    addFeatureChips(msgsEl, intro, chipLabels[action], action);
  }

  function addFeatureChips(msgsEl, introText, chips, action) {
    var d = document.createElement('div'); d.className = 'sbot-msg bot';
    var b = document.createElement('div'); b.className = 'sbot-bub';
    b.innerHTML = introText.replace(/\n/g,'<br>').replace(/\*\*(.*?)\*\*/g,'<b>$1</b>');
    d.appendChild(b);

    var row = document.createElement('div'); row.className = 'sbot-chips';
    chips.forEach(function(label) {
      var ch = document.createElement('div'); ch.className = 'sbot-chip';
      ch.textContent = label;
      ch.onclick = function() {
        // Remove all chips after selection
        row.remove();
        sendFeatureMsg(msgsEl, label, buildFeatureQuery(action, label));
      };
      row.appendChild(ch);
    });
    d.appendChild(row);
    msgsEl.appendChild(d);
    msgsEl.scrollTop = msgsEl.scrollHeight;
  }

  function buildFeatureQuery(action, domain) {
    var cvContext = uploadedCVText ? '\n\nMy CV for reference:\n' + uploadedCVText : '';
    if (action === 'companies') {
      return 'Provide a list of 8-12 specific, realistic target companies in the ' + domain + ' sector that precisely fit my background, skills, and experience. For each company, explain specifically why it fits based on my profile.' + cvContext;
    } else if (action === 'templates') {
      return 'Draft a highly personalized cold outreach email template for the ' + domain + ' sector. The email must reference my specific skills, projects, and internships, not be generic.' + cvContext;
    } else if (action === 'linkedin') {
      return 'Provide a specific, step-by-step LinkedIn profile optimization checklist for the ' + domain + ' sector based on my CV. Quote actual elements of my profile that need to change and show exactly how to rewrite them.' + cvContext;
    } else if (action === 'interview') {
      return 'Generate tailored technical and behavioral interview preparation questions for the ' + domain + ' sector based on my specific background, projects, and internships. Include tactical advice on how to answer each, referencing my actual experience.' + cvContext;
    }
    return '';
  }

  // All AI calls go through the backend, which holds the provider keys in env.
  // (Direct provider calls from the extension are not allowed — they would ship
  // a secret to every user.)
  async function executeAIQuery(history, systemInstruction) {
    var resp = await fetch(API + '/api/ai/cv-chat', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ messages: history, system: systemInstruction })
    });
    var data = await resp.json().catch(function() { return {}; });
    if (!resp.ok) throw new Error(data.error || 'AI request failed');
    return data.reply || '';
  }

  async function sendFeatureMsg(msgsEl, displayText, apiText) {
    if (isLoading) return;
    addBub(msgsEl, 'user', displayText);
    isLoading = true;

    var d = document.createElement('div'); d.className = 'sbot-msg bot'; d.id = 'sb-typing';
    d.innerHTML = '<div class="sbot-bub"><div class="sbot-ty"><div class="sbot-td"></div><div class="sbot-td"></div><div class="sbot-td"></div></div></div>';
    msgsEl.appendChild(d); msgsEl.scrollTop = msgsEl.scrollHeight;

    try {
      var reply = await executeAIQuery([{ role: 'user', content: apiText }], SYSTEM);
      var t = document.getElementById('sb-typing'); if (t) t.remove();
      addBub(msgsEl, 'bot', reply || 'No response received.');
    } catch(e) {
      var t2 = document.getElementById('sb-typing'); if (t2) t2.remove();
      addBub(msgsEl, 'bot', 'AI error: ' + e.message);
    }
    isLoading = false;
  }

  function mkAct(id, title, sub, iconSvg) {
    return '<div class="sbot-act sbot-live" id="' + id + '">' +
             '<div class="sbot-act-ico">' + iconSvg + '</div>' +
             '<div class="sbot-act-txt">' +
               '<div class="sbot-act-t">' + title + '</div>' +
               '<div class="sbot-act-s">' + sub + '</div>' +
             '</div>' +
             '<span class="sbot-arr">&#x203A;</span>' +
           '</div>';
  }

  // ── CV ANALYSIS + GENERAL CHAT ──
  function renderCV(initialQuestion){
    panel.innerHTML =
      '<div class="sbot-chat-hdr">' +
        '<button class="sbot-back" id="sb-back">&#x2039; Back</button>' +
        '<div class="sbot-chat-title">CAREER CO-PILOT</div>' +
      '</div>' +
      '<div class="sbot-msgs" id="sb-msgs"></div>' +
      '<div class="sbot-inp-area">' +
        '<input type="file" id="sb-file" accept=".pdf,.doc,.docx" style="display:none">' +
        '<button class="sbot-upload-btn" id="sb-upload">Upload Resume / CV (PDF)</button>' +
        '<div id="sb-file-name" style="display:none;font-family:var(--mono);font-size:10px;color:#6be82d;padding:4px 12px;background:rgba(143,255,79,0.08);border-radius:6px;margin-bottom:6px;word-break:break-all"></div>' +
        '<div class="sbot-ta-wrap">' +
          '<textarea class="sbot-ta" id="sb-ta" rows="1" placeholder="Type your message here..."></textarea>' +
          '<button class="sbot-send" id="sb-send"><svg width="11" height="11" viewBox="0 0 11 11" fill="none"><path d="M1.5 5.5h8M7 2l3 3.5L7 9" stroke="#ffffff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
        '</div>' +
      '</div>';

    document.getElementById('sb-back').onclick = function(){ currentView='home'; renderHome(); };

    var msgsEl = document.getElementById('sb-msgs');
    convHistory.forEach(function(m){ addBub(msgsEl, m.role==='assistant'?'bot':'user', m._d||m.content); });

    if(convHistory.length===0 && !initialQuestion){
      addBub(msgsEl,'bot',
        'Welcome to the SNDR AI Career Advisor.\n\nUpload your CV for a highly tailored benchmark analysis, or ask me anything about your career transition, target companies, or outreach strategy.',
        ['Investment Banking','Consulting','VC / PE','Marketing','Tech / Product']);
    }

    var ta = document.getElementById('sb-ta');
    var sb = document.getElementById('sb-send');
    if(ta){
      ta.addEventListener('input',function(){ ta.style.height='auto'; ta.style.height=Math.min(ta.scrollHeight,80)+'px'; });
      ta.onkeydown = function(e){ if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();doSend();} };
    }
    if(sb) sb.onclick = doSend;

    // File upload
    var fileBtn = document.getElementById('sb-upload');
    var fileInp = document.getElementById('sb-file');
    if(fileBtn && fileInp){
      fileBtn.onclick = function(){ fileInp.click(); };
      fileInp.onchange = function(e){
        var file = e.target.files[0];
        if(!file) return;
        var nameEl = document.getElementById('sb-file-name');
        if(nameEl){ nameEl.textContent = 'Attached: ' + file.name; nameEl.style.display='block'; }
        fileBtn.textContent = 'Processing CV...';
        fileBtn.disabled = true;
        var formData = new FormData();
        formData.append('cv', file);
        fetch(API + '/api/cv/upload', { method:'POST', body: formData })
          .then(function(r){ return r.json(); })
          .then(function(data){
            if(!data.ok || !data.cvText){
              throw new Error(data.error || 'No text extracted');
            }
            uploadedCVText = data.cvText; // Store globally for all feature panels
            fileBtn.textContent = 'CV Successfully Uploaded';
            fileBtn.style.background = 'rgba(143,255,79,0.1)';
            fileBtn.style.color = '#6be82d';
            fileBtn.style.borderColor = 'rgba(143,255,79,0.3)';
            cvPhase = 'chat';
            var msg = 'I have uploaded my CV (' + file.name + '). Here is the content:\n\n' + data.cvText;
            sendMsg(msg, file.name);
          })
          .catch(function(err){
            fileBtn.textContent = 'Upload Resume / CV (PDF)';
            fileBtn.disabled = false;
            fileBtn.style.background = 'rgba(255,92,92,0.08)';
            fileBtn.style.borderColor = 'rgba(255,92,92,0.3)';
            fileBtn.style.color = '#ff7070';
            setTimeout(function(){
              fileBtn.style.background = '';
              fileBtn.style.borderColor = '';
              fileBtn.style.color = '';
            }, 2000);
            var msgsEl2 = document.getElementById('sb-msgs');
            if(msgsEl2) addBub(msgsEl2,'bot','Upload failed. Please verify that the backend server is operational.');
          });
      };
    }

    // If navigated here from home "Ask a question", auto-send the typed question
    if (initialQuestion) {
      setTimeout(function(){ sendMsg(initialQuestion); }, 80);
    }

    function doSend(){ var v=(document.getElementById('sb-ta')||{}).value||''; v=v.trim(); if(!v||isLoading) return; document.getElementById('sb-ta').value=''; document.getElementById('sb-ta').style.height='auto'; sendMsg(v); }
  }

  function addBub(container, role, text, chips){
    var d=document.createElement('div'); d.className='sbot-msg '+role;
    var b=document.createElement('div'); b.className='sbot-bub';
    b.innerHTML=text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>').replace(/\*\*(.*?)\*\*/g,'<b>$1</b>');
    d.appendChild(b);
    if(chips&&chips.length){
      var row=document.createElement('div'); row.className='sbot-chips';
      chips.forEach(function(c){ var ch=document.createElement('div'); ch.className='sbot-chip'; ch.textContent=c; ch.onclick=function(){ sendMsg(c); }; row.appendChild(ch); });
      d.appendChild(row);
    }
    container.appendChild(d); container.scrollTop=container.scrollHeight;
  }

  function addTyping(){
    var msgsEl=document.getElementById('sb-msgs'); if(!msgsEl) return;
    var d=document.createElement('div'); d.className='sbot-msg bot'; d.id='sb-typing';
    d.innerHTML='<div class="sbot-bub"><div class="sbot-ty"><div class="sbot-td"></div><div class="sbot-td"></div><div class="sbot-td"></div></div></div>';
    msgsEl.appendChild(d); msgsEl.scrollTop=msgsEl.scrollHeight;
  }

  async function callAI(history){
    return await executeAIQuery(history, SYSTEM);
  }

  async function sendMsg(text, displayName){
    if(!text||isLoading) return;
    var apiText = text;

    // If this is a CV upload (long text), trigger deep tailored analysis
    if(text.length > 100 && (cvPhase === 'cv' || cvPhase === 'role')){
      cvPhase = 'chat';
      apiText = 'Here is my CV:\n\n' + text + '\n\nPlease conduct a highly specific and tailored benchmark analysis of my profile. Do not provide generic resume advice. Identify at least 2-3 specific bullet points/pointers from my CV that need improvement, explain exactly what is weak about them, and provide specific, redrafted versions of those pointers that show quantified impact or better phrasing.';
    }

    // For freeform questions, append CV context if available and not already included
    if (uploadedCVText && text.length < 500 && apiText.indexOf(uploadedCVText) === -1) {
      apiText = apiText + '\n\n[My CV for context]:\n' + uploadedCVText;
    }

    var msgsEl = document.getElementById('sb-msgs'); if(!msgsEl) return;
    var displayText = displayName ? 'CV Uploaded: ' + displayName : text;
    addBub(msgsEl,'user',displayText);
    convHistory.push({role:'user',content:apiText,_d:displayText});
    isLoading=true; addTyping();
    var sb=document.getElementById('sb-send'); if(sb) sb.disabled=true;
    try{
      var history=convHistory.map(function(m){return{role:m.role,content:m.content};});
      var reply=await callAI(history);
      var t=document.getElementById('sb-typing'); if(t) t.remove();
      convHistory.push({role:'assistant',content:reply,_d:reply});
      var msgsEl2=document.getElementById('sb-msgs');
      if(msgsEl2) addBub(msgsEl2,'bot',reply);
      if(cvPhase==='role') cvPhase='cv';
    }catch(e){
      var t2=document.getElementById('sb-typing'); if(t2) t2.remove();
      var msgsEl3=document.getElementById('sb-msgs');
      if(msgsEl3) addBub(msgsEl3,'bot','AI error: ' + e.message);
    }
    isLoading=false;
    var sb2=document.getElementById('sb-send'); if(sb2) sb2.disabled=false;
  }

  function showToast(msg){
    var t=document.getElementById('sb-toast'); if(!t) return;
    t.innerHTML=msg; t.classList.add('show');
    setTimeout(function(){ t.classList.remove('show'); },2500);
  }

})();