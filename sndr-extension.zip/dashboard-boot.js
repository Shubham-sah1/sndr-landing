// dashboard-boot.js — runs in <head> BEFORE the body paints.
// MV3's CSP (script-src 'self') blocks inline scripts on extension pages, so this
// boot logic lives in an external file. It sets the initial show/hide of the app
// vs the login overlay and handles the font-ready class.
//
// We can't read chrome.storage synchronously here, so we gate optimistically on a
// localStorage hint that dashboard.js writes whenever it confirms (or clears) a
// real session. dashboard.js's setAuthVisibility() then corrects this the moment
// the real chrome.storage session is read. Net effect: a returning logged-in user
// sees the app immediately (no hide-then-show flash); a logged-out user sees the
// login overlay (no dashboard flash).
(function () {
  // Apply the saved theme BEFORE the body paints so dark-mode users never see a
  // white flash. dashboard.js re-syncs the toggle icon once it loads.
  try {
    if (localStorage.getItem('sndr_theme') === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
    }
  } catch (e) {}

  var urlParams = new URLSearchParams(window.location.search);
  var isAuthView = urlParams.get('view') === 'forgot' || urlParams.get('view') === 'reset';

  // Three states, decided from the localStorage hint that dashboard.js maintains:
  //   '1'      -> logged in: show the app immediately (cache paints fill it).
  //   '0'      -> known logged out: show the login overlay.
  //   unknown  -> show NOTHING (blank page) until the real chrome.storage session
  //               check resolves in dashboard.js. The old two-state gate defaulted
  //               to the login overlay here — which flashed the login screen for a
  //               second on every refresh where the hint wasn't readable.
  var hint = null;
  try { hint = localStorage.getItem('sndr_has_session'); } catch (e) {}

  var style = document.createElement('style');
  style.id = 'sync-auth-styles';
  if (!isAuthView && hint === '1') {
    style.innerHTML = '.layout { display: flex !important; } #auth-overlay { display: none !important; }';
  } else if (isAuthView || hint === '0') {
    style.innerHTML = '.layout { display: none !important; } #auth-overlay { display: flex !important; }';
  } else {
    style.innerHTML = '.layout { display: none !important; } #auth-overlay { display: none !important; }';
  }
  document.documentElement.appendChild(style);

  // Reveal text once fonts are ready, with a hard fallback so we never wait long.
  var fontsTimeout = setTimeout(function () {
    document.documentElement.classList.add('fonts-loaded');
  }, 1500);

  function markFontsLoaded() {
    clearTimeout(fontsTimeout);
    document.documentElement.classList.add('fonts-loaded');
  }

  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(markFontsLoaded).catch(markFontsLoaded);
  } else {
    markFontsLoaded();
  }
})();
