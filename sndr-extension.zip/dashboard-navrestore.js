// dashboard-navrestore.js — restores the last active tab's title and sidebar
// highlight synchronously, before dashboard.js runs, to prevent the header/sidebar
// flashing "Overview" then jumping to the real tab. External (not inline) because
// MV3's CSP blocks inline scripts on extension pages. Must load AFTER the sidebar
// + topbar markup exists (it's placed right after them in the body).
(function () {
  var saved = localStorage.getItem('sndr_active_nav') || 'overview';
  if (!saved) return;

  var titleMap = {
    overview: 'Overview',
    timing: 'Best Time',
    contacts: 'Contacts',
    campaigns: 'Campaigns',
    compose: 'New Campaign',
    settings: 'Settings',
    find: 'Find Emails'
  };

  var t = document.getElementById('tb-title');
  if (t) t.textContent = titleMap[saved] || saved;

  document.querySelectorAll('.ni').forEach(function (n) {
    if (n.dataset.nav === saved) n.classList.add('active');
    else n.classList.remove('active');
  });
})();
