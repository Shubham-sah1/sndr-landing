// ── Constants & Globals ──────────────────────────────────────
// HTML-escape dynamic (server/user/scraped) data before interpolating into innerHTML.
function escHtml(s){ return String(s==null?'':s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

// localStorage.setItem can THROW (quota full — easy to hit when caching hundreds
// of contacts — or privacy mode). A failed cache write must never abort the
// render that follows it: an unwrapped throw skipped renderContactsList /
// renderCampaignsList on EVERY poll and permanently froze the page mid-send.
// Caching is an optimization; rendering is the product. Never let one kill the other.
function safeSetItem(key, value) {
  try { safeSetItem(key, value); } catch (e) {}
}

var API_URL = window.location.hostname === 'localhost' ? window.location.origin : 'https://sndr-f4rg.onrender.com';
var titles = {
  overview: 'Overview',
  timing: 'Best Time',
  contacts: 'Contacts',
  campaigns: 'Campaigns',
  compose: 'New Campaign',
  settings: 'Settings',
  find: 'Find Emails'
};

var activeAccount = null;
var campaignsList = [];
var globalSelectedCampaignId = 'all';
var globalSelectedPeriod = '7'; // '7' | '30' | 'all' — matches the default-active 7D pill

// Build the dashboard-stats query string from the active campaign + period filters.
// Minutes to ADD to UTC to get the user's local time (IST = +330). Sent so the
// backend buckets hour/day analytics by the user's local clock, not UTC.
function tzOffsetParam() {
  try { return 'tz=' + (-new Date().getTimezoneOffset()); } catch (e) { return 'tz=0'; }
}

function statsQuery() {
  var p = [tzOffsetParam()];
  if (globalSelectedCampaignId && globalSelectedCampaignId !== 'all') p.push('campaign_id=' + encodeURIComponent(globalSelectedCampaignId));
  if (globalSelectedPeriod && globalSelectedPeriod !== 'all') p.push('days=' + encodeURIComponent(globalSelectedPeriod));
  return '?' + p.join('&');
}

// Same as statsQuery() but for an explicit campaign/period (used by prewarm).
function statsQueryFor(campaignId, period) {
  var p = [tzOffsetParam()];
  if (campaignId && campaignId !== 'all') p.push('campaign_id=' + encodeURIComponent(campaignId));
  if (period && period !== 'all') p.push('days=' + encodeURIComponent(period));
  return '?' + p.join('&');
}

// Warm the "all campaigns" contacts cache in the background on boot, so opening
// the Contacts tab renders instantly from cache instead of waiting 4-5s on the
// per-campaign network fetches. Runs once per boot; failures are silent.
function prefetchContactsCache() {
  if (!activeAccount || window._contactsPrefetched) return;
  window._contactsPrefetched = true;
  var acctId = activeAccount.id;
  // One request via the all-contacts endpoint. On failure just skip warming —
  // never cache a partial list (it painted rows that then "flickered" back).
  apiCall('GET', '/campaigns/all-contacts?account_id=' + acctId).then(function(rows) {
    var list = (rows || []).map(function(ci) { return { ...ci, campaignName: ci.campaign_name || '' }; });
    try {
      safeSetItem('sndr_cached_contacts_' + acctId + '_all', JSON.stringify(list));
      safeSetItem('sndr_cached_overview_contacts', JSON.stringify(list));
    } catch (e) {}
  }).catch(function() {});
}

// Fetch the other period variants (7D/30D/All) for the current campaign in the
// background and cache them, so switching the period pill is instant the first
// time too (no 2-3s network wait). Only fetches combinations not already cached.
function prewarmPeriodCaches(campaignId) {
  if (!activeAccount) return;
  ['7', '30', 'all'].forEach(function(period) {
    if (period === globalSelectedPeriod) return; // current one was just fetched
    var key = 'sndr_cached_stats_' + activeAccount.id + '_' + campaignId + '_' + period;
    if (localStorage.getItem(key)) return; // already warm
    var url = '/auth/accounts/' + activeAccount.id + '/dashboard-stats' + statsQueryFor(campaignId, period);
    apiCall('GET', url).then(function(s) {
      try { safeSetItem(key, JSON.stringify(s)); } catch (e) {}
    }).catch(function() {});
  });
}

// Best display name for greetings/sidebar: prefer the connected Gmail account's
// name (the name linked to the mail) over the login username / email-prefix.
function bestDisplayName(session) {
  try {
    var ca = JSON.parse(localStorage.getItem('sndr_cached_accounts') || 'null');
    if (ca && ca[0] && ca[0].name) return ca[0].name;
  } catch (e) {}
  if (session && session.username) return session.username;
  if (session && session.email) return session.email.split('@')[0];
  return 'User';
}
var sidebarInitialized = false;

function getEmptyStats() {
  return {
    funnel: { total: 0, pending: 0, sent: 0, delivered: 0, opened: 0, replied: 0, bounced: 0 },
    timeToOpen: { within1h: 0, within6h: 0, within24h: 0, after24h: 0 },
    engagementOverTime: [
      { label: 'Mon', openRate: 0, replyRate: 0 },
      { label: 'Tue', openRate: 0, replyRate: 0 },
      { label: 'Wed', openRate: 0, replyRate: 0 },
      { label: 'Thu', openRate: 0, replyRate: 0 },
      { label: 'Fri', openRate: 0, replyRate: 0 },
      { label: 'Sat', openRate: 0, replyRate: 0 },
      { label: 'Sun', openRate: 0, replyRate: 0 }
    ],
    heatmap: [
      [0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0]
    ],
    openRateByDay: [0, 0, 0, 0, 0, 0, 0],
    openRateByHour: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    topCompanies: [],
    followupStats: {
      initial: [0, 0, 0, 0, 0, 0, 0],
      followup: [0, 0, 0, 0, 0, 0, 0]
    },
    usage: { todaySends: 0, dailyLimit: 500 }
  };
}

// Authoritative show/hide of the app vs the login overlay. The inline boot script
// in dashboard.html sets a `#sync-auth-styles` rule with `!important` based on a
// localStorage session — but login only stores the session in chrome.storage, so a
// fresh user's localStorage is empty and the layout stays hidden behind the login
// overlay on every refresh. Rewriting that same style element (so the !important
// rule is overridden) is the only reliable way to reveal the app. Call this once we
// truly know the auth state (from chrome.storage), not from the localStorage proxy.
function setAuthVisibility(isLoggedIn) {
  try {
    // Persist the last-known auth state so dashboard-boot.js can gate the very first
    // paint correctly on the next load (it can't read chrome.storage synchronously).
    safeSetItem('sndr_has_session', isLoggedIn ? '1' : '0');
  } catch (e) {}
  try {
    var s = document.getElementById('sync-auth-styles');
    if (!s) {
      s = document.createElement('style');
      s.id = 'sync-auth-styles';
      document.documentElement.appendChild(s);
    }
    s.innerHTML = isLoggedIn
      ? '.layout{display:flex !important} #auth-overlay{display:none !important}'
      : '.layout{display:none !important} #auth-overlay{display:flex !important}';
  } catch (e) {}
}

// Clear cached stats (and optionally contacts) after a mutating action so the
// dashboard doesn't keep painting stale funnel/usage/contact numbers cache-first.
function invalidateStatsCache(opts) {
  opts = opts || {};
  try {
    if (!activeAccount) return;
    var statsPrefix = 'sndr_cached_stats_' + activeAccount.id + '_';
    var contactsPrefix = 'sndr_cached_contacts_' + activeAccount.id + '_';
    var toRemove = [];
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (!k) continue;
      if (k.indexOf(statsPrefix) === 0) toRemove.push(k);
      if (opts.contacts && k.indexOf(contactsPrefix) === 0) toRemove.push(k);
    }
    toRemove.forEach(function(k) { localStorage.removeItem(k); });
    localStorage.removeItem('sndr_cached_overview_stats');
    if (opts.contacts) localStorage.removeItem('sndr_cached_overview_contacts');
    // Force the next render to repaint instead of short-circuiting on the dedupe.
    window._lastOverviewDataString = null;
    window._lastTimingDataString = null;
    if (opts.contacts) window._lastContactsDataString = null;
  } catch (e) {}
}

function reportClientError(err, context) {
  console.error('[reportClientError]', err, context);
  var body = {
    message: err ? (err.message || String(err)) : 'Unknown Error',
    stack: err ? (err.stack || '') : '',
    context: context || '',
    url: window.location.href,
    userAgent: navigator.userAgent,
    chartType: typeof window.Chart
  };
  fetch(API_URL + '/api/debug-log', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  }).catch(function(e) {
    console.error('Failed to report client error:', e);
  });
}

window.addEventListener('error', function(e) {
  reportClientError(e.error || { message: e.message }, 'window.onerror');
});
window.addEventListener('unhandledrejection', function(e) {
  reportClientError(e.reason, 'window.onunhandledrejection');
});

// Does this account have live Gmail credentials? `connected` arrived in backend
// 2.3.x — treat a missing flag (older backend / stale cache) as connected so we
// never wrongly lock out a working account.
function isAccountConnected(acc) {
  if (!acc) return false;
  if (acc.connected === undefined || acc.connected === null) return true;
  return acc.connected === true || Number(acc.connected) === 1;
}

// Update a campaign <select> WITHOUT rebuilding it when nothing changed. The
// old cache-paint paths rewrote select.innerHTML on every 8s poll, which
// snapped the dropdown shut mid-interaction and flashed the control — one of
// the "extension looks broken" glitches during sends.
function updateCampaignSelect(selectId, campaigns, allLabel) {
  var select = document.getElementById(selectId);
  if (!select) return;
  campaigns = campaigns || [];
  var changed = select.options.length !== campaigns.length + 1;
  if (!changed) {
    for (var i = 0; i < campaigns.length; i++) {
      if (select.options[i + 1].value !== String(campaigns[i].id) || select.options[i + 1].textContent !== campaigns[i].name) {
        changed = true;
        break;
      }
    }
  }
  if (changed) {
    select.innerHTML = '<option value="all">' + escHtml(allLabel || 'All Campaigns') + '</option>';
    campaigns.forEach(function(c) {
      var opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.name;
      select.appendChild(opt);
    });
  }
  if (select.value !== globalSelectedCampaignId) select.value = globalSelectedCampaignId;
}

// Ask the backend to sweep for replies — at most once every 2 minutes across all
// triggers. The backend already runs this sweep on a 1-minute cron, so extra
// client-triggered sweeps on every tab switch only piled Gmail API load onto the
// server (slowing sends and polls). Throttled + fire-and-forget.
function maybeSyncReplies(onDetected) {
  try {
    var last = Number(localStorage.getItem('sndr_last_sync_replies') || 0);
    if (Date.now() - last < 120000) return;
    safeSetItem('sndr_last_sync_replies', String(Date.now()));
  } catch (e) {}
  apiCall('POST', '/campaigns/sync-replies')
    .then(function(res) {
      if (res && res.detected > 0 && typeof onDetected === 'function') onDetected();
    })
    .catch(function() {});
}

// Run a screen's loader behind a held-frame dim: the current content fades to
// 50%, every repaint (cache paint, network paint, tiles, charts, heatmap)
// happens behind the dim, and the finished state is revealed in ONE go. Used
// for the first load after login, every tab switch, and every filter change —
// so numbers and graphs always land together instead of trickling in.
function withScreenReveal(screen, loaderFn) {
  if (!screen) return;
  window._filterRefreshSeq = (window._filterRefreshSeq || 0) + 1;
  var seq = window._filterRefreshSeq;
  screen.classList.add('filter-refreshing');
  var done = function() {
    // Only the LATEST cycle may undim (rapid clicks each start a new cycle).
    if (seq === window._filterRefreshSeq) screen.classList.remove('filter-refreshing');
  };
  // Safety reveal: never hold the dim longer than 8s (cold backend) — data that
  // arrives later still paints normally, just undimmed.
  setTimeout(done, 8000);
  var p;
  try { p = loaderFn(); } catch (e) { done(); return; }
  Promise.resolve(p).then(done, done);
}

// Refresh the active screen after a filter change (period pill / campaign select).
function refreshActiveScreenForFilters() {
  var screen = document.querySelector('.screen.on');
  if (!screen) return;
  withScreenReveal(screen, function() {
    if (screen.id === 'screen-overview') return loadOverview(true, false);
    if (screen.id === 'screen-timing') return loadTiming(false);
    if (screen.id === 'screen-contacts') return loadContacts(true, false, false);
  });
}

function syncCampaignSelection(val) {
  globalSelectedCampaignId = val;
  ['overview-campaign-select', 'timing-campaign-select', 'contacts-campaign-select'].forEach(function(id) {
    var sel = document.getElementById(id);
    if (sel) {
      sel.value = val;
    }
  });
  refreshActiveScreenForFilters();
}

// ── API Helper ──────────────────────────────────────────────
async function apiCall(method, path, body, isFormData) {
  var token = null;
  if (typeof chrome !== 'undefined' && chrome.storage) {
    token = await new Promise(function(resolve) {
      chrome.storage.local.get(['session'], function(data) {
        resolve(data.session ? data.session.token : null);
      });
    });
  } else {
    var sess = localStorage.getItem('sndr_session');
    if (sess) {
      token = JSON.parse(sess).token;
    }
  }

  var headers = {};
  if (token) {
    headers['Authorization'] = 'Bearer ' + token;
  }

  var opts = { method: method, headers: headers };
  if (body) {
    if (isFormData) {
      opts.body = body;
    } else {
      headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
  }

  // Hard 60s cap on every request. Without it, one connection held open by a
  // busy/cold backend wedged the SERIALIZED poll loop for minutes — the whole
  // dashboard froze and looked dead. An abort is just a failed poll: every
  // caller keeps the current data and the next 8s tick retries.
  var _ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
  var _tmo = null;
  if (_ctrl) {
    opts.signal = _ctrl.signal;
    _tmo = setTimeout(function() { try { _ctrl.abort(); } catch (e) {} }, 60000);
  }

  var res;
  try {
    res = await fetch(API_URL + path, opts);
  } catch (e) {
    if (_tmo) clearTimeout(_tmo);
    throw (e && e.name === 'AbortError') ? new Error('Request timed out') : e;
  }
  if (_tmo) clearTimeout(_tmo);
  if (res.status === 401 || res.status === 403) {
    localStorage.removeItem('sndr_session');
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.remove(['session'], function() {
        window.location.reload();
      });
    } else {
      window.location.reload();
    }
    throw new Error('Unauthorized');
  }
  if (!res.ok) {
    var err = await res.json().catch(function() { return { error: res.statusText }; });
    throw new Error(err.error || res.statusText);
  }
  return res.json();
}

// ── Toast Notification Helper ───────────────────────────────
function showToast(msg, isError) {
  var toast = document.createElement('div');
  toast.style.position = 'fixed';
  toast.style.bottom = '24px';
  toast.style.left = '50%';
  toast.style.transform = 'translateX(-50%)';
  toast.style.background = isError ? '#ef4444' : '#0058be';
  toast.style.color = '#fff';
  toast.style.padding = '10px 24px';
  toast.style.borderRadius = '99px';
  toast.style.fontSize = '13px';
  toast.style.fontWeight = '700';
  toast.style.zIndex = '99999';
  toast.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
  toast.textContent = msg;

  if (msg === 'No active Gmail account connected.') {
    toast.style.cursor = 'pointer';
    toast.title = 'Click to go connect your account';
    toast.addEventListener('click', function() {
      goNav('settings');
      toast.remove();
    });
  }

  document.body.appendChild(toast);
  setTimeout(function() {
    if (toast.parentNode) {
      toast.style.transition = 'opacity 0.5s';
      toast.style.opacity = '0';
      setTimeout(function() { if (toast.parentNode) toast.remove(); }, 500);
    }
  }, 3500);
}

// ── Navigation ────────────────────────────────────────────────
function goNav(name) {
  var tempStyle = document.getElementById('sync-nav-css');
  if (tempStyle) tempStyle.remove();

  safeSetItem('sndr_active_nav', name);
  document.querySelectorAll('.screen').forEach(function(s) { s.classList.remove('on'); });
  document.querySelectorAll('.ni').forEach(function(n) { n.classList.remove('active'); });
  var sc = document.getElementById('screen-' + name); if (sc) sc.classList.add('on');
  document.querySelectorAll('[data-nav="' + name + '"]').forEach(function(n) { n.classList.add('active'); });
  var t = document.getElementById('tb-title'); if (t) t.textContent = titles[name] || name;

  // Data screens: the FIRST visit after login loads behind the held-frame dim
  // (numbers, tiles, and charts land together in one reveal). Every later visit
  // switches instantly — cached content paints at once and refreshes silently.
  window._screenRevealed = window._screenRevealed || {};
  var _isData = (name === 'overview' || name === 'timing' || name === 'contacts' || name === 'campaigns');
  if (_isData) {
    var _sc = document.getElementById('screen-' + name);
    var _loader = function() {
      if (name === 'overview') return loadOverview();
      if (name === 'timing') return loadTiming();
      if (name === 'contacts') return loadContacts();
      return loadCampaigns();
    };
    if (!window._screenRevealed[name]) {
      window._screenRevealed[name] = true;
      withScreenReveal(_sc, _loader);
    } else {
      _loader();
    }
  }
  if (name === 'compose') {
    if (localStorage.getItem('sndr_compose_state')) {
      restoreComposeState();
    } else {
      resetComposeWizard();
    }
  }
  if (name === 'settings') { loadSettings(); }
  if (name === 'find') { _finding = false; loadFindScreen(); }
}

document.querySelectorAll('[data-nav]').forEach(function(el) {
  el.addEventListener('click', function() { goNav(el.dataset.nav); });
});
var tbNewBtn = document.getElementById('tb-new-btn');
if (tbNewBtn) {
  tbNewBtn.addEventListener('click', function() {
    if (typeof window.clearComposeState === 'function') {
      window.clearComposeState();
    }
    resetComposeWizard();
    goNav('compose');
  });
}

// ── Dark mode toggle ──────────────────────────────────────────────────────────
// dashboard-boot.js already set data-theme before paint; here we just keep the
// toggle icon in sync and persist the user's choice. Re-themes the whole app via
// the CSS tokens, so campaign manager / contacts / review all flip together.
function applyTheme(theme) {
  if (theme === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
  else document.documentElement.removeAttribute('data-theme');
  var icon = document.getElementById('theme-toggle-icon');
  if (icon) icon.textContent = theme === 'dark' ? 'light_mode' : 'dark_mode';
}
(function setupThemeToggle() {
  var saved = 'light';
  try { if (localStorage.getItem('sndr_theme') === 'dark') saved = 'dark'; } catch (e) {}
  applyTheme(saved);
  var btn = document.getElementById('theme-toggle');
  if (btn) {
    btn.addEventListener('click', function() {
      var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      try { safeSetItem('sndr_theme', next); } catch (e) {}
      applyTheme(next);
      rerenderChartsForTheme();
    });
  }
})();

// Charts draw to <canvas>, so their colours don't follow the CSS theme tokens.
// On a theme switch, bust the render dedupe guards and re-render the active
// screen so its charts are rebuilt with the new palette immediately.
function rerenderChartsForTheme() {
  window._lastCampaignsDataString = null;
  window._lastOverviewDataString = null;
  window._lastTimingDataString = null;
  var active = document.querySelector('.screen.on');
  if (!active) return;
  try {
    if (active.id === 'screen-campaigns') loadCampaigns(true);
    else if (active.id === 'screen-overview') loadOverview(true);
    else if (active.id === 'screen-timing') loadTiming();
  } catch (e) {}
}

// ── Period pills ──────────────────────────────────────────────
document.querySelectorAll('.period-btn').forEach(function(btn) {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.period-btn').forEach(function(b) { b.classList.remove('on'); });
    btn.classList.add('on');
    var range = btn.getAttribute('data-range');
    globalSelectedPeriod = (range === '30d') ? '30' : (range === 'all') ? 'all' : '7';
    // One smooth transition: dim, repaint everything behind it, reveal once.
    refreshActiveScreenForFilters();
  });
});

// ── Step nav (compose wizard) ─────────────────────────────────
function goStep(n) {
  window.currentComposeStep = n;
  if (typeof window.saveComposeState === 'function') {
    window.saveComposeState();
  }
  ['upload', 'map', 'compose', 'schedule', 'review'].forEach(function(s, i) {
    var el = document.getElementById('step-' + s);
    if (el) el.style.display = (i === n - 1) ? 'block' : 'none';
  });
  for (var i = 1; i <= 5; i++) {
    var e = document.getElementById('step' + i); if (!e) continue;
    e.classList.remove('active', 'done');
    if (i < n) e.classList.add('done'); else if (i === n) e.classList.add('active');
  }
  document.querySelectorAll('.step-line').forEach(function(l, i) {
    l.classList.toggle('done-line', i < n - 1);
  });

  if (n === 3) {
    if (typeof loadTemplatesList === 'function') {
      loadTemplatesList();
    }
    if (typeof updateLivePreview === 'function') {
      updateLivePreview();
    }
  }

  if (n === 5) {
    updateReviewStepSummary();
  }
}

document.querySelectorAll('[data-step]').forEach(function(el) {
  el.addEventListener('click', function() { goStep(parseInt(el.dataset.step)); });
});

document.querySelectorAll('.sched-card').forEach(function(el) {
  el.addEventListener('click', function() {
    document.querySelectorAll('.sched-card').forEach(function(c) { c.classList.remove('sel'); });
    el.classList.add('sel');
    var pk = document.getElementById('sched-picker');
    if (pk) pk.style.display = el.id === 'sched-later' ? 'block' : 'none';
  });
});

document.querySelectorAll('.sw').forEach(function(sw) {
  sw.addEventListener('click', function() { sw.classList.toggle('on'); });
});

// ── Status classes ──────────────────────────────────────────
function statusDot(s) { return { sending: 'dot-live', paused: 'dot-paused', draft: 'dot-draft', scheduled: 'dot-paused', sent: 'dot-done' }[s] || 'dot-done'; }
function statusBadge(s) { return { sending: '<span class="badge b-green">Live</span>', paused: '<span class="badge b-amber">Paused</span>', draft: '<span class="badge b-grey">Draft</span>', scheduled: '<span class="badge b-amber">Scheduled</span>', sent: '<span class="badge b-blue">Done</span>' }[s] || ''; }
// AI-classified reply category -> coloured pill. Returns '' for unknown/absent.
function replyCategoryBadge(cat) {
  var map = {
    interested:     ['Interested',     '#16a34a', 'rgba(22,163,74,0.14)'],
    question:       ['Question',       '#4f46e5', 'rgba(79,70,229,0.14)'],
    not_interested: ['Not interested', '#64748b', 'rgba(100,116,139,0.16)'],
    out_of_office:  ['Out of office',  '#b45309', 'rgba(180,83,9,0.14)'],
    unsubscribe:    ['Unsubscribe',    '#dc2626', 'rgba(220,38,38,0.14)'],
    auto_reply:     ['Auto-reply',     '#64748b', 'rgba(100,116,139,0.16)'],
    other:          ['Other',          '#64748b', 'rgba(100,116,139,0.16)']
  };
  var m = map[cat]; if (!m) return '';
  return '<span style="display:inline-block;font-size:9.5px;font-weight:700;color:' + m[1] + ';background:' + m[2] + ';padding:1px 7px;border-radius:6px;margin-top:3px">' + m[0] + '</span>';
}

// ── Sidebar Info & Usage ─────────────────────────────────────

async function loadSidebar(showToastIfMissing) {
  var oldAccountId = activeAccount ? activeAccount.id : null;
  try {
    showToastIfMissing = !!showToastIfMissing;

    // Synchronous instant paint of the user identity from cache, BEFORE the async
    // session read — avoids the 1-2s "Loading / Gmail not connected" flash on reload.
    // Prefer the Gmail account name (the name linked with the mail).
    try {
      var _ca = localStorage.getItem('sndr_cached_accounts');
      if (_ca) {
        var _accs = JSON.parse(_ca);
        if (_accs && _accs[0]) {
          var _dn = _accs[0].name || (_accs[0].email ? _accs[0].email.split('@')[0] : 'User');
          var _n = document.getElementById('u-name'); if (_n) _n.textContent = _dn;
          var _e = document.getElementById('u-email'); if (_e && _accs[0].email) _e.textContent = _accs[0].email;
          var _a = document.getElementById('u-av'); if (_a) _a.textContent = (_dn.substring(0, 2) || 'U').toUpperCase();
          document.querySelectorAll('.user-greeting-name').forEach(function(el) { el.textContent = _dn; });
        }
      }
    } catch (e) {}

    var session = null;
    if (typeof chrome !== 'undefined' && chrome.storage) {
      session = await new Promise(function(resolve) {
        chrome.storage.local.get(['session'], function(data) {
          resolve(data.session || null);
        });
      });
      // Token is stored only in chrome.storage.local (source of truth).
      // Purge any legacy localStorage copy of the session token.
      localStorage.removeItem('sndr_session');
    } else {
      var sess = localStorage.getItem('sndr_session');
      if (sess) {
        try { session = JSON.parse(sess); } catch(e) {}
      }
    }

    // Try to load cached data for sidebar immediately to prevent flashing placeholder values
    try {
      var cachedAccounts = localStorage.getItem('sndr_cached_accounts');
      if (cachedAccounts) {
        var accounts = JSON.parse(cachedAccounts);
        if (accounts && accounts.length > 0) {
          activeAccount = accounts[0];
          var displayName = activeAccount.name || (session && session.username) || activeAccount.email.split('@')[0];
          var nameEl = document.getElementById('u-name');
          var emailEl = document.getElementById('u-email');
          var avEl = document.getElementById('u-av');
          if (nameEl) nameEl.textContent = displayName;
          if (emailEl) emailEl.textContent = activeAccount.email;
          if (avEl) {
            avEl.textContent = displayName.substring(0, 2).toUpperCase() || 'G';
          }
          var greetingNameEls = document.querySelectorAll('.user-greeting-name');
          greetingNameEls.forEach(function(el) {
            el.textContent = displayName;
          });

          var cachedUsage = localStorage.getItem('sndr_cached_usage_' + activeAccount.id);
          if (cachedUsage) {
            var usage = JSON.parse(cachedUsage);
            var used = usage.todaySends || 0;
            var limit = usage.dailyLimit || 500;
            var pct = Math.min(100, Math.round((used / limit) * 100));
            var fillEl = document.getElementById('sb-usage-fill');
            var labelEl = document.getElementById('sb-usage-label');
            if (fillEl) {
              fillEl.style.width = pct + '%';
              fillEl.style.background = used / limit > 0.9 ? 'var(--red)' : used / limit > 0.7 ? 'var(--amber)' : 'var(--p)';
            }
            if (labelEl) {
              labelEl.textContent = used + ' / ' + limit + ' Usage (Daily)';
            }
          }
        }
      }
    } catch (e) {}

    // Update oldAccountId to capture the cached account if it was loaded
    oldAccountId = activeAccount ? activeAccount.id : null;

    if (!session) {
      localStorage.removeItem('sndr_session');
      setAuthVisibility(false);
      return;
    } else {
      setAuthVisibility(true);
    }

    var nameEl = document.getElementById('u-name');
    var emailEl = document.getElementById('u-email');
    var avEl = document.getElementById('u-av');

    var welcomeName = bestDisplayName(session);

    var greetingNameEls = document.querySelectorAll('.user-greeting-name');
    greetingNameEls.forEach(function(el) {
      el.textContent = welcomeName;
    });

    if (session && session.username) {
      if (nameEl && nameEl.textContent === 'Loading...') nameEl.textContent = session.username;
      if (emailEl && emailEl.textContent === 'Gmail not connected') emailEl.textContent = 'Gmail not connected';
      if (avEl && avEl.textContent === '--') {
        var initials = session.username.substring(0, 2).toUpperCase();
        avEl.textContent = initials || 'U';
      }
    } else if (session && session.email) {
      if (nameEl && nameEl.textContent === 'Loading...') nameEl.textContent = session.email.split('@')[0];
      if (emailEl && emailEl.textContent === 'Gmail not connected') emailEl.textContent = 'Gmail not connected';
      if (avEl && avEl.textContent === '--') {
        var initials = session.email.split('@')[0].substring(0, 2).toUpperCase();
        avEl.textContent = initials || 'U';
      }
    }

    var accounts = await apiCall('GET', '/auth/accounts');
    sidebarInitialized = true;
    if (accounts && accounts.length > 0) {
      safeSetItem('sndr_cached_accounts', JSON.stringify(accounts));
      activeAccount = accounts[0];
      var displayName = activeAccount.name || session.username || activeAccount.email.split('@')[0];
      if (nameEl) nameEl.textContent = displayName;
      if (emailEl) emailEl.textContent = activeAccount.email;
      if (avEl) {
        var initials = displayName.substring(0, 2).toUpperCase();
        avEl.textContent = initials || 'G';
      }

      var greetingNameEls = document.querySelectorAll('.user-greeting-name');
      greetingNameEls.forEach(function(el) {
        el.textContent = displayName;
      });

      var usage = await apiCall('GET', '/auth/accounts/' + activeAccount.id + '/usage');
      if (usage) {
        safeSetItem('sndr_cached_usage_' + activeAccount.id, JSON.stringify(usage));
        var used = usage.todaySends || 0;
        var limit = usage.dailyLimit || 500;
        var pct = Math.min(100, Math.round((used / limit) * 100));

        var fillEl = document.getElementById('sb-usage-fill');
        var labelEl = document.getElementById('sb-usage-label');
        if (fillEl) {
          fillEl.style.width = pct + '%';
          fillEl.style.background = used / limit > 0.9 ? 'var(--red)' : used / limit > 0.7 ? 'var(--amber)' : 'var(--p)';
        }
        if (labelEl) {
          labelEl.textContent = used + ' / ' + limit + ' Usage (Daily)';
        }
      }
    } else {
      activeAccount = null;
      localStorage.removeItem('sndr_cached_accounts');
      if (session && session.username) {
        if (nameEl) nameEl.textContent = session.username;
        if (emailEl) emailEl.textContent = 'Gmail not connected';
        if (avEl) {
          var initials = session.username.substring(0, 2).toUpperCase();
          avEl.textContent = initials || 'U';
        }
      } else if (session && session.email) {
        if (nameEl) nameEl.textContent = session.email.split('@')[0];
        if (emailEl) emailEl.textContent = 'Gmail not connected';
        if (avEl) {
          var initials = session.email.split('@')[0].substring(0, 2).toUpperCase();
          avEl.textContent = initials || 'U';
        }
      }
      var fillEl = document.getElementById('sb-usage-fill');
      var labelEl = document.getElementById('sb-usage-label');
      if (fillEl) fillEl.style.width = '0%';
      if (labelEl) labelEl.textContent = '0 / 0 Usage (Daily)';
      if (showToastIfMissing) {
        showToast('No active Gmail account connected.', true);
      }
    }

    var newAccountId = activeAccount ? activeAccount.id : null;
    if (oldAccountId !== newAccountId) {
      // Reload the active screen to keep the UI in sync
      var activeScreen = document.querySelector('.screen.on');
      if (activeScreen) {
        var screenId = activeScreen.id;
        if (screenId === 'screen-overview') {
          loadOverview(true);
        } else if (screenId === 'screen-settings') {
          loadSettings();
        } else if (screenId === 'screen-campaigns') {
          loadCampaigns();
        } else if (screenId === 'screen-contacts') {
          loadContacts();
        } else if (screenId === 'screen-timing') {
          loadTiming();
        }
      }
    }
  } catch (err) {
    console.error('Error loading sidebar:', err);
  }
}

// ── Overview Screen ─────────────────────────────────────────
async function loadOverview(skipSync, skipCacheRender) {
  var hasActive = !!activeAccount;
  if (!hasActive && !sidebarInitialized) {
    await loadSidebar(false);
    hasActive = !!activeAccount;
  }

  var warnBanner = document.getElementById('overview-connection-warning');
  if (warnBanner) {
    warnBanner.style.display = hasActive ? 'none' : 'block';
  }
  var connectBtn = document.getElementById('btn-overview-connect-gmail');
  if (connectBtn && !connectBtn._listenerAttached) {
    connectBtn.addEventListener('click', function() {
      goNav('settings');
    });
    connectBtn._listenerAttached = true;
  }

  // Load from cache first for immediate rendering without flashes
  if (hasActive) {
    try {
      var cachedCampaigns = localStorage.getItem('sndr_cached_campaigns_' + activeAccount.id) || localStorage.getItem('sndr_cached_overview_campaigns');
      // EXACT filter only — no cross-filter fallback, so switching campaign/period
      // doesn't flash the previous filter's data before the correct one loads.
      var cachedStats = localStorage.getItem('sndr_cached_stats_' + activeAccount.id + '_' + globalSelectedCampaignId + '_' + globalSelectedPeriod);

      var campaigns = cachedCampaigns ? JSON.parse(cachedCampaigns) : [];
      var stats = cachedStats ? JSON.parse(cachedStats) : null;

      if (campaigns && campaigns.length > 0) {
        campaignsList = campaigns;
        // Diffed update — no dropdown rebuild/flash on every poll.
        updateCampaignSelect('overview-campaign-select', campaigns, 'All Campaigns (Combined)');
      }

      // Instant paint from the exact-filter cache (keyed by campaign+period), so a
      // filter change applies immediately. The network render below dedupes via
      // _lastOverviewDataString when the data is unchanged (no second flash).
      // No cache yet (first ever load) -> paint an empty skeleton so the charts
      // appear instantly instead of a blank area while the network responds.
      if (stats) renderOverviewData(stats, campaignsList);
      else if (!window.engageChart) renderOverviewData(getEmptyStats(), campaignsList);
    } catch (e) {
      console.warn('Failed to load overview cache:', e);
    }
  }

  var stats;
  var campaigns = [];

  if (hasActive) {
    try {
      if (!skipSync) {
        maybeSyncReplies(function() { loadOverview(true); });
      }

      // Capture the filter this request is FOR. If the user switches campaign/period
      // while the request is in flight, we must cache it under the right key and not
      // paint stale data over the newer selection.
      var reqCampaign = globalSelectedCampaignId;
      var reqPeriod = globalSelectedPeriod;
      var statsUrl = '/auth/accounts/' + activeAccount.id + '/dashboard-stats' + statsQuery();

      var results = await Promise.all([
        apiCall('GET', '/campaigns?account_id=' + activeAccount.id),
        apiCall('GET', statsUrl)
      ]);

      campaigns = results[0];
      stats = results[1];
      campaignsList = campaigns;

      safeSetItem('sndr_cached_campaigns_' + activeAccount.id, JSON.stringify(campaigns));
      safeSetItem('sndr_cached_overview_campaigns', JSON.stringify(campaigns));
      safeSetItem('sndr_cached_stats_' + activeAccount.id + '_' + reqCampaign + '_' + reqPeriod, JSON.stringify(stats));
      if (reqCampaign === 'all') {
        safeSetItem('sndr_cached_overview_stats', JSON.stringify(stats));
      }
      // Warm the other period variants in the background so period toggles are instant.
      prewarmPeriodCaches(reqCampaign);

      // A newer filter was selected while this was loading -> don't overwrite the
      // current view with this now-stale response (it's already cached above).
      if (reqCampaign !== globalSelectedCampaignId || reqPeriod !== globalSelectedPeriod) {
        return;
      }

      // Populate the dropdown (diffed — only rebuilt when the campaigns changed)
      updateCampaignSelect('overview-campaign-select', campaigns, 'All Campaigns (Combined)');
      var select = document.getElementById('overview-campaign-select');
      if (select) {
        select.onchange = function() {
          syncCampaignSelection(select.value);
        };
      }
    } catch (err) {
      // Transient fetch failure (free-tier cold start, blip): keep the cache-painted
      // overview instead of flashing empty charts/tiles (that was the flicker). Bail.
      console.error('Error loading overview (keeping current view):', err);
      return;
    }
  } else {
    stats = getEmptyStats();
    var select = document.getElementById('overview-campaign-select');
    if (select) {
      select.innerHTML = '<option value="all">All Campaigns (Combined)</option>';
      select.value = 'all';
    }
  }

  renderOverviewData(stats, campaigns);
}

function renderOverviewData(stats, campaigns) {
  try {
    var statsString = JSON.stringify(stats) + '_' + JSON.stringify(campaigns);
    if (window._lastOverviewDataString === statsString && window.engageChart && window.donutChart) {
      return;
    }
    window._lastOverviewDataString = statsString;
    window._dashboardStats = stats;

    var f = stats.funnel || { total: 0, pending: 0, sent: 0, delivered: 0, opened: 0, replied: 0, bounced: 0 };
    var total = Number(f.total) || 0;
    var scheduled = Number(f.pending) || 0;
    var sent = Number(f.sent) || 0;
    var delivered = Number(f.delivered) || 0;
    var opened = Number(f.opened) || 0;
    var replied = Number(f.replied) || 0;
    var bounced = Number(f.bounced) || 0;

    var openRate = sent > 0 ? Math.round((opened / sent) * 100) : 0;
    var replyRate = sent > 0 ? Math.round((replied / sent) * 100) : 0;
    var bounceRate = sent > 0 ? Math.round((bounced / sent) * 100) : 0;

    var sentEl = document.getElementById('v-sent');
    var openEl = document.getElementById('v-open');
    var replyEl = document.getElementById('v-reply');
    var bounceEl = document.getElementById('v-bounce');

    if (sentEl) sentEl.textContent = sent;
    if (openEl) openEl.textContent = openRate + '%';
    if (replyEl) replyEl.textContent = replyRate + '%';
    if (bounceEl) bounceEl.textContent = bounceRate + '%';

    var scEl = document.getElementById('f-sc');
    var seEl = document.getElementById('f-se');
    var deEl = document.getElementById('f-de');
    var opEl = document.getElementById('f-op');
    var reEl = document.getElementById('f-re');

    var scFill = document.getElementById('f-sc-fill');
    var seFill = document.getElementById('f-se-fill');
    var deFill = document.getElementById('f-de-fill');
    var opFill = document.getElementById('f-op-fill');
    var reFill = document.getElementById('f-re-fill');

    var scPct = document.getElementById('f-sc-pct');
    var sePct = document.getElementById('f-se-pct');
    var dePct = document.getElementById('f-de-pct');
    var opPct = document.getElementById('f-op-pct');
    var rePct = document.getElementById('f-re-pct');

    var pSc = total > 0 ? 100 : 0;
    var pSe = total > 0 ? Math.round((sent / total) * 100) : 0;
    var pDe = total > 0 ? Math.round((delivered / total) * 100) : 0;
    var pOp = total > 0 ? Math.round((opened / total) * 100) : 0;
    var pRe = total > 0 ? Math.round((replied / total) * 100) : 0;

    if (scEl) scEl.textContent = scheduled;
    if (scFill) scFill.style.width = pSc + '%';
    if (scPct) scPct.textContent = pSc + '%';

    if (seEl) seEl.textContent = sent;
    if (seFill) seFill.style.width = pSe + '%';
    if (sePct) sePct.textContent = pSe + '%';

    if (deEl) deEl.textContent = delivered;
    if (deFill) deFill.style.width = pDe + '%';
    if (dePct) dePct.textContent = pDe + '%';

    if (opEl) opEl.textContent = opened;
    if (opFill) opFill.style.width = pOp + '%';
    if (opPct) opPct.textContent = pOp + '%';

    if (reEl) reEl.textContent = replied;
    if (reFill) reFill.style.width = pRe + '%';
    if (rePct) rePct.textContent = pRe + '%';

    var funnelSub = document.getElementById('funnel-sub');
    if (funnelSub) funnelSub.textContent = total + ' emails total';

    var tOpen = stats.timeToOpen || { within1h: 0, within6h: 0, within24h: 0, after24h: 0 };
    var t1hPct = document.getElementById('t-open-1h-pct');
    var t1hFill = document.getElementById('t-open-1h-fill');
    if (t1hPct) t1hPct.textContent = (tOpen.within1h || 0) + '%';
    if (t1hFill) t1hFill.style.width = (tOpen.within1h || 0) + '%';

    var t6hPct = document.getElementById('t-open-6h-pct');
    var t6hFill = document.getElementById('t-open-6h-fill');
    if (t6hPct) t6hPct.textContent = (tOpen.within6h || 0) + '%';
    if (t6hFill) t6hFill.style.width = (tOpen.within6h || 0) + '%';

    var t24hPct = document.getElementById('t-open-24h-pct');
    var t24hFill = document.getElementById('t-open-24h-fill');
    if (t24hPct) t24hPct.textContent = (tOpen.within24h || 0) + '%';
    if (t24hFill) t24hFill.style.width = (tOpen.within24h || 0) + '%';

    var tAfterPct = document.getElementById('t-open-after-pct');
    var tAfterFill = document.getElementById('t-open-after-fill');
    if (tAfterPct) tAfterPct.textContent = (tOpen.after24h || 0) + '%';
    if (tAfterFill) tAfterFill.style.width = (tOpen.after24h || 0) + '%';

    var hDel = document.getElementById('health-delivery-val');
    var hSpam = document.getElementById('health-spam-val');
    var hBounce = document.getElementById('health-bounce-val');
    var hQuotaVal = document.getElementById('health-quota-val');
    var hQuotaFill = document.getElementById('health-quota-fill');

    var delRate = sent > 0 ? (100 - bounceRate) : 100;
    if (hDel) hDel.textContent = delRate + '%';
    if (hSpam) hSpam.textContent = '0%';
    if (hBounce) hBounce.textContent = bounceRate + '%';

    var used = (stats.usage && stats.usage.todaySends) || 0;
    var limit = (stats.usage && stats.usage.dailyLimit) || 500;
    if (hQuotaVal) hQuotaVal.textContent = used + '/' + limit;
    if (hQuotaFill) {
      var qPct = Math.min(100, Math.round((used / limit) * 100));
      hQuotaFill.style.width = qPct + '%';
    }

    renderOverviewCharts(stats);
    renderRecentCampaigns(campaigns);
  } catch (err) {
    // A failed/interrupted render must not poison the dedup guard, or the next
    // refresh with the same data would short-circuit and leave the page stuck.
    window._lastOverviewDataString = null;
    console.error('Error rendering overview details:', err);
  }
}

async function loadTiming(skipCacheRender) {
  var hasActive = !!activeAccount;
  if (!hasActive && !sidebarInitialized) {
    await loadSidebar(false);
    hasActive = !!activeAccount;
  }

  var stats;
  var campaigns = [];

  if (hasActive) {
    // Instant paint: render the timing charts from cache (or empty) right away so
    // they are always visible, then refresh below when fresh data arrives.
    try {
      var cachedT = localStorage.getItem('sndr_cached_stats_' + activeAccount.id + '_' + globalSelectedCampaignId + '_' + globalSelectedPeriod);
      if (cachedT) {
        var parsedT = JSON.parse(cachedT);
        // Prime the dedupe guard so the identical network response below is skipped.
        window._lastTimingDataString = JSON.stringify(parsedT);
        window._dashboardStats = parsedT;
        buildTimingCharts(parsedT);
      } else if (!window.daysChart) {
        // First-ever load with no cache: paint the chart skeletons immediately so
        // the screen isn't blank while the (possibly cold-starting) network call
        // runs — the fresh data then updates the charts in place.
        buildTimingCharts(getEmptyStats());
      }
    } catch (e) {}
    try {
      campaigns = campaignsList.length > 0 ? campaignsList : await apiCall('GET', '/campaigns?account_id=' + activeAccount.id);
      campaignsList = campaigns;

      // Populate timing dropdown (diffed — only rebuilt when campaigns changed)
      updateCampaignSelect('timing-campaign-select', campaigns, 'All Campaigns (Combined)');
      var select = document.getElementById('timing-campaign-select');
      if (select) {
        select.onchange = function() {
          syncCampaignSelection(select.value);
        };
      }

      var reqCampaignT = globalSelectedCampaignId;
      var reqPeriodT = globalSelectedPeriod;
      var statsUrl = '/auth/accounts/' + activeAccount.id + '/dashboard-stats' + statsQuery();
      stats = await apiCall('GET', statsUrl);
      // Ignore a stale response if the filter changed while it was in flight.
      if (reqCampaignT !== globalSelectedCampaignId || reqPeriodT !== globalSelectedPeriod) {
        return;
      }
    } catch (err) {
      // Transient fetch failure (free-tier cold start, blip): keep the cache-painted
      // charts instead of flashing empty ones (that was the flicker). Bail out and
      // leave whatever is already on screen.
      console.error('Error loading timing stats (keeping current charts):', err);
      return;
    }
  } else {
    stats = getEmptyStats();
    var select = document.getElementById('timing-campaign-select');
    if (select) {
      select.innerHTML = '<option value="all">All Campaigns (Combined)</option>';
      select.value = 'all';
    }
  }

  try {
    // Smart diff to prevent flicker
    var statsString = JSON.stringify(stats);
    if (window._lastTimingDataString === statsString && window.daysChart && window.hoursChart && window.followupChart) {
      return;
    }
    window._lastTimingDataString = statsString;
    window._dashboardStats = stats;

    buildTimingCharts(stats);
  } catch (err) {
    // Reset the dedup guard on failure so the next refresh retries instead of
    // short-circuiting on un-rendered data.
    window._lastTimingDataString = null;
    console.error('Error rendering timing stats charts:', err);
  }
}

function renderRecentCampaigns(campaigns) {
  var dCamp = document.getElementById('dash-camp-list');
  if (!dCamp) return;

  if (campaigns.length === 0) {
    var emptyHtml = '<div style="text-align:center;padding:20px;color:var(--ol)">No campaigns created yet.</div>';
    if (dCamp._sig !== emptyHtml) { dCamp._sig = emptyHtml; dCamp.innerHTML = emptyHtml; }
    return;
  }

  var html = '';
  campaigns.slice(0, 3).forEach(function(c) {
    var s = c.stats || { total: 0, sent: 0, replied: 0, opened: 0 };
    var sent = Number(s.sent) || 0;
    var repR = sent > 0 ? Math.round((Number(s.replied) || 0) / sent * 100) + '%' : '0%';
    var openR = sent > 0 ? Math.round((Number(s.opened) || 0) / sent * 100) + '%' : '0%';

    html += '<div class="camp-row" onclick="goNav(\'campaigns\')">' +
      '<div class="camp-dot ' + statusDot(c.status) + '"></div>' +
      '<div class="camp-name">' + escHtml(c.name) + '</div>' +
      statusBadge(c.status) +
      '<div class="camp-stats">' +
        '<div><div class="cs-val">' + s.total + '</div><div class="cs-lbl">Total</div></div>' +
        '<div><div class="cs-val">' + sent + '</div><div class="cs-lbl">Sent</div></div>' +
        '<div><div class="cs-val">' + openR + '</div><div class="cs-lbl">Open</div></div>' +
        '<div><div class="cs-val">' + repR + '</div><div class="cs-lbl">Reply</div></div>' +
      '</div>' +
    '</div>';
  });
  // Only touch the DOM when the content actually changed — during an active send
  // this repainted every poll and made the Overview's campaign rows flicker.
  if (dCamp._sig !== html) { dCamp._sig = html; dCamp.innerHTML = html; }
}

// ── Campaigns Screen ────────────────────────────────────────
// First-load skeleton placeholders — shown on a cacheless client while the very
// first network response is in flight, so a cold install sees a structured loading
// state instead of a blank panel. They carry no data-cid / .camp-row, so the
// reconcilers treat them as absent and replace them the instant real data renders.
function contactsSkeletonHtml(rows) {
  var n = rows || 6;
  var w = ['55%', '40%', '68%', '45%', '60%', '50%'];
  var out = '';
  for (var i = 0; i < n; i++) {
    out += '<tr>' +
      '<td><div style="display:flex;align-items:center;gap:10px"><span class="skel skel-av"></span>' +
        '<span style="display:flex;flex-direction:column;gap:6px"><span class="skel skel-line" style="width:120px"></span><span class="skel skel-line" style="width:160px"></span></span></div></td>' +
      '<td><span class="skel skel-line" style="width:' + w[i % w.length] + '"></span></td>' +
      '<td><span class="skel skel-line" style="width:80%"></span></td>' +
      '<td><span class="skel skel-line" style="width:48px"></span></td>' +
      '<td><span class="skel skel-line" style="width:70px"></span></td>' +
    '</tr>';
  }
  return out;
}
function campaignsSkeletonHtml(rows) {
  var n = rows || 4;
  var out = '';
  for (var i = 0; i < n; i++) {
    out += '<div class="camp-skel">' +
      '<span class="skel" style="width:10px;height:10px;border-radius:50%"></span>' +
      '<span class="skel skel-line" style="width:180px"></span>' +
      '<span class="skel skel-line" style="width:70px;margin-left:auto"></span>' +
      '<span class="skel skel-line" style="width:54px"></span>' +
      '<span class="skel skel-line" style="width:54px"></span>' +
      '<span class="skel skel-line" style="width:54px"></span>' +
    '</div>';
  }
  return out;
}

async function loadCampaigns(skipSync) {
  var hasActive = !!activeAccount;
  if (!hasActive && !sidebarInitialized) {
    await loadSidebar(false);
    hasActive = !!activeAccount;
  }

  // Load from cache first for instant render
  if (hasActive) {
    try {
      var cachedCampaigns = localStorage.getItem('sndr_cached_campaigns_' + activeAccount.id) || localStorage.getItem('sndr_cached_overview_campaigns');
      if (cachedCampaigns) {
        var parsed = JSON.parse(cachedCampaigns);
        renderCampaignsList(parsed, hasActive);
      }
    } catch (e) {}

    // Cold start, no cache: show a skeleton so a fresh install isn't staring at a
    // blank panel during the (possibly slow) first fetch. Cleared on first render.
    var campWrap = document.getElementById('camp-list');
    if (campWrap && campWrap.children.length === 0) campWrap.innerHTML = campaignsSkeletonHtml();
  }

  // No connected account: render the empty/connect state and stop.
  if (!hasActive) {
    renderCampaignsList([], hasActive);
    return;
  }

  if (!skipSync) {
    maybeSyncReplies(function() { loadCampaigns(true); });
  }

  try {
    var campaigns = await apiCall('GET', '/campaigns?account_id=' + activeAccount.id);
    campaignsList = campaigns;
    safeSetItem('sndr_cached_campaigns_' + activeAccount.id, JSON.stringify(campaigns));
    safeSetItem('sndr_cached_overview_campaigns', JSON.stringify(campaigns));
    renderCampaignsList(campaigns, hasActive);
  } catch (err) {
    // Transient fetch failure (free-tier cold start, network blip, 5xx): keep the
    // last good render instead of wiping the list to empty. Re-rendering [] on a
    // failed poll was the flicker — the campaigns vanished, then the next poll's
    // cache paint brought them back, every ~8s. Leave the current list untouched.
    console.error('Error loading campaigns (keeping current list):', err);
  }
}

// Build one campaign's row + (optional) steps-panel HTML, plus a signature used to
// detect whether the card changed since the last render. Pure function of `c`.
function buildCampaignCard(c) {
  var s = c.stats || { total: 0, sent: 0, replied: 0, opened: 0 };
  var sent = Number(s.sent) || 0;
  var repR = sent > 0 ? Math.round((Number(s.replied) || 0) / sent * 100) + '%' : '0%';
  var openR = sent > 0 ? Math.round((Number(s.opened) || 0) / sent * 100) + '%' : '0%';

  var actionButton = '';
  if (c.status === 'draft' || c.status === 'paused' || (c.status === 'sent' && sent < s.total)) {
    actionButton = '<button class="btn-ol btn-send-camp" data-id="' + c.id + '" style="padding: 4px 10px; font-size:11px; margin-right:5px"><span class="mi" style="font-size:13px">play_arrow</span>Send</button>';
  } else if (c.status === 'scheduled') {
    // A scheduled campaign starts by itself at its time; offer "Send Now" to
    // override, so a scheduled send is never a black box the user can't control.
    actionButton = '<button class="btn-ol btn-send-camp" data-id="' + c.id + '" style="padding: 4px 10px; font-size:11px; margin-right:5px" title="Start sending immediately instead of waiting for the scheduled time"><span class="mi" style="font-size:13px">play_arrow</span>Send Now</button>';
  } else if (c.status === 'sending') {
    actionButton = '<button class="btn-ol btn-pause-camp" data-id="' + c.id + '" style="padding: 4px 10px; font-size:11px; margin-right:5px"><span class="mi" style="font-size:13px">pause</span>Pause</button>';
  }

  var deleteButton = '<button class="btn-ol btn-delete-camp" data-id="' + c.id + '" style="padding: 4px 10px; font-size:11px; color: var(--red); border-color: rgba(186,26,26,0.2)"><span class="mi" style="font-size:13px">delete</span>Delete</button>';

  var followupButton = '';
  var fu = c.followups || { pending: 0, cancelled: 0 };
  if (fu.pending > 0) {
    followupButton = '<button class="btn-ol btn-stop-camp-fu" data-id="' + c.id + '" style="padding: 4px 10px; font-size:11px; margin-right:5px; color:#dc2626; border-color:#fca5a5" title="Cancel all pending follow-ups for this campaign"><span class="mi" style="font-size:13px">block</span>Stop follow-ups</button>';
  } else if (fu.cancelled > 0) {
    followupButton = '<button class="btn-ol btn-resume-camp-fu" data-id="' + c.id + '" style="padding: 4px 10px; font-size:11px; margin-right:5px; color:var(--p); border-color:var(--p20)" title="Re-arm all cancelled follow-ups for this campaign"><span class="mi" style="font-size:13px">restart_alt</span>Resume follow-ups</button>';
  }

  var fuSteps = [];
  try { fuSteps = c.followup_steps ? JSON.parse(c.followup_steps) : []; } catch (e) { fuSteps = []; }
  var activeStepCount = fuSteps.filter(function(st) { return st && !st.deleted; }).length;

  var stepsToggleButton = '';
  var stepsPanel = '';
  if (activeStepCount > 0) {
    stepsToggleButton = '<button class="btn-ol btn-toggle-steps" data-id="' + c.id + '" style="padding:4px 10px; font-size:11px; margin-right:5px" title="Pause or delete individual follow-up steps"><span class="mi" style="font-size:13px">tune</span>Steps (' + activeStepCount + ')</button>';

    var stepRows = '';
    fuSteps.forEach(function(st, i) {
      if (!st || st.deleted) return;
      var stepNum = i + 1;
      var rawPreview = String(st.body || '').replace(/<[^>]*>/g, '').replace(/&nbsp;/gi, ' ').trim();
      var preview = rawPreview ? escHtml(rawPreview.slice(0, 70)) : '<span style="color:var(--ol)">(empty body)</span>';
      var paused = !!st.paused;
      var badge = paused ? '<span style="font-size:9.5px;font-weight:700;color:#b45309;background:#fef3c7;padding:1px 6px;border-radius:6px;margin-left:8px;vertical-align:middle">PAUSED</span>' : '';
      var pauseStyle = paused ? 'color:var(--p);border-color:var(--p20)' : 'color:#b45309;border-color:#fcd34d';
      stepRows +=
        '<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-top:1px solid var(--border)">' +
          '<div style="font-size:11.5px;font-weight:700;color:var(--p);flex-shrink:0;min-width:46px">Step ' + stepNum + '</div>' +
          '<div style="flex:1;min-width:0;font-size:11px;color:var(--tx);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + preview + badge + '</div>' +
          '<button class="btn-ol btn-step-pause" data-id="' + c.id + '" data-step="' + stepNum + '" data-paused="' + (paused ? '1' : '0') + '" style="padding:3px 9px;font-size:10.5px;flex-shrink:0;' + pauseStyle + '"><span class="mi" style="font-size:12px">' + (paused ? 'play_arrow' : 'pause') + '</span>' + (paused ? 'Resume' : 'Pause') + '</button>' +
          '<button class="btn-ol btn-step-delete" data-id="' + c.id + '" data-step="' + stepNum + '" style="padding:3px 9px;font-size:10.5px;flex-shrink:0;color:var(--red);border-color:rgba(186,26,26,0.2)"><span class="mi" style="font-size:12px">delete</span>Delete</button>' +
        '</div>';
    });
    stepsPanel =
      '<div class="camp-steps-panel" data-camp-id="' + c.id + '" style="display:none;margin:-4px 0 8px 18px;background:var(--sf);border:1px solid var(--sf-hi);border-radius:0 0 var(--r4) var(--r4);overflow:hidden">' +
        '<div style="font-size:10.5px;color:var(--ol);font-weight:600;padding:8px 12px 2px">Follow-up steps: pause or delete individually</div>' +
        stepRows +
      '</div>';
  }

  var rowHtml = '<div class="camp-row" data-camp-id="' + c.id + '">' +
    '<div class="camp-dot ' + statusDot(c.status) + '"></div>' +
    '<div class="camp-name">' + escHtml(c.name) + '</div>' +
    statusBadge(c.status) +
    '<div style="display:flex;align-items:center;margin-right:12px">' + actionButton + followupButton + stepsToggleButton + deleteButton + '</div>' +
    '<div class="camp-stats">' +
      '<div><div class="cs-val">' + s.total + '</div><div class="cs-lbl">Total</div></div>' +
      '<div><div class="cs-val">' + sent + '</div><div class="cs-lbl">Sent</div></div>' +
      '<div><div class="cs-val">' + openR + '</div><div class="cs-lbl">Open</div></div>' +
      '<div><div class="cs-val">' + repR + '</div><div class="cs-lbl">Reply</div></div>' +
    '</div>' +
  '</div>';

  return { id: String(c.id), rowHtml: rowHtml, panelHtml: stepsPanel, sig: rowHtml + '' + stepsPanel };
}

// Turn an HTML string (a single root element) into a detached DOM node.
function nodeFromHtml(html) {
  var t = document.createElement('div');
  t.innerHTML = html;
  return t.firstElementChild;
}

// Delegated click handling for the campaigns list — bound ONCE on the stable
// #camp-list container, so incremental card updates never rebind per-button.
// Mirrors the previous per-button handlers exactly (confirms, toasts, cache
// invalidation, guard resets, and the optimistic loadCampaigns reload).
function bindCampaignsDelegation(wrap) {
  if (!wrap || wrap._sndrCampDeleg) return;
  wrap._sndrCampDeleg = true;
  wrap.addEventListener('click', async function(e) {
    var btn = e.target.closest ? e.target.closest('button') : null;
    if (!btn || !wrap.contains(btn)) return;
    e.stopPropagation();            // match the old per-button stopPropagation
    var id = btn.dataset.id;

    if (btn.classList.contains('btn-send-camp')) {
      if (!id) return;
      try { btn.disabled = true; await apiCall('POST', '/campaigns/' + id + '/send'); invalidateStatsCache({ contacts: true }); showToast('Campaign send process started!'); loadCampaigns(); }
      catch (err) { showToast(err.message, true); btn.disabled = false; }
    } else if (btn.classList.contains('btn-pause-camp')) {
      if (!id) return;
      try { btn.disabled = true; await apiCall('POST', '/campaigns/' + id + '/pause'); invalidateStatsCache(); showToast('Campaign paused.'); loadCampaigns(); }
      catch (err) { showToast(err.message, true); btn.disabled = false; }
    } else if (btn.classList.contains('btn-delete-camp')) {
      if (!id) return;
      if (!confirm('Are you sure you want to delete this campaign? This will remove all associated contacts.')) return;
      try { btn.disabled = true; await apiCall('DELETE', '/campaigns/' + id); invalidateStatsCache({ contacts: true }); showToast('Campaign deleted.'); loadCampaigns(); }
      catch (err) { showToast(err.message, true); btn.disabled = false; }
    } else if (btn.classList.contains('btn-stop-camp-fu')) {
      if (!id) return;
      if (!confirm('Stop all pending follow-ups for this campaign? You can resume them later.')) return;
      try { btn.disabled = true; btn.textContent = 'Stopping...'; var res = await apiCall('POST', '/campaigns/' + id + '/stop-followups'); window._lastCampaignsDataString = null; showToast('Stopped ' + ((res && res.cancelled) || 0) + ' follow-up(s) for this campaign.'); loadCampaigns(); }
      catch (err) { showToast(err.message, true); btn.disabled = false; }
    } else if (btn.classList.contains('btn-resume-camp-fu')) {
      if (!id) return;
      try { btn.disabled = true; btn.textContent = 'Resuming...'; var res = await apiCall('POST', '/campaigns/' + id + '/resume-followups'); window._lastCampaignsDataString = null; showToast('Resumed ' + ((res && res.resumed) || 0) + ' follow-up(s) for this campaign.'); loadCampaigns(); }
      catch (err) { showToast(err.message, true); btn.disabled = false; }
    } else if (btn.classList.contains('btn-toggle-steps')) {
      var panel = wrap.querySelector('.camp-steps-panel[data-camp-id="' + id + '"]');
      if (panel) panel.style.display = (panel.style.display === 'none' || !panel.style.display) ? 'block' : 'none';
    } else if (btn.classList.contains('btn-step-pause')) {
      if (!id) return;
      var step = parseInt(btn.dataset.step, 10);
      var currentlyPaused = btn.dataset.paused === '1';
      try { btn.disabled = true; await apiCall('POST', '/campaigns/' + id + '/followup-steps/' + step + '/pause', { paused: !currentlyPaused }); window._lastCampaignsDataString = null; showToast(currentlyPaused ? ('Step ' + step + ' resumed.') : ('Step ' + step + ' paused.')); loadCampaigns(); }
      catch (err) { showToast(err.message, true); btn.disabled = false; }
    } else if (btn.classList.contains('btn-step-delete')) {
      if (!id) return;
      var step = parseInt(btn.dataset.step, 10);
      if (!confirm('Delete follow-up step ' + step + '? Any pending sends for this step will be cancelled. This cannot be undone.')) return;
      try { btn.disabled = true; var res = await apiCall('DELETE', '/campaigns/' + id + '/followup-steps/' + step); window._lastCampaignsDataString = null; showToast('Step ' + step + ' deleted' + (res && res.cancelled ? ' (' + res.cancelled + ' pending cancelled).' : '.')); loadCampaigns(); }
      catch (err) { showToast(err.message, true); btn.disabled = false; }
    }
  });
}

// ── Campaigns toolbar: search / status / sort (instant client-side view) ─────
var campViewFilters = { q: '', status: 'all', sort: 'newest' };
function campViewState() { return campViewFilters.q + '|' + campViewFilters.status + '|' + campViewFilters.sort; }
function campaignRate(c, key) {
  var s = c.stats || {};
  var sent = Number(s.sent) || 0;
  return sent > 0 ? (Number(s[key]) || 0) / sent : 0;
}
function applyCampaignView(campaigns) {
  var q = campViewFilters.q.toLowerCase();
  var view = (campaigns || []).filter(function(c) {
    if (campViewFilters.status !== 'all' && c.status !== campViewFilters.status) return false;
    if (q && String(c.name || '').toLowerCase().indexOf(q) === -1) return false;
    return true;
  }).slice();
  var by = campViewFilters.sort;
  view.sort(function(a, b) {
    if (by === 'oldest') return (Number(a.created_at) || 0) - (Number(b.created_at) || 0);
    if (by === 'name') return String(a.name || '').localeCompare(String(b.name || ''));
    if (by === 'sent') return (((b.stats || {}).sent) || 0) - (((a.stats || {}).sent) || 0);
    if (by === 'open') return campaignRate(b, 'opened') - campaignRate(a, 'opened');
    if (by === 'reply') return campaignRate(b, 'replied') - campaignRate(a, 'replied');
    return (Number(b.created_at) || 0) - (Number(a.created_at) || 0); // newest (default)
  });
  return view;
}

function setupCampaignToolbar() {
  if (window._campToolbarSet) return;
  var search = document.getElementById('camp-search');
  var stBtn = document.getElementById('btn-camp-status');
  var stMenu = document.getElementById('camp-status-menu');
  var soBtn = document.getElementById('btn-camp-sort');
  var soMenu = document.getElementById('camp-sort-menu');
  if (!search || !stBtn || !stMenu || !soBtn || !soMenu) return;
  window._campToolbarSet = true;

  function rerender() { renderCampaignsList(campaignsList || [], !!activeAccount); }

  var deb = null;
  search.addEventListener('input', function() {
    clearTimeout(deb);
    deb = setTimeout(function() { campViewFilters.q = search.value.trim(); rerender(); }, 120);
  });

  function closeMenus() { stMenu.hidden = true; soMenu.hidden = true; }
  stBtn.addEventListener('click', function(e) { e.stopPropagation(); soMenu.hidden = true; stMenu.hidden = !stMenu.hidden; });
  soBtn.addEventListener('click', function(e) { e.stopPropagation(); stMenu.hidden = true; soMenu.hidden = !soMenu.hidden; });
  document.addEventListener('click', closeMenus);

  function bindMenu(menu, btn, key, labelPrefix) {
    menu.addEventListener('click', function(e) {
      var item = e.target.closest ? e.target.closest('.camp-menu-item') : null;
      if (!item) return;
      e.stopPropagation();
      campViewFilters[key] = item.getAttribute('data-value');
      Array.prototype.forEach.call(menu.querySelectorAll('.camp-menu-item'), function(mi) {
        mi.classList.toggle('on', mi === item);
      });
      btn.textContent = labelPrefix + ': ' + item.textContent.trim() + ' ▾';
      closeMenus();
      rerender();
    });
  }
  bindMenu(stMenu, stBtn, 'status', 'Status');
  bindMenu(soMenu, soBtn, 'sort', 'Sort');
}

function renderCampaignsList(campaigns, hasActive) {
  try {
    var wrap = document.getElementById('camp-list');
    if (!wrap) return;
    setupCampaignToolbar();

    // Dedupe key includes the toolbar state, so changing search/status/sort
    // always repaints even when the underlying data is unchanged.
    var campString = JSON.stringify(campaigns) + '::' + campViewState();
    // Only skip re-render when the data is unchanged AND the list is actually
    // painted. Previously the "rendered" flag was set BEFORE rendering, so a render
    // interrupted by slow/partial data (e.g. during a heavy 500-email send) left the
    // flag stuck and this guard then skipped re-rendering the same data — leaving the
    // dashboard blank with no recovery. Checking the DOM lets it self-heal on the
    // next paint, and we only set the flag AFTER a successful render (below).
    if (window._lastCampaignsDataString === campString && window.campChartInstance && wrap.children.length > 0) {
      return;
    }

    if (campaigns.length === 0) {
      wrap.innerHTML = '<div style="text-align:center;padding:40px;color:var(--ol)">No campaigns created yet.' + (hasActive ? ' Click "+ New Campaign" to start!' : ' Connect a Gmail account to start.') + '</div>';
      window._lastCampaignsDataString = campString;
      return;
    }

    // Apply the toolbar view (search + status filter + sort). Campaigns exist
    // but none match → say so explicitly (distinct from "none created").
    var view = applyCampaignView(campaigns);
    if (view.length === 0) {
      wrap.innerHTML = '<div style="text-align:center;padding:40px;color:var(--ol)">No campaigns match your search / filters.</div>';
      buildCampCharts([]);
      window._lastCampaignsDataString = campString;
      return;
    }

    // Precompute each campaign's card HTML + change-signature once.
    var cards = {};
    var desiredIds = [];
    view.forEach(function(c) {
      var card = buildCampaignCard(c);
      cards[card.id] = card;
      desiredIds.push(card.id);
    });

    // Index the current DOM: rows + panels by id, the existing row order, and which
    // step-panels are currently expanded (the open state lives in the DOM).
    var exRows = {}, exPanels = {}, existingIds = [], openSet = {};
    Array.prototype.forEach.call(wrap.querySelectorAll('.camp-row[data-camp-id]'), function(r) {
      var rid = r.getAttribute('data-camp-id');
      exRows[rid] = r;
      existingIds.push(rid);
    });
    Array.prototype.forEach.call(wrap.querySelectorAll('.camp-steps-panel[data-camp-id]'), function(p) {
      var pid = p.getAttribute('data-camp-id');
      exPanels[pid] = p;
      if (p.style.display && p.style.display !== 'none') openSet[pid] = true;
    });

    var sameOrder = existingIds.length === desiredIds.length &&
      desiredIds.every(function(id, i) { return id === existingIds[i]; });

    if (sameOrder) {
      // ── Hot path: same campaigns, same order (the during-send case). Replace
      // only the cards whose content actually changed, in place, and keep any
      // expanded steps-panel open. Unchanged cards are never touched → no flicker. ──
      view.forEach(function(c) {
        var card = cards[String(c.id)];
        var row = exRows[card.id];
        if (!row || row.dataset.sig === card.sig) return; // missing or unchanged
        var oldPanel = exPanels[card.id];
        var wasOpen = !!(oldPanel && oldPanel.style.display && oldPanel.style.display !== 'none');
        var newRow = nodeFromHtml(card.rowHtml);
        newRow.dataset.sig = card.sig;
        wrap.replaceChild(newRow, row);
        if (card.panelHtml) {
          var newPanel = nodeFromHtml(card.panelHtml);
          if (wasOpen) newPanel.style.display = 'block';
          if (oldPanel) wrap.replaceChild(newPanel, oldPanel);
          else wrap.insertBefore(newPanel, newRow.nextSibling);
        } else if (oldPanel) {
          wrap.removeChild(oldPanel);
        }
      });
    } else {
      // ── Fallback: campaigns added/removed/reordered/refiltered (user-initiated).
      // Rebuild the list, then stamp signatures + restore any open panels. ──
      var html = '';
      view.forEach(function(c) { var card = cards[String(c.id)]; html += card.rowHtml + card.panelHtml; });
      wrap.innerHTML = html;
      Array.prototype.forEach.call(wrap.querySelectorAll('.camp-row[data-camp-id]'), function(r) {
        var card = cards[r.getAttribute('data-camp-id')];
        if (card) r.dataset.sig = card.sig;
      });
      Array.prototype.forEach.call(wrap.querySelectorAll('.camp-steps-panel[data-camp-id]'), function(p) {
        if (openSet[p.getAttribute('data-camp-id')]) p.style.display = 'block';
      });
    }

    bindCampaignsDelegation(wrap);

    // The performance chart follows the visible (filtered/sorted) list.
    buildCampCharts(view);
    // Mark this data as rendered only AFTER a successful paint, so an interrupted
    // render never leaves the dedup guard stuck on un-painted data.
    window._lastCampaignsDataString = campString;
  } catch (err) {
    console.error('Error rendering campaigns:', err);
  }
}

// Paint the Contacts-tab stat tiles (Total / Replied / Opened / Pending) from a
// dashboard-stats object. Used both for the instant cache paint and — crucially —
// when the fresh network stats resolve, so the tiles reflect the latest sends
// instead of staying on the cached value for a cycle.
// Paint the "Follow-ups" tile from the campaigns list (each campaign carries
// exact per-status follow-up counts straight from the followups table). Honors
// the selected campaign filter; big number = follow-ups currently scheduled,
// sub-line = how many the user's sequences have created in total and how many
// already went out.
function renderFollowupsTile() {
  var valEl = document.getElementById('v-contacts-followups');
  var descEl = document.getElementById('v-contacts-followups-desc');
  if (!valEl) return;
  var scheduled = 0, created = 0, sent = 0, hasTotals = false;
  (campaignsList || []).forEach(function(c) {
    if (globalSelectedCampaignId && globalSelectedCampaignId !== 'all' && String(c.id) !== String(globalSelectedCampaignId)) return;
    var fu = c.followups || {};
    scheduled += Number(fu.pending) || 0;
    if (fu.total !== undefined) {
      hasTotals = true;
      created += Number(fu.total) || 0;
      sent += Number(fu.sent) || 0;
    }
  });
  valEl.textContent = scheduled;
  if (descEl) {
    descEl.textContent = hasTotals
      ? (created + ' created · ' + sent + ' sent')
      : 'Scheduled follow-ups';
  }
}

function renderContactsStatTiles(stats) {
  if (!stats) return;
  var totalEl = document.getElementById('v-contacts-total');
  var repliedEl = document.getElementById('v-contacts-replied');
  var openedEl = document.getElementById('v-contacts-opened');
  var pendingEl = document.getElementById('v-contacts-pending');

  var f = stats.funnel || { total: 0, pending: 0, sent: 0, delivered: 0, opened: 0, replied: 0, bounced: 0 };
  var total = Number(f.total) || 0;
  var replied = Number(f.replied) || 0;
  var opened = Number(f.opened) || 0;
  var pending = Number(f.pending) || 0;

  if (totalEl) totalEl.textContent = total;
  if (repliedEl) {
    repliedEl.textContent = replied;
    var repliedDesc = repliedEl.nextElementSibling;
    if (repliedDesc && repliedDesc.classList.contains('mc-desc')) {
      var replyRate = total > 0 ? Math.round((replied / total) * 100) : 0;
      repliedDesc.textContent = replyRate + '% Reply Rate';
    }
  }
  if (openedEl) {
    openedEl.textContent = opened;
    var openedDesc = openedEl.nextElementSibling;
    if (openedDesc && openedDesc.classList.contains('mc-desc')) {
      var openRate = total > 0 ? Math.round((opened / total) * 100) : 0;
      openedDesc.textContent = openRate + '% Open Rate';
    }
  }
  if (pendingEl) pendingEl.textContent = pending;
  renderFollowupsTile();
}

async function loadContacts(skipSync, skipLoader, skipCacheRender) {
  var hasActive = !!activeAccount;
  if (!hasActive && !sidebarInitialized) {
    await loadSidebar(false);
    hasActive = !!activeAccount;
  }

  // Load from cache first
  if (hasActive) {
    try {
      var cachedCampaigns = localStorage.getItem('sndr_cached_campaigns_' + activeAccount.id) || localStorage.getItem('sndr_cached_overview_campaigns');
      var cachedStats = localStorage.getItem('sndr_cached_stats_' + activeAccount.id + '_' + globalSelectedCampaignId + '_' + globalSelectedPeriod);
      var campaigns = cachedCampaigns ? JSON.parse(cachedCampaigns) : [];
      var stats = cachedStats ? JSON.parse(cachedStats) : null;

      if (campaigns && campaigns.length > 0) {
        campaignsList = campaigns;
        // Diffed update — no dropdown rebuild/flash on every poll.
        updateCampaignSelect('contacts-campaign-select', campaigns, 'All Campaigns');
      }
      if (stats) renderContactsStatTiles(stats);
      renderFollowupsTile();
    } catch(e) {}
  }

  var stats;
  var campaigns = [];

  if (hasActive) {
    try {
      if (!skipSync) {
        maybeSyncReplies(function() { loadContacts(true); });
      }

      // Always fetch fresh campaigns here: their followup counts feed the
      // Follow-ups tile and change as follow-ups send/schedule — reusing the
      // in-memory list froze the tile while sitting on this tab. On failure,
      // fall back to the last known list (never blank anything).
      try {
        campaigns = await apiCall('GET', '/campaigns?account_id=' + activeAccount.id);
        campaignsList = campaigns || [];
        safeSetItem('sndr_cached_campaigns_' + activeAccount.id, JSON.stringify(campaignsList));
        safeSetItem('sndr_cached_overview_campaigns', JSON.stringify(campaignsList));
      } catch (e) {
        campaigns = campaignsList; // fetch failed — keep last known, never cache over it
      }
      renderFollowupsTile();

      // Populate contacts dropdown (diffed — only rebuilt when campaigns changed)
      updateCampaignSelect('contacts-campaign-select', campaigns, 'All Campaigns');
      var select = document.getElementById('contacts-campaign-select');
      if (select) {
        select.onchange = function() {
          syncCampaignSelection(select.value);
        };
      }

      // Fetch dashboard-stats in the BACKGROUND (for AI context + cache). The
      // contacts table must NOT wait on this — it gets its own counts from the list.
      // Capture the filter so the response is cached under the correct key even if
      // the user switches filters before it resolves.
      var reqCampaignC = globalSelectedCampaignId;
      var reqPeriodC = globalSelectedPeriod;
      var statsUrl = '/auth/accounts/' + activeAccount.id + '/dashboard-stats' + statsQuery();
      apiCall('GET', statsUrl).then(function(s) {
        try {
          safeSetItem('sndr_cached_stats_' + activeAccount.id + '_' + reqCampaignC + '_' + reqPeriodC, JSON.stringify(s));
          if (reqCampaignC === 'all') safeSetItem('sndr_cached_overview_stats', JSON.stringify(s));
          // Only treat as the "current" stats if the filter hasn't moved on, and
          // repaint the tiles so a send done moments ago is reflected right away.
          if (reqCampaignC === globalSelectedCampaignId && reqPeriodC === globalSelectedPeriod) {
            window._dashboardStats = s;
            renderContactsStatTiles(s);
          }
        } catch (e) {}
      }).catch(function() {});
    } catch (err) {
      console.error('Error loading contacts tab:', err);
    }
  } else {
    stats = getEmptyStats();
    var select = document.getElementById('contacts-campaign-select');
    if (select) {
      select.innerHTML = '<option value="all">All Campaigns</option>';
      select.value = 'all';
    }
    
    var totalEl = document.getElementById('v-contacts-total');
    var repliedEl = document.getElementById('v-contacts-replied');
    var openedEl = document.getElementById('v-contacts-opened');
    var pendingEl = document.getElementById('v-contacts-pending');

    if (totalEl) totalEl.textContent = '0';
    if (repliedEl) repliedEl.textContent = '0';
    if (openedEl) openedEl.textContent = '0';
    if (pendingEl) pendingEl.textContent = '0';
  }

  try {
    await loadContactsList(globalSelectedCampaignId, skipLoader, skipCacheRender);
  } catch (err) {
    console.error('Error rendering contacts tab:', err);
  }
}

async function loadContactsList(campaignId, skipLoader, skipCacheRender) {
  var tbody = document.getElementById('contacts-list');
  if (!tbody) return;

  if (!activeAccount) {
    tbody.innerHTML = '<tr><td colSpan="5" style="text-align:center;padding:40px;color:var(--ol)">No contacts found.</td></tr>';
    return;
  }

  // Load from cache first
  try {
    var cachedContacts = localStorage.getItem('sndr_cached_contacts_' + activeAccount.id + '_' + campaignId);
    if (cachedContacts) {
      // Instant paint from this campaign's cached contacts, then the network render
      // dedupes below when the list is identical (no redundant table rebuild/flash).
      var parsedList = JSON.parse(cachedContacts);
      renderContactsList(parsedList, campaignId);
    }
  } catch (e) {}

  if (!skipLoader && (!tbody.children || tbody.children.length === 0)) {
    tbody.innerHTML = contactsSkeletonHtml();
  }

  try {
    var list = [];
    if (campaignId === 'all') {
      // ONE request for all contacts across campaigns (new backend endpoint).
      // The old per-campaign fan-out had a fatal failure mode: any single slow or
      // failed campaign fetch silently returned [] for that campaign, so entire
      // blocks of rows vanished from the table and reappeared on the next poll —
      // exactly the "contacts flicker after sending" glitch (the backend is at
      // its busiest mid-send, so fetches failed most right after sending).
      try {
        var allRows = await apiCall('GET', '/campaigns/all-contacts?account_id=' + activeAccount.id);
        list = (allRows || []).map(function(citem) {
          return { ...citem, campaignName: citem.campaign_name || '' };
        });
      } catch (allErr) {
        // Backend without the endpoint yet (or transient failure) → legacy
        // fan-out. If ANY campaign's fetch fails here, ABORT the render and keep
        // the rows on screen rather than painting a partial list.
        var campaigns = campaignsList.length > 0 ? campaignsList : await apiCall('GET', '/campaigns?account_id=' + activeAccount.id);
        if (campaigns && campaigns.length > 0) {
          var perCampaign = await Promise.all(campaigns.map(function(c) {
            return apiCall('GET', '/campaigns/' + c.id + '/contacts')
              .then(function(ctcts) { return (ctcts || []).map(function(citem) { return { ...citem, campaignName: c.name }; }); });
          }));
          perCampaign.forEach(function(arr) { list = list.concat(arr); });
        }
      }
    } else {
      // No inner catch: a failed fetch must reach the outer handler (keep the
      // current rows), NOT cache + render an empty list over real contacts.
      var ctcts = await apiCall('GET', '/campaigns/' + campaignId + '/contacts');
      list = ctcts.map(function(citem) { return { ...citem, campaignName: '' }; });
    }

    safeSetItem('sndr_cached_contacts_' + activeAccount.id + '_' + campaignId, JSON.stringify(list));
    if (campaignId === 'all') {
      safeSetItem('sndr_cached_overview_contacts', JSON.stringify(list));
    }

    renderContactsList(list, campaignId);
  } catch (err) {
    console.error('Error loading contacts list (keeping current rows):', err);
    // On a transient failure, keep the cache-painted rows. If NOTHING is on
    // screen yet, say the truth — "retrying" — never a false "No contacts
    // found" (the fetch failed; the contacts exist). The 8s poll retries and
    // replaces this the moment a fetch succeeds.
    if (!tbody.querySelector('.ct-cell')) {
      tbody.innerHTML = '<tr><td colSpan="5" style="text-align:center;padding:40px;color:var(--ol)">Contacts are taking longer than usual to load — retrying automatically…</td></tr>';
    }
  }
}

// Optimistic local update of a contact's follow-up state: patch the cached list
// and re-render instantly (no network), so Stop/Resume feel immediate.
function setContactFollowupLocal(contactId, status, campaignId) {
  try {
    var acctId = activeAccount ? activeAccount.id : '';
    var key = 'sndr_cached_contacts_' + acctId + '_' + campaignId;
    var raw = localStorage.getItem(key);
    if (!raw) return;
    var list = JSON.parse(raw);
    var changed = false;
    list.forEach(function(c) { if (c.id === contactId) { c.followup_status = status; changed = true; } });
    if (!changed) return;
    safeSetItem(key, JSON.stringify(list));
    if (campaignId === 'all') safeSetItem('sndr_cached_overview_contacts', JSON.stringify(list));
    renderContactsList(list, campaignId);
  } catch (e) {}
}

// One contact row's inner cells. Pure function of the contact → used both to
// build a new <tr> and to detect (via signature) whether an existing row changed.
function contactRowInnerHtml(c) {
  var initials = (c.name || c.email).split(' ').map(function(p){ return p[0]||''; }).slice(0,2).join('').toUpperCase();
  var company = c.company || '-';
  if (c.fields) {
    try { var fObj = JSON.parse(c.fields); if (fObj.company) company = fObj.company; } catch(e){}
  }

  var badgeColor = { pending: 'b-grey', sent: 'b-solid', opened: 'b-green', replied: 'b-blue', bounced: 'b-grey' }[c.status] || 'b-grey';
  var actButton = '';
  if (c.followup_status === 'pending') {
    var whenStr = c.followup_at ? new Date(c.followup_at * 1000).toLocaleDateString('en', { month: 'short', day: 'numeric' }) : '';
    actButton = '<button class="act-btn btn-stop-fu" data-id="' + c.id + '" title="Cancel the scheduled follow-up for this contact (e.g. if you already connected by call)" style="border-color:#fca5a5;color:#dc2626">Stop follow-up' + (whenStr ? ' · ' + escHtml(whenStr) : '') + '</button>';
  } else if (c.followup_status === 'cancelled') {
    actButton = '<button class="act-btn btn-resume-fu" data-id="' + c.id + '" title="Re-arm the follow-up for this contact" style="color:var(--p);border-color:var(--p20)">Resume follow-up</button>';
  } else if (c.status === 'sent') {
    actButton = '<button class="act-btn btn-sim-open" data-id="' + c.id + '">Simulate Open</button>';
  } else if (c.status === 'opened') {
    actButton = '<button class="act-btn btn-sim-reply" data-id="' + c.id + '" style="border-color: var(--lime); color: var(--lime)">Simulate Reply</button>';
  }

  var activityHtml = '';
  if (c.replied_at || c.status === 'replied') {
    var openStr = c.opened_at ? new Date(c.opened_at * 1000).toLocaleString('en', { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' }) : '-';
    var replyStr = c.replied_at ? new Date(c.replied_at * 1000).toLocaleString('en', { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' }) : '-';
    activityHtml += '<div style="font-weight:600;color:var(--lime-dim)">Replied</div>';
    if (c.reply_category) {
      activityHtml += '<div>' + replyCategoryBadge(c.reply_category) + '</div>';
      if (c.reply_snippet) {
        activityHtml += '<div style="font-size:10px;color:var(--ol);margin-top:2px;max-width:240px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="' + escHtml(c.reply_snippet) + '">' + escHtml(c.reply_snippet) + '</div>';
      }
    }
    activityHtml += '<div style="font-size:10px;color:var(--ol)">Opened: ' + openStr + '</div>';
    activityHtml += '<div style="font-size:10px;color:var(--ol)">Replied: ' + replyStr + '</div>';
    if (c.opened_at && c.replied_at) {
      var diff = c.replied_at - c.opened_at;
      var durationStr = '';
      if (diff < 0) { durationStr = '< 1m'; }
      else if (diff < 60) { durationStr = '< 1m'; }
      else if (diff < 3600) { durationStr = Math.round(diff / 60) + 'm'; }
      else if (diff < 86400) { var h = Math.floor(diff / 3600); var m = Math.round((diff % 3600) / 60); durationStr = h + 'h ' + m + 'm'; }
      else { var d = Math.floor(diff / 86400); var h = Math.round((diff % 86400) / 3600); durationStr = d + 'd ' + h + 'h'; }
      activityHtml += '<div style="font-size:10px;color:var(--lime);margin-top:2px;font-family:var(--mono)">Replied in ' + durationStr + '</div>';
    }
  } else if (c.opened_at) {
    var lastOpen = c.last_opened_at || c.opened_at;
    var cnt = c.open_count || 1;
    var openDate = new Date(lastOpen * 1000);
    var openStr = openDate.toLocaleString('en-IN', { weekday:'short', month:'short', day:'numeric', year:'numeric', hour:'2-digit', minute:'2-digit', hour12:true });
    activityHtml += '<div style="font-weight:600;color:var(--lime)">Opened ' + cnt + 'x</div>';
    activityHtml += '<div style="font-size:10px;color:var(--ol);margin-top:2px">' + (cnt > 1 ? 'Last: ' : '') + openStr + '</div>';
    var secAgo = Math.floor(Date.now()/1000) - lastOpen;
    var rel = secAgo < 60 ? 'just now' : secAgo < 3600 ? Math.floor(secAgo/60) + 'm ago' : secAgo < 86400 ? Math.floor(secAgo/3600) + 'h ago' : Math.floor(secAgo/86400) + 'd ago';
    activityHtml += '<div style="font-size:10px;color:var(--lime-dim);font-family:var(--mono)">' + rel + '</div>';
  } else {
    activityHtml += '<div style="color:var(--text3)">No activity</div>';
  }

  return '<td><div class="ct-cell"><div class="av">' + escHtml(initials) + '</div><div><div class="ct-name">' + escHtml(c.name || 'Unknown') + '</div><div class="ct-em">' + escHtml(c.email) + '</div></div></div></td>' +
    '<td>' + escHtml(company) + (c.campaignName ? ' <span style="font-size:10px;color:var(--ol)">(' + escHtml(c.campaignName) + ')</span>' : '') + '</td>' +
    '<td>' + activityHtml + '</td>' +
    '<td><span class="badge ' + badgeColor + '">' + c.status + '</span></td>' +
    '<td>' + actButton + '</td>';
}

// Delegated click handling for the contacts table + nudge queue — bound ONCE per
// container so incremental row updates never have to rebind per-button listeners.
function bindContactsDelegation(container) {
  if (!container || container._sndrDeleg) return;
  container._sndrDeleg = true;
  container.addEventListener('click', function(e) {
    var b = e.target.closest ? e.target.closest('button') : null;
    if (!b || !container.contains(b)) return;
    var id = b.getAttribute('data-id');
    if (!id) return;
    var cid = globalSelectedCampaignId;
    if (b.classList.contains('btn-sim-open')) {
      b.disabled = true;
      apiCall('POST', '/t/open/' + id)
        .then(function() { showToast('Simulated open recorded!'); loadContactsList(cid); })
        .catch(function(err) { showToast(err.message, true); b.disabled = false; });
    } else if (b.classList.contains('btn-sim-reply')) {
      b.disabled = true;
      apiCall('POST', '/t/reply/' + id)
        .then(function() { showToast('Simulated reply recorded!'); loadContactsList(cid); })
        .catch(function(err) { showToast(err.message, true); b.disabled = false; });
    } else if (b.classList.contains('btn-stop-fu')) {
      b.disabled = true;
      setContactFollowupLocal(id, 'cancelled', cid);
      apiCall('POST', '/campaigns/contacts/' + id + '/stop-followup')
        .then(function() { showToast('Follow-up stopped for this contact'); })
        .catch(function() { showToast('Could not stop follow-up', true); setContactFollowupLocal(id, 'pending', cid); });
    } else if (b.classList.contains('btn-resume-fu')) {
      b.disabled = true;
      setContactFollowupLocal(id, 'pending', cid);
      apiCall('POST', '/campaigns/contacts/' + id + '/resume-followup')
        .then(function() { showToast('Follow-up resumed for this contact'); })
        .catch(function() { showToast('Could not resume follow-up', true); setContactFollowupLocal(id, 'cancelled', cid); });
    }
  });
}

function renderContactsList(list, campaignId) {
  try {
    var tbody = document.getElementById('contacts-list');
    if (!tbody) return;

    var listString = JSON.stringify(list);
    // Skip a redundant rebuild when the data matches what's already on screen
    // (e.g. instant cache paint followed by an identical network response).
    if (window._lastContactsDataString === listString && tbody.children && tbody.children.length > 0) return;
    window._lastContactsDataString = listString;

    var total = list.length;
    var replied = list.filter(function(c) { return (c.replied_at !== null && c.replied_at !== undefined) || c.status === 'replied'; }).length;
    var opened = list.filter(function(c) { return (c.opened_at !== null && c.opened_at !== undefined) || c.status === 'opened' || c.status === 'replied'; }).length;
    var pending = list.filter(function(c) { return c.status === 'pending'; }).length;

    var totalEl = document.getElementById('v-contacts-total');
    var repliedEl = document.getElementById('v-contacts-replied');
    var openedEl = document.getElementById('v-contacts-opened');
    var pendingEl = document.getElementById('v-contacts-pending');

    if (totalEl) totalEl.textContent = total;
    if (repliedEl) {
      repliedEl.textContent = replied;
      var repliedDesc = repliedEl.nextElementSibling;
      if (repliedDesc && repliedDesc.classList.contains('mc-desc')) {
        var replyRate = total > 0 ? Math.round((replied / total) * 100) : 0;
        repliedDesc.textContent = replyRate + '% Reply Rate';
      }
    }
    if (openedEl) {
      openedEl.textContent = opened;
      var openedDesc = openedEl.nextElementSibling;
      if (openedDesc && openedDesc.classList.contains('mc-desc')) {
        var openRate = total > 0 ? Math.round((opened / total) * 100) : 0;
        openedDesc.textContent = openRate + '% Open Rate';
      }
    }
    if (pendingEl) pendingEl.textContent = pending;

    if (list.length === 0) {
      tbody.innerHTML = '<tr><td colSpan="5" style="text-align:center;padding:40px;color:var(--ol)">No contacts found.</td></tr>';
      return;
    }

    // ── Incremental keyed reconciliation — only changed rows are touched, so
    // unchanged rows never repaint (no flicker, scroll position preserved). ──
    var existing = {};
    Array.prototype.forEach.call(tbody.querySelectorAll('tr[data-cid]'), function(tr) {
      existing[tr.getAttribute('data-cid')] = tr;
    });

    var seen = {};
    var prev = null;
    list.forEach(function(c) {
      var id = String(c.id);
      seen[id] = true;
      var inner = contactRowInnerHtml(c);
      var tr = existing[id];
      if (!tr) {
        tr = document.createElement('tr');
        tr.setAttribute('data-cid', id);
        tr.dataset.sig = inner;
        tr.innerHTML = inner;
      } else if (tr.dataset.sig !== inner) {
        tr.dataset.sig = inner;
        tr.innerHTML = inner;        // only this row's cells repaint
      }
      // Place in the correct order, moving only rows that are actually misplaced.
      var ref = prev ? prev.nextSibling : tbody.firstChild;
      if (tr !== ref) tbody.insertBefore(tr, ref);
      prev = tr;
    });
    // Drop rows no longer present (and any stale placeholder row without a cid).
    Array.prototype.slice.call(tbody.children).forEach(function(node) {
      var cid = node.getAttribute ? node.getAttribute('data-cid') : null;
      if (!cid || !seen[cid]) tbody.removeChild(node);
    });

    bindContactsDelegation(tbody);

    // Nudge Queue: high-intent contacts (opened, no reply) that still have a pending
    // follow-up — a fast place to stop a follow-up right after you connect by call.
    var nudgeGrid = document.getElementById('nudge-grid');
    if (nudgeGrid) {
      var hot = list.filter(function(c) {
        var opened  = (c.opened_at != null) || c.status === 'opened';
        var replied = (c.replied_at != null) || c.status === 'replied';
        return c.followup_status === 'pending' && opened && !replied;
      });
      var nudgeHtml;
      if (hot.length === 0) {
        nudgeHtml = '<div style="font-size:12px;color:var(--ol);padding:10px;text-align:center;">No high intent contacts to nudge yet.</div>';
      } else {
        nudgeHtml = hot.slice(0, 6).map(function(c) {
          var nm = c.name || (c.email ? c.email.split('@')[0] : 'Contact');
          var ini = nm.split(' ').map(function(p){ return p[0] || ''; }).slice(0, 2).join('').toUpperCase();
          var whenStr = c.followup_at ? new Date(c.followup_at * 1000).toLocaleDateString('en', { month: 'short', day: 'numeric' }) : '';
          return '<div class="nq-item">' +
              '<div style="display:flex;align-items:center;gap:10px;min-width:0">' +
                '<div style="width:34px;height:34px;border-radius:50%;background:var(--p10);color:var(--p);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;flex-shrink:0">' + escHtml(ini || 'C') + '</div>' +
                '<div style="min-width:0;overflow:hidden">' +
                  '<div style="font-weight:600;font-size:13px;color:var(--tx);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + escHtml(nm) + '</div>' +
                  '<div style="font-size:11px;color:var(--ol)">Follow-up' + (whenStr ? ' · ' + escHtml(whenStr) : ' scheduled') + '</div>' +
                '</div>' +
              '</div>' +
              '<button class="btn-ol btn-stop-fu" data-id="' + c.id + '" title="Cancel the scheduled follow-up for this contact (e.g. if you already connected by call)" style="padding:5px 12px;font-size:11px;font-weight:600;border-color:#fca5a5;color:#dc2626;flex-shrink:0">Stop follow-up</button>' +
            '</div>';
        }).join('');
      }
      // Only repaint the nudge grid when its content actually changed (avoids a
      // needless innerHTML swap on every poll).
      if (nudgeGrid._sig !== nudgeHtml) { nudgeGrid._sig = nudgeHtml; nudgeGrid.innerHTML = nudgeHtml; }
      bindContactsDelegation(nudgeGrid);
    }
  } catch (err) {
    // Reset the dedup guard on failure so the next refresh retries instead of
    // short-circuiting on un-rendered data.
    window._lastContactsDataString = null;
    console.error('Error rendering contacts list details:', err);
  }
}

// Export contacts
var exportBtn = document.getElementById('btn-export-contacts');
if (exportBtn) {
  exportBtn.addEventListener('click', function() {
    var tbody = document.getElementById('contacts-list');
    if (!tbody) return;
    var rows = tbody.querySelectorAll('tr');
    if (rows.length === 0 || rows[0].textContent.includes('No contacts found')) {
      showToast('No contacts to export', true);
      return;
    }

    var csvContent = 'data:text/csv;charset=utf-8,Name,Email,Company,Status\n';
    rows.forEach(function(row) {
      var cols = row.querySelectorAll('td');
      if (cols.length < 4) return;

      var name = cols[0].querySelector('.ct-name').textContent.replace(/"/g, '""');
      var email = cols[0].querySelector('.ct-em').textContent.replace(/"/g, '""');
      var company = cols[1].textContent.replace(/"/g, '""');
      var status = cols[3].textContent.replace(/"/g, '""');

      csvContent += '"' + name + '","' + email + '","' + company + '","' + status + '"\n';
    });

    var encodedUri = encodeURI(csvContent);
    var link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'sndr_contacts.csv');
    document.body.appendChild(link);
    link.click();
    link.remove();
    showToast('Contacts exported successfully!');
  });
}

// ── Settings Screen ─────────────────────────────────────────
// Paint the Gmail Connection card for the given account (or no-account) state:
//   connected     -> green CONNECTED badge + "Disconnect Account"
//   disconnected  -> amber DISCONNECTED badge + "Reconnect Gmail"
//   no account    -> red NOT CONNECTED badge + "Connect Gmail"
function renderConnectionCard(account) {
  var dispName = document.getElementById('settings-display-name');
  var replyEmail = document.getElementById('settings-reply-email');
  var connEmail = document.getElementById('settings-gmail-connection-email');
  var connStatus = document.getElementById('settings-gmail-connection-status');
  var connectGmailBtn = document.getElementById('btn-connect-gmail');
  var disconnectGmailBtn = document.getElementById('btn-disconnect-gmail');
  var accountHelp = document.getElementById('settings-account-help');

  if (account && !isAccountConnected(account)) {
    if (dispName) dispName.value = account.name || '';
    if (replyEmail) replyEmail.value = account.email || '';
    if (connEmail) connEmail.textContent = account.email || '-';
    if (connStatus) {
      connStatus.textContent = 'Disconnected';
      connStatus.className = 'badge b-amber';
    }
    if (connectGmailBtn) {
      connectGmailBtn.style.display = 'inline-flex';
      connectGmailBtn.innerHTML = '<span class="mi" style="font-size:14px">link</span>Reconnect Gmail';
    }
    if (disconnectGmailBtn) disconnectGmailBtn.style.display = 'none';
    if (accountHelp) accountHelp.style.display = 'block';
  } else if (account) {
    if (dispName) dispName.value = account.name || '';
    if (replyEmail) replyEmail.value = account.email || '';
    if (connEmail) connEmail.textContent = account.email || '-';
    if (connStatus) {
      connStatus.textContent = 'Connected';
      connStatus.className = 'badge b-green';
    }
    if (connectGmailBtn) connectGmailBtn.style.display = 'none';
    if (disconnectGmailBtn) disconnectGmailBtn.style.display = 'inline-flex';
    if (accountHelp) accountHelp.style.display = 'block';
  } else {
    if (dispName) dispName.value = '';
    if (replyEmail) replyEmail.value = '';
    if (connEmail) connEmail.textContent = 'No Gmail account connected';
    if (connStatus) {
      connStatus.textContent = 'Not Connected';
      connStatus.className = 'badge b-red';
    }
    if (connectGmailBtn) {
      connectGmailBtn.style.display = 'inline-flex';
      connectGmailBtn.innerHTML = '<span class="mi" style="font-size:14px">link</span>Connect Gmail';
    }
    if (disconnectGmailBtn) disconnectGmailBtn.style.display = 'none';
    if (accountHelp) accountHelp.style.display = 'none';
  }
}

async function loadSettings() {
  if (!activeAccount && !sidebarInitialized) {
    await loadSidebar(false);
  }

  var backendUrlInput = document.getElementById('settings-backend-url');
  if (backendUrlInput) {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['custom_api_url'], function(data) {
        backendUrlInput.value = data.custom_api_url || 'https://sndr-f4rg.onrender.com';
      });
    } else {
      backendUrlInput.value = API_URL;
    }
  }

  // Instant paint from what we know, then VERIFY against a fresh server
  // response — the connection badge must reflect the database truth, never a
  // stale in-memory/cached flag.
  renderConnectionCard(activeAccount);
  if (activeAccount) {
    try {
      var freshAccounts = await apiCall('GET', '/auth/accounts');
      if (freshAccounts && freshAccounts.length > 0) {
        activeAccount = freshAccounts[0];
        safeSetItem('sndr_cached_accounts', JSON.stringify(freshAccounts));
        renderConnectionCard(activeAccount);
      } else {
        activeAccount = null;
        renderConnectionCard(null);
      }
    } catch (e) { /* keep the instant paint on a transient failure */ }
  }
}

var saveSettingsBtn = document.getElementById('btn-save-settings');
if (saveSettingsBtn) {
  saveSettingsBtn.addEventListener('click', async function() {
    if (!activeAccount) return;
    var dispName = document.getElementById('settings-display-name');
    if (!dispName) return;

    try {
      saveSettingsBtn.disabled = true;
      saveSettingsBtn.textContent = 'Saving...';
      await apiCall('PUT', '/auth/accounts/' + activeAccount.id, { name: dispName.value });
      showToast('Settings saved successfully!');
      await loadSidebar();
      await loadSettings();
    } catch (err) {
      showToast(err.message, true);
    } finally {
      saveSettingsBtn.disabled = false;
      saveSettingsBtn.textContent = 'Save Settings';
    }
  });
}

var saveBackendUrlBtn = document.getElementById('btn-save-backend-url');
if (saveBackendUrlBtn) {
  saveBackendUrlBtn.addEventListener('click', async function() {
    var urlInput = document.getElementById('settings-backend-url');
    if (!urlInput) return;
    var rawUrl = urlInput.value.trim();
    if (!rawUrl) {
      showToast('Backend URL cannot be empty', true);
      return;
    }
    if (rawUrl.endsWith('/')) {
      rawUrl = rawUrl.slice(0, -1);
    }
    
    try {
      saveBackendUrlBtn.disabled = true;
      saveBackendUrlBtn.textContent = 'Saving...';
      
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        await new Promise(function(resolve) {
          chrome.storage.local.set({ custom_api_url: rawUrl }, function() {
            API_URL = rawUrl;
            resolve();
          });
        });
        showToast('Backend URL saved! Reloading data...');
        await loadSidebar();
        var activeScreen = document.querySelector('.screen.on');
        if (activeScreen && activeScreen.id === 'screen-overview') {
          await loadOverview(false);
        } else {
          goNav('overview');
        }
      } else {
        API_URL = rawUrl;
        showToast('Backend URL saved locally!');
      }
    } catch (err) {
      showToast(err.message, true);
    } finally {
      saveBackendUrlBtn.disabled = false;
      saveBackendUrlBtn.textContent = 'Save Backend URL';
    }
  });
}

var connectGmailBtn = document.getElementById('btn-connect-gmail');
if (connectGmailBtn) {
  connectGmailBtn.addEventListener('click', async function() {
    try {
      var res = await apiCall('GET', '/auth/url');
      if (res && res.url) {
        if (typeof chrome !== 'undefined' && chrome.tabs) {
          chrome.tabs.create({ url: res.url });
        } else {
          window.open(res.url, '_blank');
        }
      }
    } catch (err) {
      showToast(err.message, true);
    }
  });
}

var disconnectGmailBtn = document.getElementById('btn-disconnect-gmail');
if (disconnectGmailBtn) {
  disconnectGmailBtn.addEventListener('click', async function() {
    if (!activeAccount) return;
    if (!confirm('Disconnect this Gmail account? Sending will pause, but all your campaigns, contacts, and analytics are kept. Reconnect the same Gmail any time to pick up exactly where you left off.')) {
      return;
    }
    try {
      disconnectGmailBtn.disabled = true;
      disconnectGmailBtn.textContent = 'Disconnecting...';
      // Non-destructive: clears tokens only, keeps all data (was a destructive DELETE).
      await apiCall('POST', '/auth/accounts/' + activeAccount.id + '/disconnect');
      showToast('Gmail disconnected. Your data is safe — reconnect any time to restore access.');
      // Reflect the disconnect IMMEDIATELY (in-memory + cache), so the settings
      // repaint below shows "Disconnected" even before the network refresh.
      activeAccount.connected = false;
      try {
        var cachedAccs = JSON.parse(localStorage.getItem('sndr_cached_accounts') || '[]');
        cachedAccs.forEach(function(a) { if (a.id === activeAccount.id) a.connected = false; });
        safeSetItem('sndr_cached_accounts', JSON.stringify(cachedAccs));
      } catch (e) {}
      await loadSidebar();
      await loadSettings();
      // Reload overview to reflect disconnected state (e.g. empty stats)
      var activeScreen = document.querySelector('.screen.on');
      if (activeScreen && activeScreen.id === 'screen-overview') {
        await loadOverview(true);
      }
    } catch (err) {
      showToast(err.message, true);
    } finally {
      disconnectGmailBtn.disabled = false;
      disconnectGmailBtn.innerHTML = '<span class="mi" style="font-size:14px">link_off</span>Disconnect Account';
    }
  });
}

// "Delete account & all data" was removed from the UI entirely — Disconnect
// (non-destructive, reversible) is the only account action users need; the
// destructive DELETE endpoint still exists server-side but has no button.

// ── New Campaign Wizard Logic ──────────────────────────────
var uploadedFile = null;
var parsedHeaders = [];
var parsedRows = [];
var campaignAttachments = [];
var campaignFollowupSteps = [];

var _saveTimeout = null;
window.saveComposeState = function() {
  if (_saveTimeout) clearTimeout(_saveTimeout);
  _saveTimeout = setTimeout(function() {
    var state = {
      step: window.currentComposeStep || 1,
      campaignName: document.getElementById('comp-campaign-name') ? document.getElementById('comp-campaign-name').value : '',
      subject: document.getElementById('comp-subject') ? document.getElementById('comp-subject').value : '',
      bodyHtml: document.getElementById('comp-body') ? document.getElementById('comp-body').innerHTML : '',
      // Store only the file NAME — a File object serializes to {} (caused the
      // "File loaded: undefined" bug); the actual data is in parsedRows.
      uploadedFile: uploadedFile ? { name: uploadedFile.name } : null,
      parsedHeaders: parsedHeaders,
      parsedRows: parsedRows,
      // Do NOT persist attachment base64 — it can blow the ~5MB localStorage quota
      // and corrupt the entire draft. Keep only names so we can show what was attached.
      campaignAttachments: [],
      attachmentNames: (campaignAttachments || []).map(function(a) { return a.filename || a.name || 'file'; }),
      // Follow-up steps carry their OWN attachment base64 — strip it for the same
      // reason (a single 5MB file is ~6.7MB of base64 and overflows the draft quota,
      // which threw the "entry too big" error). Strip on a COPY so the live
      // campaignFollowupSteps the actual create/send request uses is untouched; set
      // attachments to [] (not {filename}) so a restored draft never sends an empty file.
      campaignFollowupSteps: (campaignFollowupSteps || []).map(function(s) {
        return Object.assign({}, s, { attachments: [] });
      }),
      // Names of per-step attachments (bytes stripped above) so a restored draft
      // can tell the user exactly what needs re-attaching.
      stepAttachmentNames: (campaignFollowupSteps || []).map(function(s) {
        return (s.attachments || []).map(function(a) { return a.filename || a.name || 'file'; });
      }),
      mapEmail: document.getElementById('map-email-col') ? document.getElementById('map-email-col').value : '',
      mapName: document.getElementById('map-name-col') ? document.getElementById('map-name-col').value : '',
      mapCompany: document.getElementById('map-company-col') ? document.getElementById('map-company-col').value : '',
      mapRole: document.getElementById('map-role-col') ? document.getElementById('map-role-col').value : '',
      useSignature: document.getElementById('comp-use-signature') ? document.getElementById('comp-use-signature').checked : false,
      signatureText: document.getElementById('comp-signature-text') ? document.getElementById('comp-signature-text').value : '',
      schedLater: document.getElementById('sched-later') ? document.getElementById('sched-later').classList.contains('sel') : false,
      scheduleTime: document.getElementById('comp-schedule-time') ? document.getElementById('comp-schedule-time').value : '',
      gsheetUrl: document.getElementById('campaign-gsheet-url') ? document.getElementById('campaign-gsheet-url').value : ''
    };
    // NOTE: deliberately the raw setItem — this save NEEDS the QuotaExceeded
    // throw so the fallback below can retry without the heavy recipient rows.
    try {
      localStorage.setItem('sndr_compose_state', JSON.stringify(state));
    } catch (e) {
      // Quota exceeded (very large recipient list) — retry without the heavy rows
      // so the rest of the draft (subject/body/settings) still persists.
      try {
        state.parsedRows = [];
        state.parsedHeaders = [];
        localStorage.setItem('sndr_compose_state', JSON.stringify(state));
      } catch (e2) {}
    }
  }, 100);
};

window.clearComposeState = function() {
  localStorage.removeItem('sndr_compose_state');
};

function restoreComposeState() {
  var saved = localStorage.getItem('sndr_compose_state');
  if (!saved) return;
  try {
    var state = JSON.parse(saved);
    if (!state) return;

    uploadedFile = state.uploadedFile || null;
    parsedHeaders = state.parsedHeaders || [];
    parsedRows = state.parsedRows || [];
    campaignAttachments = state.campaignAttachments || [];
    campaignFollowupSteps = state.campaignFollowupSteps || [];
    window.currentComposeStep = state.step || 1;

    // Attachment BYTES are never persisted in the draft (localStorage quota) —
    // only their names. Surface that loudly instead of silently launching the
    // campaign without the files the user thinks are attached.
    var droppedNames = (state.attachmentNames || []).slice();
    (state.stepAttachmentNames || []).forEach(function(names, i) {
      (names || []).forEach(function(n) { droppedNames.push(n + ' (follow-up step ' + (i + 1) + ')'); });
    });
    window._restoredDroppedAttachments = droppedNames.length ? droppedNames : null;
    if (droppedNames.length) {
      showToast('Draft restored — please re-attach: ' + droppedNames.join(', '), true);
    }

    if (document.getElementById('comp-campaign-name')) {
      document.getElementById('comp-campaign-name').value = state.campaignName || '';
    }
    if (document.getElementById('comp-subject')) {
      document.getElementById('comp-subject').value = state.subject || '';
    }
    if (document.getElementById('comp-body')) {
      document.getElementById('comp-body').innerHTML = state.bodyHtml || '';
    }
    if (document.getElementById('comp-signature-text')) {
      document.getElementById('comp-signature-text').value = state.signatureText || '';
    }
    if (document.getElementById('comp-use-signature')) {
      document.getElementById('comp-use-signature').checked = !!state.useSignature;
      var sigWrapper = document.getElementById('comp-signature-wrapper');
      if (sigWrapper) sigWrapper.style.display = state.useSignature ? 'block' : 'none';
    }
    if (state.gsheetUrl && document.getElementById('campaign-gsheet-url')) {
      document.getElementById('campaign-gsheet-url').value = state.gsheetUrl;
    }

    if (uploadedFile) {
      var statusTitle = document.getElementById('upload-status-title');
      var statusSub = document.getElementById('upload-status-sub');
      var uploadContinueBtn = document.getElementById('btn-upload-continue');
      var dropZone = document.getElementById('drop-zone');

      if (statusTitle) statusTitle.textContent = 'File loaded: ' + uploadedFile.name;
      if (statusSub) statusSub.textContent = parsedRows.length + ' rows';
      if (uploadContinueBtn) uploadContinueBtn.disabled = false;
      if (dropZone) dropZone.style.borderColor = 'var(--p)';

      setupMappingDropdowns();
      setupMappingPreviewTable();

      if (state.mapEmail && document.getElementById('map-email-col')) {
        document.getElementById('map-email-col').value = state.mapEmail;
      }
      if (state.mapName && document.getElementById('map-name-col')) {
        document.getElementById('map-name-col').value = state.mapName;
      }
      if (state.mapCompany && document.getElementById('map-company-col')) {
        document.getElementById('map-company-col').value = state.mapCompany;
      }
      if (state.mapRole && document.getElementById('map-role-col')) {
        document.getElementById('map-role-col').value = state.mapRole;
      }
    }

    if (state.schedLater) {
      if (document.getElementById('sched-later')) document.getElementById('sched-later').classList.add('sel');
      if (document.getElementById('sched-now')) document.getElementById('sched-now').classList.remove('sel');
      var pk = document.getElementById('sched-picker');
      if (pk) pk.style.display = 'block';
    } else {
      if (document.getElementById('sched-now')) document.getElementById('sched-now').classList.add('sel');
      if (document.getElementById('sched-later')) document.getElementById('sched-later').classList.remove('sel');
      var pk = document.getElementById('sched-picker');
      if (pk) pk.style.display = 'none';
    }
    if (state.scheduleTime && document.getElementById('comp-schedule-time')) {
      document.getElementById('comp-schedule-time').value = state.scheduleTime;
    }

    updatePreviewStepSelect();
    renderFollowupSteps();
    goStep(window.currentComposeStep);
  } catch (e) {
    console.error('Error restoring compose state:', e);
  }
}

function setupComposeAutoSave() {
  // initDashboard() runs again after an in-page login; never double-bind the
  // compose listeners (double saves + duplicate step-list handlers).
  if (window._composeAutoSaveSet) return;
  window._composeAutoSaveSet = true;
  var inputs = [
    'comp-campaign-name',
    'comp-subject',
    'comp-body',
    'comp-use-signature',
    'comp-signature-text',
    'comp-schedule-time',
    'map-email-col',
    'map-name-col',
    'map-company-col',
    'map-role-col',
    'campaign-gsheet-url'
  ];

  inputs.forEach(function(id) {
    var el = document.getElementById(id);
    if (el) {
      var eventType = (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.id === 'comp-body') ? 'input' : 'change';
      el.addEventListener(eventType, function() {
        window.saveComposeState();
      });
    }
  });

  var schedNow = document.getElementById('sched-now');
  var schedLater = document.getElementById('sched-later');
  if (schedNow) {
    schedNow.addEventListener('click', function() {
      setTimeout(window.saveComposeState, 50);
    });
  }
  if (schedLater) {
    schedLater.addEventListener('click', function() {
      setTimeout(window.saveComposeState, 50);
    });
  }

  var listEl = document.getElementById('followup-steps-list');
  if (listEl) {
    listEl.addEventListener('input', function() {
      window.saveComposeState();
    });
    listEl.addEventListener('change', function() {
      window.saveComposeState();
    });
  }
}

function resetComposeWizard() {
  uploadedFile = null;
  parsedHeaders = [];
  parsedRows = [];
  campaignAttachments = [];
  window.clearComposeState();

  var statusTitle = document.getElementById('upload-status-title');
  var statusSub = document.getElementById('upload-status-sub');
  var continueBtn = document.getElementById('btn-upload-continue');
  var fileInput = document.getElementById('campaign-file-input');
  var gsheetUrlInput = document.getElementById('campaign-gsheet-url');

  if (statusTitle) statusTitle.textContent = 'Drag & Drop your CSV file here';
  if (statusSub) statusSub.textContent = 'Or click to select a file from your device';
  if (continueBtn) continueBtn.disabled = true;
  if (fileInput) fileInput.value = '';
  if (gsheetUrlInput) gsheetUrlInput.value = '';

  var dropZone = document.getElementById('drop-zone');
  if (dropZone) dropZone.style.borderColor = 'rgba(0,88,190,.2)';

  // Reset inputs
  var cName = document.getElementById('comp-campaign-name');
  var cSubject = document.getElementById('comp-subject');
  var cBody = document.getElementById('comp-body');
  if (cName) cName.value = '';
  if (cSubject) cSubject.value = '';
  if (cBody) cBody.innerHTML = 'Hi {first_name},<br><br>I noticed you work at {company} and would love to connect...<br><br>Best,<br>Outreach Team';

  var attachmentsInput = document.getElementById('comp-attachments');
  var attachmentsListEl = document.getElementById('attachments-list');
  if (attachmentsInput) attachmentsInput.value = '';
  if (attachmentsListEl) attachmentsListEl.innerHTML = '';

  // Reset scheduling + signature. These were NOT reset before, so a new campaign
  // silently inherited the PREVIOUS campaign's "Schedule later" time (wrong send
  // time, or a "time is in the past" launch error) and its signature.
  var schedNow = document.getElementById('sched-now');
  var schedLater = document.getElementById('sched-later');
  if (schedNow) schedNow.classList.add('sel');
  if (schedLater) schedLater.classList.remove('sel');
  var schedPicker = document.getElementById('sched-picker');
  if (schedPicker) schedPicker.style.display = 'none';
  var schedTime = document.getElementById('comp-schedule-time');
  if (schedTime) schedTime.value = '';
  var useSig = document.getElementById('comp-use-signature');
  if (useSig) useSig.checked = false;
  var sigText = document.getElementById('comp-signature-text');
  if (sigText) sigText.value = '';
  var sigWrap = document.getElementById('comp-signature-wrapper');
  if (sigWrap) sigWrap.style.display = 'none';
  window._restoredDroppedAttachments = null;

  campaignFollowupSteps = [];
  updatePreviewStepSelect();
  renderFollowupSteps();

  goStep(1);
}

function updatePreviewStepSelect() {
  var select = document.getElementById('preview-step-select');
  if (!select) return;
  var currentVal = select.value;
  select.innerHTML = '<option value="main">Main Email</option>';
  campaignFollowupSteps.forEach(function(step, idx) {
    var opt = document.createElement('option');
    opt.value = idx.toString();
    opt.textContent = 'Follow-up Step ' + step.step;
    select.appendChild(opt);
  });
  if (currentVal && select.querySelector('option[value="' + currentVal + '"]')) {
    select.value = currentVal;
  } else {
    select.value = 'main';
  }
}

function renderFollowupSteps() {
  var listEl = document.getElementById('followup-steps-list');
  if (!listEl) return;
  listEl.innerHTML = '';

  // Follow-ups reply in the SAME Gmail thread, so the subject is always the main
  // email's subject — shown frozen (read-only) in each step, not editable.
  var mainSubjectEl = document.getElementById('comp-subject');
  var mainSubject = mainSubjectEl ? (mainSubjectEl.value || '') : '';
  var safeMainSubject = String(mainSubject).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  campaignFollowupSteps.forEach(function(step, idx) {
    var stepCard = document.createElement('div');
    stepCard.className = 'card';
    stepCard.style.padding = '12px 14px';
    stepCard.style.border = '1px solid var(--border)';
    stepCard.style.background = 'var(--navy2)';
    stepCard.style.display = 'flex';
    stepCard.style.flexDirection = 'column';
    stepCard.style.gap = '8px';
    stepCard.style.position = 'relative';

    var hasDate = !!step.specific_date;

    stepCard.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border); padding-bottom:6px">
        <span style="font-size:12.5px; font-weight:700; color:var(--p)">Step ${step.step}</span>
        <button type="button" class="btn-remove-step btn-ol" data-index="${idx}" style="color:var(--danger); border-color:rgba(255,77,106,0.3); padding:2px 6px; font-size:10.5px">Remove</button>
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px">
        <div>
          <label class="form-label" style="font-size:10px">Schedule Mode</label>
          <select class="form-input select-step-mode" data-index="${idx}" style="font-size:11px; padding:4px 6px">
            <option value="days" ${!hasDate ? 'selected' : ''}>Relative Delay</option>
            <option value="date" ${hasDate ? 'selected' : ''}>Specific Date</option>
          </select>
        </div>
        <div>
          ${hasDate ? `
            <label class="form-label" style="font-size:10px">Target Date</label>
            <input type="date" class="form-input input-step-date" data-index="${idx}" value="${step.specific_date}" style="font-size:11px; padding:4px 6px">
          ` : `
            <label class="form-label" style="font-size:10px">Wait Days</label>
            <input type="number" min="1" max="90" class="form-input input-step-days" data-index="${idx}" value="${step.delay_days}" style="font-size:11px; padding:4px 6px">
          `}
        </div>
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px">
        <div>
          <label class="form-label" style="font-size:10px">Send Time</label>
          <input type="time" class="form-input input-step-time" data-index="${idx}" value="${step.send_time || '09:00'}" style="font-size:11px; padding:4px 6px">
        </div>
        <div>
          <label class="form-label" style="font-size:10px">Condition</label>
          <select class="form-input select-step-trigger" data-index="${idx}" style="font-size:11px; padding:4px 6px">
            <option value="no_reply" ${step.trigger === 'no_reply' ? 'selected' : ''}>If no reply</option>
            <option value="opened_no_reply" ${step.trigger === 'opened_no_reply' ? 'selected' : ''}>If opened, no reply</option>
            <option value="no_open" ${step.trigger === 'no_open' ? 'selected' : ''}>If not opened</option>
          </select>
        </div>
      </div>

      <div style="display:flex; gap:8px; align-items:center">
        <select class="form-input select-step-template" data-index="${idx}" style="font-size:11px; padding:4px 6px; flex:1">
          <option value="">-- Load Saved Template --</option>
          ${savedTemplates.map(t => `<option value="${t.id}">${t.name}</option>`).join('')}
        </select>
        <button type="button" class="btn-save-step-template btn-ol" data-index="${idx}" style="padding:4px 8px; font-size:11px">Save Template</button>
        <button type="button" class="btn-delete-step-template btn-ol" data-index="${idx}" title="Delete the selected saved template" style="padding:4px 8px; font-size:11px; color:var(--red); border-color:rgba(186,26,26,0.2)">Delete</button>
      </div>

      <div>
        <label class="form-label" style="font-size:10px; margin:0 0 4px 0; display:block">Subject (same thread as the main email)</label>
        <input type="text" class="form-input" value="${safeMainSubject}" disabled title="Follow-ups reply in the same Gmail thread, so the subject always matches the main email and can't be changed." style="font-size:11px; padding:4px 6px; width:100%; opacity:0.65; cursor:not-allowed; background:var(--navy2)">
      </div>

      <div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 4px">
          <label class="form-label" style="font-size:10px; margin:0">Body</label>
          <div style="display:flex; gap:4px">
            <button type="button" class="btn-step-ai btn-ol" data-index="${idx}" style="white-space:nowrap; font-size:10px; padding:2px 6px; color:var(--p); border-color:var(--p20); background:var(--p05)">AI ✦</button>
            <button type="button" class="btn-step-tag-body btn-ol" data-index="${idx}" style="white-space:nowrap; font-size:10px; padding:2px 6px">{ } tag</button>
          </div>
        </div>

        <!-- Collapsible AI Follow-up Panel -->
        <div id="ai-step-panel-${idx}" style="display:none; background:var(--sf-lo); border:1px solid var(--p10); border-radius:var(--r2); padding:10px; margin-bottom:8px; font-size:11.5px">
          <div style="font-size:11px; font-weight:700; color:var(--p); margin-bottom:6px">&#x2726; AI Follow-up Writer</div>
          
          <div style="margin-bottom:8px">
            <select id="ai-step-template-${idx}" class="form-input select-step-ai-template" data-index="${idx}" style="font-size:11px; padding:4px 6px; width:100%">
              <option value="context" selected>Draft based on main email body</option>
              <option value="spellcheck">Spell Check &amp; Improve Flow</option>
              <option value="internship">Reach out for an Internship</option>
              <option value="job">Reach out for a Job Opening</option>
              <option value="partnership">Business Partnership / Collaboration</option>
              <option value="custom">Custom Prompt...</option>
            </select>
          </div>
          
          <div id="ai-step-prompt-container-${idx}" style="display:none; margin-bottom:8px">
            <textarea id="ai-step-prompt-${idx}" class="form-input" style="height:50px; font-size:11px; padding:4px 6px; resize:vertical; line-height:1.4" placeholder="e.g. Ask if they read my previous email, and offer a short 10-minute call next Tuesday."></textarea>
          </div>
          
          <div style="display:flex; justify-content:flex-end; gap:6px; align-items:center">
            <span id="ai-step-loading-${idx}" style="display:none; color:var(--ol); font-size:10.5px; margin-right:auto">Generating...</span>
            <button type="button" class="btn-step-ai-generate btn-ol" data-index="${idx}" style="padding:4px 10px; font-size:10.5px; background:var(--p); color:#fff; border:none; font-weight:600; border-radius:var(--r2); cursor:pointer">Generate</button>
          </div>
        </div>

        <textarea class="form-input input-step-body" data-index="${idx}" style="height:100px; font-size:13px; line-height:1.7; padding:10px; font-family:inherit; resize:vertical" placeholder="Hi {first_name}, ...">${step.body || ''}</textarea>
      </div>

      <div>
        <div style="display:flex; justify-content:space-between; align-items:center">
          <label class="form-label" style="font-size:10px; display:flex; align-items:center; gap:6px; text-transform:none; margin:0">
            <input type="checkbox" class="check-step-sig" data-index="${idx}" ${step.use_signature ? 'checked' : ''}>
            Add Email Signature
          </label>
          <button type="button" class="btn-upload-step-sig btn-ol" data-index="${idx}" style="font-size:10px; padding:2px 6px; display:${step.use_signature ? 'inline-block' : 'none'}">Upload Signature</button>
          <input type="file" class="input-step-sig-file" data-index="${idx}" accept="image/*,text/html,text/plain" style="display:none">
        </div>
        <textarea class="form-input input-step-sig-text" data-index="${idx}" style="height:45px; font-size:11px; padding:4px; margin-top:4px; display:${step.use_signature ? 'block' : 'none'}" placeholder="Type your signature here...">${step.signature || ''}</textarea>
      </div>

      <div>
        <label class="form-label" style="font-size:10px">Attachments</label>
        <input type="file" class="input-step-attachments" data-index="${idx}" multiple style="font-size:10px; padding:2px">
        <div class="step-attachments-list" data-index="${idx}" style="margin-top:4px; display:flex; flex-direction:column; gap:3px">
          ${(step.attachments || []).map((file, fIdx) => `
            <div style="display:flex; align-items:center; justify-content:space-between; background:var(--p05); padding:2px 6px; borderRadius:3px; border:1px solid var(--border)">
              <span style="font-size:10.5px; color:var(--text)">${file.filename}</span>
              <button type="button" class="btn-remove-step-attach" data-step-index="${idx}" data-attach-index="${fIdx}" style="background:none; border:none; color:var(--danger); cursor:pointer; font-size:12px; line-height:1">×</button>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    listEl.appendChild(stepCard);
  });

  listEl.querySelectorAll('.btn-remove-step').forEach(btn => {
    btn.addEventListener('click', function() {
      var index = parseInt(this.getAttribute('data-index'));
      campaignFollowupSteps.splice(index, 1);
      campaignFollowupSteps.forEach((s, i) => s.step = i + 1);
      updatePreviewStepSelect();
      renderFollowupSteps();
      updateLivePreview();
      if (typeof window.saveComposeState === 'function') window.saveComposeState();
    });
  });

  listEl.querySelectorAll('.select-step-mode').forEach(sel => {
    sel.addEventListener('change', function() {
      var index = parseInt(this.getAttribute('data-index'));
      if (this.value === 'date') {
        campaignFollowupSteps[index].specific_date = new Date().toISOString().split('T')[0];
        campaignFollowupSteps[index].delay_days = 0;
      } else {
        campaignFollowupSteps[index].specific_date = '';
        campaignFollowupSteps[index].delay_days = 3;
      }
      renderFollowupSteps();
    });
  });

  listEl.querySelectorAll('.input-step-days').forEach(inp => {
    inp.addEventListener('input', function() {
      var index = parseInt(this.getAttribute('data-index'));
      campaignFollowupSteps[index].delay_days = parseInt(this.value) || 3;
    });
  });

  listEl.querySelectorAll('.input-step-date').forEach(inp => {
    inp.addEventListener('change', function() {
      var index = parseInt(this.getAttribute('data-index'));
      campaignFollowupSteps[index].specific_date = this.value;
    });
  });

  listEl.querySelectorAll('.input-step-time').forEach(inp => {
    inp.addEventListener('change', function() {
      var index = parseInt(this.getAttribute('data-index'));
      campaignFollowupSteps[index].send_time = this.value;
    });
  });

  listEl.querySelectorAll('.select-step-trigger').forEach(sel => {
    sel.addEventListener('change', function() {
      var index = parseInt(this.getAttribute('data-index'));
      campaignFollowupSteps[index].trigger = this.value;
      updateLivePreview();
    });
  });

  listEl.querySelectorAll('.input-step-subject').forEach(inp => {
    inp.addEventListener('input', function() {
      var index = parseInt(this.getAttribute('data-index'));
      campaignFollowupSteps[index].subject = this.value;
      updateLivePreview();
      if (typeof window.saveComposeState === 'function') window.saveComposeState();
    });
  });

  listEl.querySelectorAll('.input-step-body').forEach(inp => {
    inp.addEventListener('input', function() {
      var index = parseInt(this.getAttribute('data-index'));
      campaignFollowupSteps[index].body = this.value;
      updateLivePreview();
      if (typeof window.saveComposeState === 'function') window.saveComposeState();
    });
  });

  listEl.querySelectorAll('.check-step-sig').forEach(chk => {
    chk.addEventListener('change', function() {
      var index = parseInt(this.getAttribute('data-index'));
      campaignFollowupSteps[index].use_signature = this.checked;
      var parent = this.closest('div');
      var sigTextarea = parent.parentElement.querySelector('.input-step-sig-text');
      var uploadBtn = parent.querySelector('.btn-upload-step-sig');
      if (sigTextarea) {
        sigTextarea.style.display = this.checked ? 'block' : 'none';
      }
      if (uploadBtn) {
        uploadBtn.style.display = this.checked ? 'inline-block' : 'none';
      }
      updateLivePreview();
      if (typeof window.saveComposeState === 'function') window.saveComposeState();
    });
  });

  listEl.querySelectorAll('.btn-upload-step-sig').forEach(btn => {
    btn.addEventListener('click', function() {
      var parent = this.closest('div');
      var fileInput = parent.querySelector('.input-step-sig-file');
      if (fileInput) fileInput.click();
    });
  });

  listEl.querySelectorAll('.input-step-sig-file').forEach(inp => {
    inp.addEventListener('change', function() {
      var index = parseInt(this.getAttribute('data-index'));
      var file = this.files[0];
      if (!file) return;
      var parent = this.closest('div').parentElement;
      var sigTextarea = parent.querySelector('.input-step-sig-text');
      var reader = new FileReader();
       var isImg = file.type.startsWith('image/') || /\.(png|jpg|jpeg|gif|webp|svg|bmp|ico)$/i.test(file.name);
      if (isImg) {
        reader.onload = function(e) {
          if (sigTextarea) {
            sigTextarea.value += '\n<img src="' + e.target.result + '" style="max-width:150px; max-height:80px; object-fit:contain;">';
            campaignFollowupSteps[index].signature = sigTextarea.value;
            updateLivePreview();
            if (typeof window.saveComposeState === 'function') window.saveComposeState();
          }
        };
        reader.readAsDataURL(file);
      } else {
        reader.onload = function(e) {
          var txt = e.target.result || '';
          var lower = txt.trim().toLowerCase();
          if (lower.startsWith('<!doctype') || lower.startsWith('<html') || txt.includes('<!-- saved from')) {
            showToast('Warning: Uploaded file appears to be a full webpage, not a signature snippet.', true);
            return;
          }
          if (sigTextarea) {
            sigTextarea.value = txt;
            campaignFollowupSteps[index].signature = sigTextarea.value;
            updateLivePreview();
            if (typeof window.saveComposeState === 'function') window.saveComposeState();
          }
        };
        reader.readAsText(file);
      }
    });
  });

  listEl.querySelectorAll('.input-step-sig-text').forEach(inp => {
    inp.addEventListener('input', function() {
      var index = parseInt(this.getAttribute('data-index'));
      campaignFollowupSteps[index].signature = this.value;
      updateLivePreview();
      if (typeof window.saveComposeState === 'function') window.saveComposeState();
    });
  });

  listEl.querySelectorAll('.select-step-template').forEach(sel => {
    sel.addEventListener('change', function() {
      var index = parseInt(this.getAttribute('data-index'));
      var val = this.value;
      if (!val) return;
      var t = savedTemplates.find(function(item) { return item.id === val; });
      if (t) {
        campaignFollowupSteps[index].subject = t.subject || '';
        campaignFollowupSteps[index].body = t.body_html || '';
        renderFollowupSteps();
        updateLivePreview();
      }
    });
  });

  listEl.querySelectorAll('.btn-save-step-template').forEach(btn => {
    btn.addEventListener('click', async function(e) {
      e.preventDefault();
      var index = parseInt(this.getAttribute('data-index'));
      var step = campaignFollowupSteps[index];
      if (!step.body || !step.body.trim()) {
        showToast('Cannot save empty body as a template.', true);
        return;
      }
      var name = prompt('Enter template name:');
      if (!name || !name.trim()) return;

      try {
        await apiCall('POST', '/campaigns/templates', {
          name: name.trim(),
          subject: step.subject,
          body_html: step.body
        });
        showToast('Template saved!');
        await loadTemplatesList();
        renderFollowupSteps();
      } catch (err) {
        showToast('Error saving template: ' + err.message, true);
      }
    });
  });

  listEl.querySelectorAll('.btn-delete-step-template').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      var index = parseInt(this.getAttribute('data-index'));
      var sel = listEl.querySelector('.select-step-template[data-index="' + index + '"]');
      var id = sel ? sel.value : '';
      var tpl = savedTemplates.find(function(t) { return t.id === id; });
      deleteSavedTemplate(id, tpl ? tpl.name : '');
    });
  });

  listEl.querySelectorAll('.input-step-attachments').forEach(inp => {
    inp.addEventListener('change', function() {
      var index = parseInt(this.getAttribute('data-index'));
      var files = this.files;
      if (files.length === 0) return;
      Array.from(files).forEach(file => {
        var reader = new FileReader();
        reader.onload = function(e) {
          if (!campaignFollowupSteps[index].attachments) {
            campaignFollowupSteps[index].attachments = [];
          }
          campaignFollowupSteps[index].attachments.push({
            filename: file.name,
            contentType: file.type,
            content: e.target.result
          });
          renderFollowupSteps();
          if (typeof window.saveComposeState === 'function') window.saveComposeState();
        };
        reader.readAsDataURL(file);
      });
    });
  });

  listEl.querySelectorAll('.btn-remove-step-attach').forEach(btn => {
    btn.addEventListener('click', function() {
      var sIdx = parseInt(this.getAttribute('data-step-index'));
      var fIdx = parseInt(this.getAttribute('data-attach-index'));
      campaignFollowupSteps[sIdx].attachments.splice(fIdx, 1);
      renderFollowupSteps();
      if (typeof window.saveComposeState === 'function') window.saveComposeState();
    });
  });

  listEl.querySelectorAll('.btn-step-tag-subject').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      var target = this.closest('div').querySelector('.input-step-subject');
      if (target) showTagDropdown(this, target);
    });
  });

  listEl.querySelectorAll('.btn-step-tag-body').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      // The body textarea is a sibling of the header (not a descendant), so look it
      // up by its data-index instead of walking the DOM — that lookup returned null,
      // which is why tag insertion silently did nothing for follow-up steps.
      var index = this.getAttribute('data-index');
      var target = listEl.querySelector('.input-step-body[data-index="' + index + '"]');
      if (target) showTagDropdown(this, target);
    });
  });

  // AI Followup Event Listeners
  listEl.querySelectorAll('.btn-step-ai').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      var index = parseInt(this.getAttribute('data-index'));
      var panel = document.getElementById('ai-step-panel-' + index);
      if (panel) {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
      }
    });
  });

  listEl.querySelectorAll('.select-step-ai-template').forEach(sel => {
    sel.addEventListener('change', function() {
      var index = parseInt(this.getAttribute('data-index'));
      var container = document.getElementById('ai-step-prompt-container-' + index);
      if (container) {
        container.style.display = this.value === 'custom' ? 'block' : 'none';
      }
    });
  });

  listEl.querySelectorAll('.btn-step-ai-generate').forEach(btn => {
    btn.addEventListener('click', async function(e) {
      e.preventDefault();
      e.stopPropagation();
      var index = parseInt(this.getAttribute('data-index'));

      var loadingEl = document.getElementById('ai-step-loading-' + index);
      var generateBtn = this;
      var promptInput = document.getElementById('ai-step-prompt-' + index);
      var stepBodyTextarea = listEl.querySelector('.input-step-body[data-index="' + index + '"]');

      var templateSelect = document.getElementById('ai-step-template-' + index);
      var mode = templateSelect ? templateSelect.value : 'context';

      var finalPrompt = '';
      if (mode === 'context') {
        var mainEditor = document.getElementById('comp-body');
        var mainBody = mainEditor ? mainEditor.innerText.trim() : '';
        if (!mainBody) { showToast('The main email body is currently empty. Please write/generate it first.', true); return; }
        finalPrompt = 'Write a short followup email body (under 90 words, output body only, no subject line, no extra explanation, start with a direct opener). It must be written based on this main email body:\n\n' + mainBody;
      } else if (mode === 'spellcheck') {
        var currentBody = stepBodyTextarea ? stepBodyTextarea.value.trim() : '';
        if (!currentBody) { showToast('Please write or generate a follow-up email first to spell check & improve flow.', true); return; }
        finalPrompt = 'Spell check and improve the flow of this follow-up email content:\n\n' + currentBody;
      } else if (mode === 'internship') {
        finalPrompt = 'Draft a short follow-up checking in on my previous email regarding an internship opportunity.';
      } else if (mode === 'job') {
        finalPrompt = 'Draft a short follow-up checking in on my previous email regarding a job application.';
      } else if (mode === 'partnership') {
        finalPrompt = 'Draft a short follow-up checking in on my previous proposal for a business partnership or collaboration.';
      } else if (mode === 'formal') {
        var currentBody = stepBodyTextarea ? stepBodyTextarea.value.trim() : '';
        if (!currentBody) { showToast('Please write or generate a follow-up email first to change tone.', true); return; }
        finalPrompt = 'Rewrite this follow-up email to make it highly formal and professional:\n\n' + currentBody;
      } else if (mode === 'casual') {
        var currentBody = stepBodyTextarea ? stepBodyTextarea.value.trim() : '';
        if (!currentBody) { showToast('Please write or generate a follow-up email first to change tone.', true); return; }
        finalPrompt = 'Rewrite this follow-up email to make it casual and warm:\n\n' + currentBody;
      } else if (mode === 'concise') {
        var currentBody = stepBodyTextarea ? stepBodyTextarea.value.trim() : '';
        if (!currentBody) { showToast('Please write or generate a follow-up email first to change tone.', true); return; }
        finalPrompt = 'Rewrite this follow-up email to make it extremely concise:\n\n' + currentBody;
      } else {
        var customPromptText = promptInput ? promptInput.value.trim() : '';
        if (!customPromptText) { showToast('Please enter custom prompt instructions for the follow-up.', true); return; }
        finalPrompt = 'Write a short followup email body (under 90 words, output body only, no subject line, no extra explanation, start with a direct opener) applying these instructions:\n' + customPromptText;
      }
      
      if (loadingEl) loadingEl.style.display = 'inline';
      generateBtn.disabled = true;
      generateBtn.innerHTML = '&#x23F3;';
      
      try {
        var resp = await fetch(API_URL + '/api/ai/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: 'Write a follow-up email. Output EXACTLY:\nSubject: <subject>\nBody:\n<email body under 90 words>\nInstruction: ' + finalPrompt,
            history: []
          })
        });
        if (!resp.ok) {
          var errObj2 = await resp.json().catch(function() { return {}; });
          throw new Error((errObj2.error && errObj2.error.message) || ('HTTP ' + resp.status + ' ' + resp.statusText));
        }
        
        var data = await resp.json();
        var rawText = data.reply.trim();

        // Parse Subject and Body
        var subjectMatch = rawText.match(/^Subject:\s*(.+)/im);
        var bodyMatch = rawText.match(/Body:\s*\n([\s\S]+)/im);
        var stepSubject = subjectMatch ? subjectMatch[1].trim() : '';
        var stepBody = bodyMatch ? bodyMatch[1].trim() : rawText.replace(/^Subject:\s*.+\n?/im, '').replace(/^Body:\s*\n?/im, '').trim();

        // Fill step subject if there is a subject field for this step
        var stepSubjectInput = listEl.querySelector('.input-step-subject[data-index="' + index + '"]');
        if (stepSubjectInput && stepSubject) stepSubjectInput.value = stepSubject;
        if (stepBodyTextarea) stepBodyTextarea.value = stepBody;

        campaignFollowupSteps[index].body = stepBody;
        if (stepSubject) campaignFollowupSteps[index].subject = stepSubject;
        updateLivePreview();
        
        var panel = document.getElementById('ai-step-panel-' + index);
        if (panel) panel.style.display = 'none';
        showToast('AI follow-up generated and inserted!');
      } catch (err) {
        showToast('AI error: ' + err.message, true);
      } finally {
        if (loadingEl) loadingEl.style.display = 'none';
        generateBtn.disabled = false;
        generateBtn.innerHTML = 'Generate';
      }
    });
  });

  // AI Step Subject Event Listeners
  listEl.querySelectorAll('.btn-step-subject-ai').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      var index = parseInt(this.getAttribute('data-index'));
      var panel = document.getElementById('ai-step-subject-panel-' + index);
      if (panel) {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
      }
    });
  });

  listEl.querySelectorAll('.select-step-subject-ai-template').forEach(sel => {
    sel.addEventListener('change', function() {
      var index = parseInt(this.getAttribute('data-index'));
      var container = document.getElementById('ai-step-subject-prompt-container-' + index);
      if (container) {
        container.style.display = this.value === 'custom' ? 'block' : 'none';
      }
    });
  });

  listEl.querySelectorAll('.btn-step-subject-ai-generate').forEach(btn => {
    btn.addEventListener('click', async function(e) {
      e.preventDefault();
      e.stopPropagation();
      var index = parseInt(this.getAttribute('data-index'));

      var loadingEl = document.getElementById('ai-step-subject-loading-' + index);
      var generateBtn = this;
      var promptInput = document.getElementById('ai-step-subject-prompt-' + index);
      var stepSubjectInput = listEl.querySelector('.input-step-subject[data-index="' + index + '"]');

      var templateSelect = document.getElementById('ai-step-subject-template-' + index);
      var mode = templateSelect ? templateSelect.value : 'context';
      var stepBodyTextarea = listEl.querySelector('.input-step-body[data-index="' + index + '"]');

      var finalPrompt = '';
      if (mode === 'context') {
        var currentBody = stepBodyTextarea ? stepBodyTextarea.value.trim() : '';
        if (!currentBody) { showToast('The follow-up email body is currently empty. Please write/generate it first.', true); return; }
        finalPrompt = 'Write a highly effective, engaging, professional follow-up email subject line based on this follow-up email body content provided. Output ONLY the subject line itself. No "Subject:" prefix, no quotation marks, no emojis, and no extra explanation. Follow-up email body:\n\n' + currentBody;
      } else if (mode === 'spellcheck') {
        var currentSubject = stepSubjectInput ? stepSubjectInput.value.trim() : '';
        if (!currentSubject) { showToast('Please write a subject line first to spell check & improve flow.', true); return; }
        finalPrompt = 'Spell check and improve the flow of this follow-up email subject line: "' + currentSubject + '". Output ONLY the improved subject line. No "Subject:" prefix, no quotation marks, no emojis, and no extra explanation.';
      } else {
        var customPromptText = promptInput ? promptInput.value.trim() : '';
        if (!customPromptText) { showToast('Please enter custom prompt instructions for the follow-up subject.', true); return; }
        finalPrompt = 'Write a highly effective, engaging, professional follow-up email subject line applying these instructions: ' + customPromptText + '. Output ONLY the subject line itself. No "Subject:" prefix, no quotation marks, no emojis, and no extra explanation.';
      }

      if (loadingEl) loadingEl.style.display = 'inline';
      generateBtn.disabled = true;
      var originalBtnText = generateBtn.innerHTML;
      generateBtn.innerHTML = '&#x23F3;';

      try {
        var resp = await fetch(API_URL + '/api/ai/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: 'Write a cold email subject line. Output ONLY the subject line itself, no labels, no quotes, no emojis, no extra explanation. Instruction: ' + finalPrompt,
            history: []
          })
        });
        if (!resp.ok) {
          var errObj2 = await resp.json().catch(function() { return {}; });
          throw new Error((errObj2.error && errObj2.error.message) || ('HTTP ' + resp.status + ' ' + resp.statusText));
        }

        var data = await resp.json();
        var rawText = data.reply.trim();
        var cleanText = rawText.replace(/^(Subject|subject):\s*/i, '').replace(/^["']|["']$/g, '').replace(/^(Re|re):\s*/i, '').trim();

        if (stepSubjectInput) {
          stepSubjectInput.value = cleanText;
          stepSubjectInput.dispatchEvent(new Event('input'));
        }
        campaignFollowupSteps[index].subject = cleanText;
        updateLivePreview();

        var panel = document.getElementById('ai-step-subject-panel-' + index);
        if (panel) panel.style.display = 'none';
        showToast('AI follow-up subject generated and inserted!');
      } catch (err) {
        showToast('AI error: ' + err.message, true);
      } finally {
        if (loadingEl) loadingEl.style.display = 'none';
        generateBtn.disabled = false;
        generateBtn.innerHTML = originalBtnText;
      }
    });
  });
}

// Drag & drop handlers
var dropZone = document.getElementById('drop-zone');
var fileInput = document.getElementById('campaign-file-input');
var uploadContinueBtn = document.getElementById('btn-upload-continue');

if (dropZone && fileInput) {
  dropZone.addEventListener('click', function() {
    fileInput.click();
  });

  dropZone.addEventListener('dragover', function(e) {
    e.preventDefault();
    dropZone.style.borderColor = 'var(--p)';
    dropZone.style.background = 'var(--p05)';
  });

  dropZone.addEventListener('dragleave', function() {
    dropZone.style.borderColor = 'rgba(0,88,190,.2)';
    dropZone.style.background = 'var(--sf-lo)';
  });

  dropZone.addEventListener('drop', function(e) {
    e.preventDefault();
    dropZone.style.borderColor = 'rgba(0,88,190,.2)';
    dropZone.style.background = 'var(--sf-lo)';
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener('change', function() {
    if (fileInput.files && fileInput.files.length > 0) {
      handleFileSelected(fileInput.files[0]);
    }
  });
}

// Google Sheet import handler
var importGSheetBtn = document.getElementById('btn-import-gsheet');
var gsheetUrlInput = document.getElementById('campaign-gsheet-url');

if (importGSheetBtn && gsheetUrlInput) {
  importGSheetBtn.addEventListener('click', async function() {
    var url = gsheetUrlInput.value.trim();
    if (!url) {
      showToast('Please enter a Google Sheets URL.', true);
      return;
    }

    var match = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (!match) {
      showToast('Invalid Google Sheets URL format. Make sure it contains /spreadsheets/d/SpreadsheetID', true);
      return;
    }

    try {
      importGSheetBtn.disabled = true;
      var originalBtnText = importGSheetBtn.innerHTML;
      importGSheetBtn.innerHTML = '<span class="mi" style="font-size:16px;animation:spin .75s linear infinite">sync</span>Syncing...';

      var csvData = null;
      var spreadsheetId = match[1];
      var exportUrl = 'https://docs.google.com/spreadsheets/d/' + spreadsheetId + '/export?format=csv';

      // 1. Try direct client-side fetch first (runs from extension context with host permissions)
      try {
        var directRes = await fetch(exportUrl);
        if (directRes.ok) {
          csvData = await directRes.text();
          console.log('[SNDR] Synced Google Sheet directly on client-side');
        }
      } catch (e) {
        console.warn('[SNDR] Direct client-side fetch failed or blocked by CORS, trying backend proxy...', e);
      }

      // 2. Fallback to backend proxy if direct fetch did not succeed
      if (!csvData) {
        try {
          var response = await apiCall('GET', '/campaigns/fetch-gsheet?url=' + encodeURIComponent(url));
          csvData = response ? response.csv : null;
          console.log('[SNDR] Synced Google Sheet via backend proxy');
        } catch (proxyError) {
          console.error('[SNDR] Backend proxy fetch failed:', proxyError);
        }
      }

      if (!csvData) {
        throw new Error('Failed to retrieve Google Sheet data. Please make sure the sheet is shared as "Anyone with the link can view".');
      }

      var rows = parseCSV(csvData);
      if (rows.length > 0) {
        // Filter out empty rows
        rows = rows.filter(function(r) { return r && r.length > 0 && r.some(function(cell) { return cell !== null && cell !== ''; }); });
        parsedHeaders = (rows[0] || []).map(function(h) { return h ? String(h).trim() : ''; });
        parsedRows = rows.slice(1).map(function(row) {
          var mappedRow = [];
          for (var cIdx = 0; cIdx < parsedHeaders.length; cIdx++) {
            var val = row[cIdx];
            mappedRow.push(val !== undefined && val !== null ? String(val).trim() : '');
          }
          return mappedRow;
        });

        // Set state as if file was selected
        uploadedFile = { name: 'Google Sheet (Synced)', size: csvData.length };
        
        var statusTitle = document.getElementById('upload-status-title');
        var statusSub = document.getElementById('upload-status-sub');
        if (statusTitle) statusTitle.textContent = 'Google Sheet connected successfully';
        if (statusSub) statusSub.textContent = parsedRows.length + ' rows loaded';
        if (uploadContinueBtn) uploadContinueBtn.disabled = false;

        var dropZoneEl = document.getElementById('drop-zone');
        if (dropZoneEl) dropZoneEl.style.borderColor = 'var(--p)';

        setupMappingDropdowns();
        setupMappingPreviewTable();
        showToast('Google Sheet contacts synced successfully!', false);
        if (typeof window.saveComposeState === 'function') {
          window.saveComposeState();
        }
      } else {
        showToast('Google Sheet is empty.', true);
      }
    } catch (err) {
      console.error('GSheet sync error:', err);
      showToast(err.message || 'Failed to sync Google Sheet. Verify sharing settings.', true);
    } finally {
      importGSheetBtn.disabled = false;
      importGSheetBtn.innerHTML = originalBtnText;
    }
  });
}

function handleFileSelected(file) {
  var ext = file.name.split('.').pop().toLowerCase();
  if (ext !== 'csv' && ext !== 'xlsx' && ext !== 'xls') {
    showToast('Please upload a CSV or Excel file.', true);
    return;
  }
  uploadedFile = file;

  var statusTitle = document.getElementById('upload-status-title');
  var statusSub = document.getElementById('upload-status-sub');
  if (statusTitle) statusTitle.textContent = 'File selected: ' + file.name;
  if (statusSub) statusSub.textContent = Math.round(file.size / 1024) + ' KB';
  if (uploadContinueBtn) uploadContinueBtn.disabled = false;

  var dropZone = document.getElementById('drop-zone');
  if (dropZone) dropZone.style.borderColor = 'var(--p)';

  // Parse file
  var reader = new FileReader();
  if (ext === 'csv') {
    reader.onload = function(e) {
      var text = e.target.result;
      var rows = parseCSV(text);
      if (rows.length > 0) {
        // Filter out empty rows
        rows = rows.filter(function(r) { return r && r.length > 0 && r.some(function(cell) { return cell !== null && cell !== ''; }); });
        parsedHeaders = (rows[0] || []).map(function(h) { return h ? String(h).trim() : ''; });
        parsedRows = rows.slice(1).map(function(row) {
          var mappedRow = [];
          for (var cIdx = 0; cIdx < parsedHeaders.length; cIdx++) {
            var val = row[cIdx];
            mappedRow.push(val !== undefined && val !== null ? String(val).trim() : '');
          }
          return mappedRow;
        });
        var ssCsv = document.getElementById('upload-status-sub');
        if (ssCsv) ssCsv.textContent = parsedRows.length + ' contacts detected';
        setupMappingDropdowns();
        setupMappingPreviewTable();
        if (typeof window.saveComposeState === 'function') {
          window.saveComposeState();
        }
      }
    };
    reader.readAsText(file);
  } else {
    reader.onload = function(e) {
      try {
        var data = new Uint8Array(e.target.result);
        var workbook = XLSX.read(data, { type: 'array' });
        var firstSheetName = workbook.SheetNames[0];
        var worksheet = workbook.Sheets[firstSheetName];

        // DEFEND against a wrong/truncated worksheet range (!ref): some Excel
        // exports declare a range covering only 1 row even though all the data
        // cells exist, which makes sheet_to_json return just 1 row. Recompute the
        // real range from the actual cell addresses so every row is read.
        try {
          var addrs = Object.keys(worksheet).filter(function(k) { return k.charAt(0) !== '!'; });
          if (addrs.length) {
            var rng = { s: { r: Infinity, c: Infinity }, e: { r: -1, c: -1 } };
            addrs.forEach(function(a) {
              var cell = XLSX.utils.decode_cell(a);
              if (cell.r < rng.s.r) rng.s.r = cell.r;
              if (cell.c < rng.s.c) rng.s.c = cell.c;
              if (cell.r > rng.e.r) rng.e.r = cell.r;
              if (cell.c > rng.e.c) rng.e.c = cell.c;
            });
            if (rng.e.r >= 0) worksheet['!ref'] = XLSX.utils.encode_range(rng);
          }
        } catch (rangeErr) { console.warn('range recompute failed:', rangeErr); }

        var rows = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '', blankrows: false });
        console.log('[SNDR] Excel parsed rows (incl header):', rows.length);

        // Filter out empty rows
        rows = rows.filter(function(r) {
          return r && r.length > 0 && r.some(function(cell) { return cell !== null && cell !== undefined && cell !== ''; });
        });

        if (rows.length > 0) {
          parsedHeaders = rows[0].map(function(h) { return h ? String(h).trim() : ''; });
          parsedRows = rows.slice(1).map(function(row) {
            var mappedRow = [];
            for (var cIdx = 0; cIdx < parsedHeaders.length; cIdx++) {
              var val = row[cIdx];
              mappedRow.push(val !== undefined && val !== null ? String(val).trim() : '');
            }
            return mappedRow;
          });
          var ssXlsx = document.getElementById('upload-status-sub');
          if (ssXlsx) ssXlsx.textContent = parsedRows.length + ' contacts detected';
          setupMappingDropdowns();
          setupMappingPreviewTable();
          if (typeof window.saveComposeState === 'function') {
            window.saveComposeState();
          }
        } else {
          showToast('Excel file is empty.', true);
        }
      } catch (err) {
        console.error('Excel parse error:', err);
        showToast('Failed to parse Excel file: ' + err.message, true);
      }
    };
    reader.readAsArrayBuffer(file);
  }
}

// RFC-4180 CSV parser: quote state is tracked across the WHOLE text, so quoted
// cells containing newlines (common in "notes"/"address" columns) stay in one
// row, and "" inside a quoted cell is an escaped literal quote. The old parser
// split on \n first — a single multi-line cell tore the row apart, shifting
// every later column and corrupting the email/name mapping for that record.
function parseCSV(text) {
  var rows = [];
  var row = [];
  var cur = '';
  var inQuotes = false;
  function pushCell() { row.push(cur.trim()); cur = ''; }
  function pushRow() {
    pushCell();
    // Skip fully blank lines (single empty cell, nothing typed)
    if (row.length > 1 || (row[0] && row[0].length)) rows.push(row);
    row = [];
  }
  for (var i = 0; i < text.length; i++) {
    var ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') { cur += '"'; i++; } // escaped quote
        else inQuotes = false;
      } else {
        cur += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      pushCell();
    } else if (ch === '\n') {
      pushRow();
    } else if (ch !== '\r') {
      cur += ch;
    }
  }
  if (cur.length || row.length) pushRow();
  return rows;
}

function setupMappingDropdowns() {
  var emailSelect = document.getElementById('map-email-col');
  var nameSelect = document.getElementById('map-name-col');
  var compSelect = document.getElementById('map-company-col');
  var roleSelect = document.getElementById('map-role-col');

  if (!emailSelect) return;

  var dropdowns = [emailSelect, nameSelect, compSelect, roleSelect];
  dropdowns.forEach(function(sel, selIndex) {
    sel.innerHTML = '';
    if (selIndex > 0) {
      var opt = document.createElement('option');
      opt.value = '';
      opt.textContent = '- skip -';
      sel.appendChild(opt);
    }
    parsedHeaders.forEach(function(h) {
      var opt = document.createElement('option');
      opt.value = h;
      opt.textContent = h;
      sel.appendChild(opt);
    });
  });

  // Guess columns
  parsedHeaders.forEach(function(h) {
    var hl = h.toLowerCase();
    if (hl.indexOf('email') !== -1 || hl.indexOf('mail') !== -1) emailSelect.value = h;
    if (hl.indexOf('name') !== -1 || hl.indexOf('first') !== -1) nameSelect.value = h;
    if (hl.indexOf('company') !== -1 || hl.indexOf('org') !== -1) compSelect.value = h;
    if (hl.indexOf('role') !== -1 || hl.indexOf('position') !== -1 || hl.indexOf('title') !== -1) roleSelect.value = h;
  });
}

function setupMappingPreviewTable() {
  var filenameEl = document.getElementById('map-filename-label');
  var countEl = document.getElementById('map-rows-count');
  var thead = document.getElementById('map-table-head');
  var tbody = document.getElementById('map-table-preview');

  if (filenameEl && uploadedFile) filenameEl.textContent = uploadedFile.name;
  if (countEl) countEl.textContent = parsedRows.length + ' rows';

  if (thead) {
    var headHtml = '<tr><th>#</th>';
    parsedHeaders.forEach(function(h) {
      headHtml += '<th>' + escHtml(h.toUpperCase()) + '</th>';
    });
    headHtml += '</tr>';
    thead.innerHTML = headHtml;
  }

  if (tbody) {
    var bodyHtml = '';
    parsedRows.slice(0, 3).forEach(function(row, rIdx) {
      var num = String(rIdx + 1).padStart(2, '0');
      bodyHtml += '<tr><td style="color:var(--p);font-family:var(--mono);font-weight:700;font-size:11px">' + num + '</td>';
      row.forEach(function(val) {
        bodyHtml += '<td>' + escHtml(val) + '</td>';
      });
      bodyHtml += '</tr>';
    });
    tbody.innerHTML = bodyHtml;
  }
}

if (uploadContinueBtn) {
  uploadContinueBtn.addEventListener('click', function() {
    goStep(2);
  });
}

var mapContinueBtn = document.getElementById('btn-map-continue');
if (mapContinueBtn) {
  mapContinueBtn.addEventListener('click', function() {
    var emailCol = document.getElementById('map-email-col').value;
    if (!emailCol) {
      showToast('Email column mapping is required.', true);
      return;
    }
    goStep(3);
  });
}

var composeContinueBtn = document.getElementById('btn-compose-continue');
if (composeContinueBtn) {
  composeContinueBtn.addEventListener('click', function() {
    var name = document.getElementById('comp-campaign-name').value;
    var subject = document.getElementById('comp-subject').value;
    var body = document.getElementById('comp-body').innerHTML;

    if (!name || !subject || !body) {
      showToast('All campaign details (Name, Subject, Body) are required.', true);
      return;
    }
    goStep(4);
  });
}

var scheduleContinueBtn = document.getElementById('btn-schedule-continue');
if (scheduleContinueBtn) {
  scheduleContinueBtn.addEventListener('click', function() {
    goStep(5);
  });
}

function updateReviewStepSummary() {
  var name = document.getElementById('comp-campaign-name').value;
  var fromAddress = activeAccount ? activeAccount.email : 'No connected account';
  var totalContacts = parsedRows.length;

  var revName = document.getElementById('rev-campaign-name');
  var revCount = document.getElementById('rev-contacts-count');
  var revSchedule = document.getElementById('rev-schedule');
  var revFrom = document.getElementById('rev-from-address');
  var revEst = document.getElementById('rev-est-emails');
  var revSeqSteps = document.getElementById('rev-sequence-steps');

  if (revName) revName.textContent = name;
  if (revCount) revCount.textContent = totalContacts;
  if (revFrom) revFrom.textContent = fromAddress;

  // Total steps = initial email (1) + every configured follow-up step.
  var totalSteps = 1 + (campaignFollowupSteps ? campaignFollowupSteps.length : 0);
  if (revSeqSteps) revSeqSteps.textContent = totalSteps;
  // Upper-bound volume across the whole sequence: contacts x every step. Actual
  // sends are lower because follow-ups only go to people who haven't replied.
  if (revEst) revEst.textContent = totalContacts * totalSteps;

  var schedLater = document.getElementById('sched-later').classList.contains('sel');
  if (revSchedule) {
    if (schedLater) {
      var timeVal = document.getElementById('comp-schedule-time').value;
      revSchedule.textContent = timeVal ? 'Scheduled: ' + new Date(timeVal).toLocaleString() : 'Scheduled';
    } else {
      revSchedule.textContent = 'Immediate';
    }
  }
}

// Launch Campaign Handler
var launchCampaignBtn = document.getElementById('btn-launch-campaign');
if (launchCampaignBtn) {
  launchCampaignBtn.addEventListener('click', async function() {
    if (!activeAccount) {
      showToast('Cannot launch: No Gmail account connected.', true);
      return;
    }
    if (!isAccountConnected(activeAccount)) {
      showToast('Gmail is disconnected — reconnect it in Settings, then launch.', true);
      return;
    }

    var name = document.getElementById('comp-campaign-name').value;
    var subject = document.getElementById('comp-subject').value;
    var bodyHtmlEl = document.getElementById('comp-body');
    var tempDiv = document.createElement('div');
    tempDiv.innerHTML = bodyHtmlEl ? bodyHtmlEl.innerHTML : '';
    tempDiv.querySelectorAll('a').forEach(function(a) {
      var isUnderlined = false;
      var parent = a.parentElement;
      while (parent && parent !== tempDiv) {
        if (parent.tagName === 'U' || parent.style.textDecoration === 'underline') {
          isUnderlined = true;
          break;
        }
        parent = parent.parentElement;
      }
      if (a.querySelector('u') || a.style.textDecoration === 'underline') {
        isUnderlined = true;
      }
      a.style.textDecoration = isUnderlined ? 'underline' : 'none';
    });
    var bodyHtml = tempDiv.innerHTML;
    var followupDaysEl = document.getElementById('comp-followup-days');
    var followupDays = followupDaysEl ? (parseInt(followupDaysEl.value) || 3) : 3;
    var followupTimeVal = document.getElementById('comp-followup-time') ? document.getElementById('comp-followup-time').value : '09:00';
    var followupTriggerVal = document.getElementById('comp-followup-trigger') ? document.getElementById('comp-followup-trigger').value : 'no_reply';

    var useSigCheck = document.getElementById('comp-use-signature');
    if (useSigCheck && useSigCheck.checked) {
      var sigText = document.getElementById('comp-signature-text');
      if (sigText && sigText.value) {
        bodyHtml += '<br><br>' + sigText.value.replace(/\n/g, '<br>');
      }
    }

    // ── Validate everything BEFORE creating anything (no empty/invalid campaigns,
    //    no reaching Launch via the step headers with missing data) ──
    var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    var bodyText = tempDiv.textContent.trim();
    if (!name.trim())    { showToast('Please enter a campaign name.', true); return; }
    if (!subject.trim()) { showToast('Please enter a subject line.', true); return; }
    if (!bodyText)       { showToast('Please write the email body.', true); return; }
    if (!parsedRows || parsedRows.length === 0) { showToast('Please add recipients first.', true); return; }

    var emailCol = document.getElementById('map-email-col').value;
    var nameCol = document.getElementById('map-name-col').value;
    var companyCol = document.getElementById('map-company-col').value;
    var roleCol = document.getElementById('map-role-col').value;
    if (!emailCol) { showToast('Please map the Email column.', true); return; }

    // Build + validate recipients up front; skip blank/invalid addresses.
    var contactsToUpload = [];
    var invalidCount = 0;
    parsedRows.forEach(function(row) {
      var emailVal = '', nameVal = '', companyVal = '', roleVal = '', fieldsVal = {};
      parsedHeaders.forEach(function(h, idx) {
        var val = row[idx] || '';
        if (h === emailCol) emailVal = val;
        if (h === nameCol) nameVal = val;
        if (h === companyCol) companyVal = val;
        if (h === roleCol) roleVal = val;
        fieldsVal[h] = val;
      });
      if (companyVal) fieldsVal['company'] = companyVal;
      if (roleVal) fieldsVal['role'] = roleVal;
      var cleanEmail = String(emailVal).trim();
      // If the mapped Email column didn't yield a valid address for this row, scan
      // every cell for an email-looking value. This prevents a wrong/auto-detected
      // column mapping from silently importing just 1 of N contacts.
      if (!EMAIL_RE.test(cleanEmail)) {
        for (var ci = 0; ci < row.length; ci++) {
          var cell = String(row[ci] == null ? '' : row[ci]).trim();
          if (EMAIL_RE.test(cell)) { cleanEmail = cell; break; }
        }
      }
      if (!cleanEmail) return;
      if (!EMAIL_RE.test(cleanEmail)) { invalidCount++; return; }
      contactsToUpload.push({ email: cleanEmail, name: (nameVal || cleanEmail.split('@')[0]), fields: fieldsVal });
    });
    if (contactsToUpload.length === 0) {
      showToast('No valid recipient emails found — check your Email column mapping.', true);
      return;
    }

    // Don't launch with an empty follow-up step (it would send a blank email).
    if (campaignFollowupSteps && campaignFollowupSteps.length > 0) {
      for (var si = 0; si < campaignFollowupSteps.length; si++) {
        var stepBody = (campaignFollowupSteps[si].body || '').replace(/<[^>]*>/g, '').trim();
        if (!stepBody) {
          showToast('Follow-up step ' + (si + 1) + ' has an empty body. Add a message or remove the step.', true);
          return;
        }
      }
    }

    // If this draft was restored and its attachments couldn't be (only names are
    // persisted), don't silently launch without them — ask.
    var hasMainAttachments = campaignAttachments && campaignAttachments.length > 0;
    var hasStepAttachments = (campaignFollowupSteps || []).some(function(s) { return s.attachments && s.attachments.length > 0; });
    if (window._restoredDroppedAttachments && !hasMainAttachments && !hasStepAttachments) {
      if (!confirm('This restored draft originally had attachment(s): ' + window._restoredDroppedAttachments.join(', ') + '.\n\nThey could not be restored. Launch WITHOUT attachments?\n\n(Click Cancel to go back and re-attach them.)')) {
        return;
      }
    }

    // Scheduling: validate the chosen time up front.
    var schedLater = document.getElementById('sched-later').classList.contains('sel');
    var scheduledAtTs = null;
    if (schedLater) {
      var schedRaw = document.getElementById('comp-schedule-time') ? document.getElementById('comp-schedule-time').value : '';
      var schedDate = schedRaw ? new Date(schedRaw) : null;
      if (!schedDate || isNaN(schedDate.getTime())) { showToast('Please pick a valid date & time to schedule.', true); return; }
      if (schedDate.getTime() < Date.now() - 60000) { showToast('That scheduled time is in the past.', true); return; }
      scheduledAtTs = Math.floor(schedDate.getTime() / 1000);
    }

    try {
      launchCampaignBtn.disabled = true;
      launchCampaignBtn.textContent = 'Creating Campaign...';

      // 1. Create Campaign (real follow-up settings; scheduled_at when scheduling)
      var campRes = await apiCall('POST', '/campaigns', {
        account_id: activeAccount.id,
        name: name.trim(),
        subject: subject.trim(),
        body_html: bodyHtml,
        followup_days: followupDays,
        followup_time: followupTimeVal,
        followup_trigger: followupTriggerVal,
        attachments: campaignAttachments,
        followup_steps: campaignFollowupSteps,
        scheduled_at: scheduledAtTs,
        tz_offset: -new Date().getTimezoneOffset()
      });
      var campaignId = campRes.id;

      // 2. Upload Contacts
      launchCampaignBtn.textContent = 'Uploading Contacts...';
      var upRes = await apiCall('POST', '/campaigns/' + campaignId + '/contacts-json', { contacts: contactsToUpload });
      var addedCount = (upRes && typeof upRes.added === 'number') ? upRes.added : contactsToUpload.length;
      // Every row with a valid email is imported (duplicates included). Only flag
      // rows that had no usable email at all.
      if (invalidCount > 0) {
        showToast('Imported ' + addedCount + ' contact(s). ' + invalidCount + ' row(s) had no valid email and were skipped.', true);
      }

      // 3. Send now, or leave scheduled for the backend to start at the chosen time.
      if (!schedLater) {
        launchCampaignBtn.textContent = 'Starting sends...';
        await apiCall('POST', '/campaigns/' + campaignId + '/send');
        showToast('Campaign created with ' + addedCount + ' contact(s) — sending started!');
      } else {
        showToast('Campaign created with ' + addedCount + ' contact(s) — scheduled for ' + new Date(scheduledAtTs * 1000).toLocaleString() + '.');
      }
      invalidateStatsCache({ contacts: true });

      if (typeof window.clearComposeState === 'function') {
        window.clearComposeState();
      }
      window._restoredDroppedAttachments = null;

      goNav('campaigns');
    } catch (err) {
      showToast(err.message, true);
    } finally {
      launchCampaignBtn.disabled = false;
      launchCampaignBtn.textContent = 'Launch Campaign';
    }
  });
}

// ── Charts & heatmaps ───────────────────────────────────────────
// Semantic, theme-aware chart palette. One rule across EVERY chart:
//   indigo (the brand primary) = opens / sent volume
//   emerald                    = replies
//   neutral gray               = "no action" / zero
// Both pairs are CVD-validated against the real surfaces (light #ffffff,
// dark #131c2e): worst adjacent deltaE 94 (light) / 85 (dark), >=3:1 contrast.
function chartTheme() {
  var dark = document.documentElement.getAttribute('data-theme') === 'dark';
  return {
    dark: dark,
    open:      dark ? '#6366f1' : '#4f46e5',              // indigo — opens
    openSoft:  dark ? 'rgba(99,102,241,0.16)'  : 'rgba(79,70,229,0.09)',
    openMid:   dark ? 'rgba(99,102,241,0.55)'  : 'rgba(79,70,229,0.45)',
    reply:     '#0f9d6e',                                  // emerald — replies (passes both modes)
    replySoft: dark ? 'rgba(15,157,110,0.16)'  : 'rgba(15,157,110,0.09)',
    neutral:   dark ? '#334155' : '#cbd5e1',               // no action / zero
    axis:      dark ? '#8a97ab' : '#64748b',
    grid:      dark ? 'rgba(255,255,255,0.06)' : 'rgba(15,23,42,0.06)',
    surface:   dark ? '#131c2e' : '#ffffff',
    tipBg:     dark ? '#1e293b' : '#0f172a',
    // sequential indigo (magnitude): [low, mid, high] — days bars, heatmap tiers
    seqLow:    dark ? 'rgba(99,102,241,0.22)' : 'rgba(79,70,229,0.16)',
    seqMid:    dark ? 'rgba(99,102,241,0.55)' : 'rgba(79,70,229,0.45)',
    seqHigh:   dark ? '#6366f1' : '#4f46e5',
    heatRgb:   dark ? '99,102,241' : '79,70,229'
  };
}

// Shared tooltip config — the hover layer every chart ships with. Values lead
// (bold, high contrast), series names follow; point-style keys, themed panel.
function chartTip(t, extra) {
  var cfg = {
    enabled: true,
    backgroundColor: t.tipBg,
    titleColor: t.dark ? '#8a97ab' : '#94a3b8',
    bodyColor: '#f8fafc',
    titleFont: { size: 10, weight: '600', family: CHART_FONT },
    bodyFont: { size: 12, weight: '700', family: CHART_FONT },
    padding: 10,
    cornerRadius: 8,
    caretSize: 5,
    displayColors: true,
    usePointStyle: true,
    boxWidth: 7,
    boxHeight: 7,
    boxPadding: 4
  };
  if (extra) { for (var k in extra) { cfg[k] = extra[k]; } }
  return cfg;
}
// Default '%'-formatting label callback (most dashboard charts are rates).
function pctLabel(ctx) {
  var name = ctx.dataset && ctx.dataset.label ? ctx.dataset.label + ': ' : '';
  var v = ctx.parsed && typeof ctx.parsed.y === 'number' ? ctx.parsed.y : ctx.parsed;
  return ' ' + name + v + '%';
}

var CHART_FONT = "'Inter', 'Plus Jakarta Sans', system-ui, -apple-system, 'Segoe UI', sans-serif";

// padding top/right leaves room for the value labels drawn above points so they
// aren't clipped at the chart edge (e.g. the "50%" label on the last point).
var G = { responsive: true, maintainAspectRatio: false, animation: false, animations: { colors: false, x: false, y: false }, plugins: { legend: { display: false }, tooltip: { enabled: false } }, layout: { padding: { top: 16, right: 12, bottom: 0, left: 0 } } };
var sc = { grid: { color: 'rgba(15,23,42,0.06)' }, border: { display: false }, ticks: { font: { size: 10, family: CHART_FONT } } };
var ng = { grid: { display: false }, border: { display: false }, ticks: { font: { size: 10, family: CHART_FONT } } };

// Bottom legend shared by every multi-series chart (single-series charts get none
// — the card title names the series). Point-style keys, text in ink tokens.
function chartLegend(t) {
  return {
    display: true,
    position: 'bottom',
    labels: {
      usePointStyle: true,
      pointStyle: 'rectRounded',
      boxWidth: 9,
      boxHeight: 9,
      padding: 14,
      color: t.dark ? '#c2ccdb' : '#424754',
      font: { size: 11, weight: '600', family: CHART_FONT }
    }
  };
}

// Charts draw to <canvas>, so they can't read CSS theme tokens. Call this before
// building any chart so the shared sc/ng config + Chart.js defaults use values
// that read on the current (light or dark) theme.
function syncChartTheme() {
  var t = chartTheme();
  try {
    if (window.Chart && Chart.defaults) {
      Chart.defaults.color = t.axis;
      Chart.defaults.font.family = CHART_FONT;
      Chart.defaults.font.size = 10;
    }
  } catch (e) {}
  sc.grid.color = t.grid; sc.ticks.color = t.axis;
  ng.ticks.color = t.axis;
  return t;
}

// ── Chart value-label + donut-center plugins (make numbers visible) ──
// Opt-in per chart via options.plugins.valueLabels / options.plugins.donutCenter.
var valueLabelsPlugin = {
  id: 'valueLabels',
  afterDatasetsDraw: function(chart) {
    var type = chart.config.type;
    if (type !== 'bar' && type !== 'line') return; // skip doughnut/pie
    var cfg = (chart.options.plugins && chart.options.plugins.valueLabels) || {};
    if (cfg === false || cfg.enabled === false) return;
    // All dashboard bar/line charts are percentages. Bars label every value;
    // dense lines label just the peak to avoid clutter.
    var suffix = cfg.suffix != null ? cfg.suffix : '%';
    var mode = cfg.mode || (type === 'line' ? 'peak' : 'all');
    var ctx = chart.ctx;
    var darkTheme = document.documentElement.getAttribute('data-theme') === 'dark';
    ctx.save();
    ctx.font = '700 ' + (cfg.size || 10) + 'px Inter, system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    chart.data.datasets.forEach(function(ds, di) {
      var meta = chart.getDatasetMeta(di);
      if (meta.hidden || !meta.data) return;
      var peakIdx = -1, peakVal = -Infinity;
      if (mode === 'peak') {
        ds.data.forEach(function(v, i) { if (v != null && v > peakVal) { peakVal = v; peakIdx = i; } });
      }
      var area = chart.chartArea;
      meta.data.forEach(function(pt, i) {
        var val = ds.data[i];
        if (val == null) return;
        if (mode === 'peak' && (i !== peakIdx || val === 0)) return;
        ctx.fillStyle = cfg.color || (typeof ds.borderColor === 'string' ? ds.borderColor : (darkTheme ? '#e6edf6' : '#0b1c30'));
        var y = pt.y - 4;
        if (y < 12) y = pt.y + 16;
        // Clamp inside the plot area so a label on the first/last point never
        // collides with the y-axis ticks or overflows the right edge.
        var x = pt.x;
        if (area) x = Math.min(Math.max(x, area.left + 16), area.right - 16);
        ctx.fillText(val + suffix, x, y);
      });
    });
    ctx.restore();
  }
};
var donutCenterPlugin = {
  id: 'donutCenter',
  afterDraw: function(chart) {
    var cfg = chart.options.plugins && chart.options.plugins.donutCenter;
    if (!cfg) return;
    var meta = chart.getDatasetMeta(0);
    if (!meta || !meta.data || !meta.data[0]) return;
    var ctx = chart.ctx, cx = meta.data[0].x, cy = meta.data[0].y;
    var darkTheme = document.documentElement.getAttribute('data-theme') === 'dark';
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = cfg.color || (darkTheme ? '#e6edf6' : '#0b1c30');
    ctx.font = '800 17px "Plus Jakarta Sans", Inter, sans-serif';
    ctx.fillText(cfg.value || '', cx, cy - 4);
    if (cfg.label) {
      ctx.fillStyle = cfg.labelColor || (darkTheme ? '#8a97ab' : '#727785');
      ctx.font = '600 8px Inter, sans-serif';
      ctx.fillText(cfg.label, cx, cy + 9);
    }
    ctx.restore();
  }
};
if (typeof Chart !== 'undefined' && Chart.register) {
  try { Chart.register(valueLabelsPlugin, donutCenterPlugin); } catch (e) {}
}

function safeDestroyChart(canvasId, globalVarName) {
  if (globalVarName && window[globalVarName]) {
    try {
      window[globalVarName].destroy();
      window[globalVarName] = null;
    } catch (e) {
      console.warn('Error destroying ' + globalVarName + ':', e);
    }
  }
  var el = document.getElementById(canvasId);
  if (el && typeof Chart !== 'undefined' && Chart.getChart) {
    try {
      var existing = Chart.getChart(el);
      if (existing) {
        existing.destroy();
      }
    } catch (e) {
      console.warn('Error destroying via Chart.getChart for ' + canvasId + ':', e);
    }
  }
}

// Update a chart in place when it already exists (no canvas teardown = no flicker),
// only creating a fresh instance the first time or if the chart type changed. This
// is what kills the flash on filter changes: the cache paint creates the chart, and
// the later network paint just updates its data smoothly instead of destroying it.
function upsertChart(canvasId, globalVarName, config) {
  var el = document.getElementById(canvasId);
  if (!el) return null;
  var chart = window[globalVarName];
  if (chart && chart.canvas === el && chart.config && chart.config.type === config.type) {
    try {
      chart.data.labels = config.data.labels;
      for (var i = 0; i < config.data.datasets.length; i++) {
        if (chart.data.datasets[i]) {
          var src = config.data.datasets[i];
          var dst = chart.data.datasets[i];
          for (var k in src) { if (Object.prototype.hasOwnProperty.call(src, k)) dst[k] = src[k]; }
        } else {
          chart.data.datasets[i] = config.data.datasets[i];
        }
      }
      chart.data.datasets.length = config.data.datasets.length;
      // Carry over dynamic plugin options (e.g. the donut center value/label).
      if (config.options && config.options.plugins) {
        chart.options.plugins = chart.options.plugins || {};
        for (var pk in config.options.plugins) {
          if (Object.prototype.hasOwnProperty.call(config.options.plugins, pk)) {
            chart.options.plugins[pk] = config.options.plugins[pk];
          }
        }
      }
      // Carry over scales + interaction too — otherwise a light/dark theme flip
      // updates the marks but leaves the AXIS tick/grid colors stale (unreadable
      // gray-on-dark axes after toggling).
      if (config.options && config.options.scales) chart.options.scales = config.options.scales;
      if (config.options && config.options.interaction) chart.options.interaction = config.options.interaction;
      chart.update('none');
      return chart;
    } catch (e) {
      // Any failure -> fall through and rebuild from scratch.
    }
  }
  safeDestroyChart(canvasId, globalVarName);
  window[globalVarName] = new Chart(el, config);
  return window[globalVarName];
}

function renderOverviewCharts(stats) {
  if (typeof window.Chart === 'undefined') {
    reportClientError(new Error('window.Chart is undefined'), 'renderOverviewCharts-check');
    return;
  }
  var t = syncChartTheme();
  try {
    var el = document.getElementById('c-engage');
    if (el && stats && stats.engagementOverTime) {
      var labels = stats.engagementOverTime.map(function(d) { return d.label; });
      var openRates = stats.engagementOverTime.map(function(d) { return d.openRate; });
      var replyRates = stats.engagementOverTime.map(function(d) { return d.replyRate; });

      upsertChart('c-engage', 'engageChart', {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            { label: 'Open rate',  data: openRates,  borderColor: t.open,  backgroundColor: t.openSoft,  tension: .35, fill: true, pointRadius: 0, pointHoverRadius: 4, pointHitRadius: 16, pointBackgroundColor: t.open,  borderWidth: 2 },
            { label: 'Reply rate', data: replyRates, borderColor: t.reply, backgroundColor: t.replySoft, tension: .35, fill: true, pointRadius: 0, pointHoverRadius: 4, pointHitRadius: 16, pointBackgroundColor: t.reply, borderWidth: 2 }
          ]
        },
        options: {
          ...G,
          // Crosshair-style hover: one tooltip lists BOTH series at that date.
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: chartLegend(t),
            tooltip: chartTip(t, { callbacks: { label: pctLabel } }),
            valueLabels: { mode: 'peak' }
          },
          scales: { x: { ...ng, ticks: { ...ng.ticks, maxTicksLimit: 8 } }, y: { ...sc, ticks: { ...sc.ticks, callback: function(v) { return v + '%' }, maxTicksLimit: 5 }, min: 0, max: 100 } }
        }
      });
    }
  } catch (e) {
    console.error('Error rendering engagement chart:', e);
    reportClientError(e, 'renderOverviewCharts-engage');
  }

  try {
    var el2 = document.getElementById('c-donut');
    if (el2 && stats) {
      var f = stats.funnel || { sent: 0, opened: 0, replied: 0 };
      var totalSent = f.sent || 0;
      var replied = f.replied || 0;
      var openedNoReply = Math.max(0, (f.opened || 0) - replied);
      var noAction = Math.max(0, totalSent - (f.opened || 0));

      var pReplied = totalSent > 0 ? Math.round((replied / totalSent) * 100) : 0;
      var pOpened = totalSent > 0 ? Math.round((openedNoReply / totalSent) * 100) : 0;
      var pNone = totalSent > 0 ? (100 - pReplied - pOpened) : 100;
      if (pNone < 0) pNone = 0;

      var replLbl = document.getElementById('v-donut-replied');
      var openLbl = document.getElementById('v-donut-opened');
      var noneLbl = document.getElementById('v-donut-none');
      if (replLbl) replLbl.textContent = pReplied + '%';
      if (openLbl) openLbl.textContent = pOpened + '%';
      if (noneLbl) noneLbl.textContent = pNone + '%';

      upsertChart('c-donut', 'donutChart', {
        type: 'doughnut',
        data: {
          labels: ['Replied', 'Opened, no reply', 'No action'],
          datasets: [{
            data: [pReplied, pOpened, pNone],
            // Semantic: replies emerald, opens indigo, no-action neutral — matches
            // the side legend and every other chart. 2px surface-color borders
            // give the segments the mark-spec surface gap.
            backgroundColor: [t.reply, t.open, t.neutral],
            borderColor: t.surface,
            borderWidth: 2,
            hoverOffset: 5
          }]
        },
        options: {
          ...G,
          cutout: '72%',
          layout: { padding: 6 }, // room for the hoverOffset lift on a 90px canvas
          plugins: {
            legend: { display: false }, // direct-labeled by the HTML side legend
            // No tooltip on the donut: the canvas is only 90px, so Chart.js
            // tooltips clip/overlap the side legend. Every value is already
            // direct-labeled (center % + the side legend rows).
            tooltip: { enabled: false },
            donutCenter: { value: pReplied + '%', label: 'replied' }
          }
        }
      });
    }
  } catch (e) {
    console.error('Error rendering donut chart:', e);
    reportClientError(e, 'renderOverviewCharts-donut');
  }
}

function buildTimingCharts(stats) {
  var t = syncChartTheme();
  var daysData = [0, 0, 0, 0, 0, 0, 0];
  if (stats && stats.openRateByDay) {
    daysData = stats.openRateByDay;
  }

  try {
    var elDays = document.getElementById('c-days');
    if (elDays) {
      upsertChart('c-days', 'daysChart', {
        type: 'bar',
        data: {
          labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          datasets: [{
            label: 'Open rate',
            data: daysData,
            // Sequential indigo by magnitude — darker = better day.
            backgroundColor: function(ctx) {
              var v = daysData[ctx.dataIndex];
              return v >= 10 ? t.seqHigh : v >= 5 ? t.seqMid : v > 0 ? t.seqLow : t.neutral;
            },
            hoverBackgroundColor: t.seqHigh,
            borderRadius: 4,
            borderWidth: 0,
            maxBarThickness: 30
          }]
        },
        options: {
          ...G,
          plugins: {
            legend: { display: false }, // single series — the card title names it
            tooltip: chartTip(t, { callbacks: { label: pctLabel } })
          },
          scales: { x: { ...ng }, y: { ...sc, ticks: { ...sc.ticks, callback: function(v) { return v + '%' }, maxTicksLimit: 5 }, min: 0, suggestedMax: 100 } }
        }
      });
    }
  } catch (e) {
    console.error('Error creating daysChart:', e);
  }

  var hoursLabels = ['12am', '1am', '2am', '3am', '4am', '5am', '6am', '7am', '8am', '9am', '10am', '11am', '12pm', '1pm', '2pm', '3pm', '4pm', '5pm', '6pm', '7pm', '8pm', '9pm', '10pm', '11pm'];
  var hoursData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
  if (stats && stats.openRateByHour) {
    hoursData = stats.openRateByHour;
  }

  try {
    var elHours = document.getElementById('c-hours');
    if (elHours) {
      upsertChart('c-hours', 'hoursChart', {
        type: 'line',
        data: {
          labels: hoursLabels,
          datasets: [{
            label: 'Open rate',
            data: hoursData,
            borderColor: t.open,
            backgroundColor: t.openSoft,
            tension: .35,
            fill: true,
            pointRadius: 0,
            pointHoverRadius: 4,
            pointHitRadius: 14,
            pointBackgroundColor: t.open,
            borderWidth: 2
          }]
        },
        options: {
          ...G,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: { display: false }, // single series
            tooltip: chartTip(t, { callbacks: { label: pctLabel } }),
            valueLabels: { mode: 'peak' }
          },
          scales: { x: { ...ng, ticks: { ...ng.ticks, maxTicksLimit: 8 } }, y: { ...sc, ticks: { ...sc.ticks, callback: function(v) { return v + '%' }, maxTicksLimit: 5 }, min: 0, suggestedMax: 100 } }
        }
      });
    }
  } catch (e) {
    console.error('Error creating hoursChart:', e);
  }

  var initialRates = [0, 0, 0, 0, 0]; // Mon-Fri default initial reply rates
  var followupRates = [0, 0, 0, 0, 0]; // Mon-Fri default followup reply rates
  if (stats && stats.followupStats && stats.followupStats.initial && stats.followupStats.followup) {
    initialRates = stats.followupStats.initial.slice(0, 5);
    followupRates = stats.followupStats.followup.slice(0, 5);
  }

  try {
    var elFu = document.getElementById('c-followup');
    if (elFu) {
      upsertChart('c-followup', 'followupChart', {
        type: 'bar',
        data: {
          labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
          datasets: [
            // Both series are REPLY rates, so both live in the emerald family:
            // solid = initial email, lighter = follow-up. Legend disambiguates.
            { label: 'Initial email',  data: initialRates,  backgroundColor: t.reply,                                              hoverBackgroundColor: t.reply, borderRadius: 4, borderWidth: 0, maxBarThickness: 22 },
            { label: 'Follow-up',      data: followupRates, backgroundColor: t.dark ? 'rgba(15,157,110,0.38)' : 'rgba(15,157,110,0.32)', hoverBackgroundColor: t.reply, borderRadius: 4, borderWidth: 0, maxBarThickness: 22 }
          ]
        },
        options: {
          ...G,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: chartLegend(t),
            tooltip: chartTip(t, { callbacks: { label: pctLabel } })
          },
          scales: { x: { ...ng }, y: { ...sc, ticks: { ...sc.ticks, callback: function(v) { return v + '%' }, maxTicksLimit: 5 }, min: 0, suggestedMax: 100 } }
        }
      });
    }
  } catch (e) {
    console.error('Error creating followupChart:', e);
  }

  try {
    var hm = document.getElementById('hm-grid'), hml = document.getElementById('hm-leg');
    if (hm && hml) {
      // Skip the full heatmap/best-windows DOM rebuild when the underlying data
      // hasn't changed — rebuilding ~50 cells on every poll made Best Time flicker.
      // Theme is part of the signature so a light/dark switch repaints the cells.
      var hmSig = JSON.stringify([stats && stats.heatmap, stats && stats.openRateByHour, t.dark]);
      if (hm._sndrSig === hmSig && hm.children.length > 0) return;
      hm._sndrSig = hmSig;
      hm.innerHTML = '';
      hml.innerHTML = '';
      var days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      var times = ['6am', '9am', '12pm', '3pm', '6pm', '9pm'];
      var heatmapData = stats && stats.heatmap ? stats.heatmap : Array(6).fill(null).map(() => Array(7).fill(0));

      // Update Peak Hour subtitle dynamically
      var peakHourIdx = 9; // default 9am
      var maxHourVal = -1;
      for (var h = 0; h < 24; h++) {
        var v = hoursData[h] || 0;
        if (v > maxHourVal) {
          maxHourVal = v;
          peakHourIdx = h;
        }
      }
      var peakHourSub = document.getElementById('peak-hour-sub');
      if (peakHourSub) {
        var isComment = peakHourSub.textContent.trim().startsWith('//');
        var peakText = maxHourVal > 0 ? 'peak ' + hoursLabels[peakHourIdx] : 'no opens recorded yet';
        peakHourSub.textContent = (isComment ? '// ' : '') + peakText;
      }

      // Update Best Send Windows dynamically
      var timeRanges = ['6–9am', '9am–12pm', '12–3pm', '3–6pm', '6–9pm', '9pm–6am'];
      var slots = [];
      var dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      for (var r = 0; r < 6; r++) {
        for (var d = 0; d < 7; d++) {
          slots.push({
            dayIndex: d,
            timeIndex: r,
            dayName: dayNames[d],
            timeRange: timeRanges[r],
            rate: heatmapData[r][d] || 0
          });
        }
      }
      slots.sort(function(a, b) {
        if (b.rate !== a.rate) {
          return b.rate - a.rate;
        }
        if (a.dayIndex !== b.dayIndex) return a.dayIndex - b.dayIndex;
        return a.timeIndex - b.timeIndex;
      });

      var bestWindowsList = document.getElementById('best-windows-list');
      if (bestWindowsList) {
        var html = '';
        var top5 = slots.slice(0, 5);
        top5.forEach(function(s, idx) {
          var rankStr = String(idx + 1).padStart(2, '0');
          var isBest = idx < 2;
          html += '<div class="tr-item' + (isBest ? ' best' : '') + '">' +
                    '<span class="tr-rank">' + rankStr + '</span>' +
                    '<span class="tr-day">' + s.dayName + '</span>' +
                    '<span class="tr-time">' + s.timeRange + '</span>' +
                    '<span class="tr-rate">' + s.rate + '%</span>' +
                  '</div>';
        });
        bestWindowsList.innerHTML = html;
      }

      hm.appendChild(document.createElement('div'));
      days.forEach(function(d) {
        var e = document.createElement('div');
        e.className = 'hm-head';
        e.textContent = d;
        hm.appendChild(e);
      });

      times.forEach(function(t, ri) {
        var lbl = document.createElement('div');
        lbl.className = 'hm-lbl';
        lbl.textContent = t;
        hm.appendChild(lbl);

        heatmapData[ri].forEach(function(v) {
          var cell = document.createElement('div');
          cell.className = 'hm-cell';
          var op = v > 40 ? 0.85 : v > 25 ? 0.6 : v > 15 ? 0.38 : v > 5 ? 0.18 : (t.dark ? 0.1 : 0.06);
          cell.style.background = 'rgba(' + t.heatRgb + ',' + op + ')';
          cell.title = v + '% open activity';
          if (v > 0) {
            cell.textContent = v + '%';
            cell.style.color = op >= 0.38 ? '#ffffff' : (t.dark ? '#c2ccdb' : '#3730a3');
            cell.style.fontSize = '9px';
            cell.style.fontWeight = '700';
            cell.style.display = 'flex';
            cell.style.alignItems = 'center';
            cell.style.justifyContent = 'center';
          }
          hm.appendChild(cell);
        });
      });

      [.06, .18, .38, .6, .85].forEach(function(a) {
        var sq = document.createElement('div');
        sq.className = 'hm-sq';
        sq.style.background = 'rgba(' + t.heatRgb + ',' + a + ')';
        hml.appendChild(sq);
      });
    }
  } catch (e) {
    console.error('Error creating heatmap:', e);
  }
}

function buildContactCharts(stats) {
  safeDestroyChart('c-company', 'companyChart');
}

function buildCampCharts(campaigns) {
  if (!campaigns || campaigns.length === 0) { safeDestroyChart('c-camp', 'campChartInstance'); return; }

  var labels = campaigns.map(function(c) { return c.name; }).slice(0, 5);
  var openData = campaigns.map(function(c) {
    var s = c.stats || { sent: 0, opened: 0 };
    var sent = Number(s.sent) || 0;
    return sent > 0 ? Math.round((Number(s.opened) || 0) / sent * 100) : 0;
  }).slice(0, 5);
  var replyData = campaigns.map(function(c) {
    var s = c.stats || { sent: 0, replied: 0 };
    var sent = Number(s.sent) || 0;
    return sent > 0 ? Math.round((Number(s.replied) || 0) / sent * 100) : 0;
  }).slice(0, 5);

  try {
    var el = document.getElementById('c-camp');
    if (el) {
      var t = syncChartTheme();
      var axisColor = t.dark ? '#c2ccdb' : '#424754';
      upsertChart('c-camp', 'campChartInstance', {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [
            // Same semantic palette as every other chart: indigo=opens, emerald=replies.
            { label: 'Open rate',  data: openData,  backgroundColor: t.open,  borderRadius: 4, borderWidth: 0, maxBarThickness: 36 },
            { label: 'Reply rate', data: replyData, backgroundColor: t.reply, borderRadius: 4, borderWidth: 0, maxBarThickness: 36 }
          ]
        },
        options: {
          ...G,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: chartLegend(t),
            tooltip: chartTip(t, { callbacks: { label: pctLabel } })
          },
          scales: {
            x: { ...ng, ticks: { ...ng.ticks, font: { size: 11, weight: '600', family: CHART_FONT }, color: axisColor, maxRotation: 0, callback: function(v) { var l = this.getLabelForValue(v); return (l && l.length > 14) ? l.slice(0, 13) + '…' : l; } } },
            y: { ...sc, ticks: { ...sc.ticks, callback: function(v) { return v + '%' }, maxTicksLimit: 5 }, min: 0, max: 100 }
          }
        }
      });
    }
  } catch (e) {}
}

// ══════════════════════════════════════════════════════════════
// FIND EMAILS SCREEN: auto-triggers on tab open
// ══════════════════════════════════════════════════════════════
var _findContacts = [];
var _emailResults = {};
var _domainCache  = {};
var _finding      = false;

function loadFindScreen(){
  if(typeof chrome === 'undefined' || !chrome.storage){
    renderFindEmpty(); return;
  }
  chrome.storage.local.get(['extractedContacts'], function(data){
    _findContacts = data.extractedContacts || [];
    renderFindScreen();
    if(_findContacts.length > 0){
      setTimeout(autoFindAll, 800);
    }
  });
}

function autoFindAll(){
  if(_finding) return;
  var pending = _findContacts.filter(function(c){
    return !_emailResults[c.id||c.profileUrl];
  });
  if(!pending.length) return;
  _finding = true;
  var btn = document.getElementById('btn-find-all');
  if(btn){ btn.disabled=true; btn.innerHTML='<span class="mi" style="font-size:15px">hourglass_top</span>Finding emails...'; }
  var i = 0;
  function next(){
    if(i >= pending.length){
      _finding = false;
      if(btn){ btn.disabled=false; btn.innerHTML='<span class="mi" style="font-size:15px">check_circle</span>All Done!'; }
      return;
    }
    var c = pending[i++];
    findOneEmail(c.id||c.profileUrl, c.name, c.company||c.headline);
    setTimeout(next, 1200);
  }
  next();
}

function renderFindScreen(){
  var grid    = document.getElementById('find-grid');
  var count   = document.getElementById('find-count');
  var findBtn = document.getElementById('btn-find-all');
  if(!grid) return;

  if(!_findContacts.length){
    renderFindEmpty();
    if(findBtn) findBtn.disabled = true;
    return;
  }

  if(count) count.innerHTML = '<span>'+_findContacts.length+'</span> contacts extracted';
  if(findBtn){ findBtn.disabled=false; findBtn.innerHTML='<span class="mi" style="font-size:15px">search</span>Find All Emails ('+_findContacts.length+')'; }

  grid.innerHTML = '';
  _findContacts.forEach(function(c){
    var id     = c.id || c.profileUrl || '';
    var result = _emailResults[id];
    var initials = (c.name||'?').split(' ').map(function(w){return w[0]||'';}).slice(0,2).join('').toUpperCase();
    var card = document.createElement('div');
    card.className = 'fc';
    card.id = 'fc-'+safeId(id);
    card.innerHTML =
      '<div class="fc-top">' +
        '<div class="fc-av">'+escHtml(initials)+'</div>' +
        '<div class="fc-info">' +
          '<div class="fc-name">'+escHtml(c.name||'Unknown')+'</div>' +
          '<div class="fc-co">'+escHtml(c.company||c.headline||'—')+'</div>' +
        '</div>' +
        '<button class="fc-search-btn" id="fcb-'+safeId(id)+'" title="Find email">' +
          '<span class="mi" style="font-size:16px">'+(result?'check_circle':'search')+'</span>' +
        '</button>' +
      '</div>' +
      '<div class="fc-result" id="fcr-'+safeId(id)+'">' +
        (result
          ? '<span class="fc-email">'+escHtml(result.email)+'</span><span class="fc-src fc-src-'+escHtml(result.source)+'">'+escHtml(result.source)+'</span>'
          : '<span class="fc-pending">Searching...</span>'
        ) +
      '</div>';
    grid.appendChild(card);
    card.querySelector('#fcb-'+safeId(id)).addEventListener('click', function(){
      findOneEmail(id, c.name, c.company||c.headline);
    });
  });
  _updateFindActions();
}

function renderFindEmpty(){
  var grid = document.getElementById('find-grid');
  if(!grid) return;
  grid.innerHTML =
    '<div class="find-empty" style="grid-column:1/-1">' +
      '<span class="mi">person_search</span>' +
      '<div class="find-empty-title">No contacts extracted yet</div>' +
      '<div class="find-empty-sub">Go to LinkedIn and scroll through a company People page. SNDR. will automatically collect contacts as you scroll.</div>' +
      '<div class="find-steps">' +
        '<div class="find-step"><div class="find-step-num">1</div><div class="find-step-txt">Go to LinkedIn → any company → People tab</div></div>' +
        '<div class="find-step"><div class="find-step-num">2</div><div class="find-step-txt">Scroll down: Contacts save automatically</div></div>' +
        '<div class="find-step"><div class="find-step-num">3</div><div class="find-step-txt">Come back here: Emails found automatically</div></div>' +
      '</div>' +
    '</div>';
}

function safeId(str){ return (str||'').replace(/[^a-z0-9]/gi,''); }

async function resolveDomain(company, profileUrl){
  if(!company && !profileUrl) return null;
  if(company){
    if(_domainCache[company]) return _domainCache[company];
    try{
      var r = await fetch(API_URL+'/finder/autocomplete?q='+encodeURIComponent(company)+'&country=IN');
      var data = await r.json();
      if(data && data.length && data[0]._domain){
        _domainCache[company] = data[0]._domain;
        return data[0]._domain;
      }
    }catch(e){}
    var guess = company.toLowerCase()
      .replace(/\s+(india|pvt|ltd|private|limited|inc|llc|corp|technologies|tech|ventures|capital|partners|group|services)\.?\s*/gi,'')
      .replace(/[^a-z0-9]/g,'').trim();
    if(guess){ _domainCache[company]=guess+'.com'; return guess+'.com'; }
  }
  return null;
}

async function findOneEmail(id, name, company){
  if(!name) return;
  var sid    = safeId(id);
  var btn    = document.getElementById('fcb-'+sid);
  var result = document.getElementById('fcr-'+sid);
  if(btn){ btn.disabled=true; btn.innerHTML='<span class="mi" style="font-size:16px;animation:spin .6s linear infinite">refresh</span>'; }
  if(result) result.innerHTML='<span class="fc-pending" style="color:var(--p)">Searching...</span>';
  try{
    var domain = await resolveDomain(company, id);
    if(!domain){
      if(result) result.innerHTML='<span class="fc-pending" style="color:var(--red)">Could not resolve domain</span>';
      if(btn){ btn.disabled=false; btn.innerHTML='<span class="mi" style="font-size:16px">search</span>'; }
      return;
    }
    var r = await fetch(API_URL+'/finder/find-person',{
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ name:name, domain:domain, company:company })
    });
    var data = await r.json();
    if(data.email){
      _emailResults[id] = { email:data.email, source:data.source||'found', confidence:data.confidence };
      if(result) result.innerHTML =
        '<span class="fc-email">'+escHtml(data.email)+'</span>' +
        '<span class="fc-src fc-src-'+escHtml(data.source)+'">'+escHtml(data.source)+'</span>';
      if(btn){ btn.disabled=false; btn.innerHTML='<span class="mi" style="font-size:16px;color:#059669">check_circle</span>'; }
      _updateFindActions();
    } else {
      if(result) result.innerHTML='<span class="fc-pending" style="color:#e67e00">Not found</span>';
      if(btn){ btn.disabled=false; btn.innerHTML='<span class="mi" style="font-size:16px;color:#e67e00">help_outline</span>'; }
    }
  }catch(e){
    if(result) result.innerHTML='<span class="fc-pending" style="color:var(--red)">Backend offline</span>';
    if(btn){ btn.disabled=false; btn.innerHTML='<span class="mi" style="font-size:16px">search</span>'; }
  }
}

// Clear button find screen
var btnClearContacts = document.getElementById('btn-clear-contacts');
if (btnClearContacts) {
  btnClearContacts.addEventListener('click', function() {
    if(!confirm('Clear all extracted contacts?')) return;
    if(typeof chrome !== 'undefined' && chrome.storage){
      chrome.storage.local.remove(['extractedContacts'], function(){
        _findContacts=[]; _emailResults={}; renderFindScreen();
      });
    }
  });
}

// ── Found-emails actions: Download CSV / Create Campaign ──────────────────────
// The only contacts worth exporting/seeding a campaign are the ones we actually
// found an email for, so both paths read the same _emailResults map.
function _findFoundList(){
  return (_findContacts||[]).map(function(c){
    var id = c.id || c.profileUrl || '';
    var r  = _emailResults[id];
    if(!r || !r.email) return null;
    return { name:c.name||'', email:r.email, company:c.company||c.headline||'', position:c.headline||'', linkedin:c.profileUrl||'' };
  }).filter(Boolean);
}

// Show the action buttons only once at least one email exists.
function _updateFindActions(){
  var bar = document.getElementById('fi-result-actions');
  if(!bar) return;
  bar.classList.toggle('on', _findFoundList().length > 0);
}
window._updateFindActions = _updateFindActions;

function _csvCell(v){ v = (v==null?'':String(v)); return /[",\n\r]/.test(v) ? '"'+v.replace(/"/g,'""')+'"' : v; }

function exportFoundCSV(){
  var found = _findFoundList();
  if(!found.length){ if(typeof showToast==='function') showToast('No emails to export yet.', true); return; }
  var lines = [['Name','Email','Company','Position','LinkedIn'].join(',')];
  found.forEach(function(c){ lines.push([c.name,c.email,c.company,c.position,c.linkedin].map(_csvCell).join(',')); });
  var blob = new Blob([lines.join('\r\n')], { type:'text/csv;charset=utf-8' });
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href = url; a.download = 'sndr_emails_'+found.length+'.csv';
  document.body.appendChild(a); a.click();
  setTimeout(function(){ if(a.parentNode) a.parentNode.removeChild(a); URL.revokeObjectURL(url); }, 500);
}

// Seed the campaign wizard from the found people by feeding the same column-mapping
// step that a CSV upload produces, then jumping straight to mapping (step 2).
function sndrCreateCampaignFromFound(){
  var found = _findFoundList();
  if(!found.length){ if(typeof showToast==='function') showToast('Find emails first — nothing to add to a campaign yet.', true); return; }
  goNav('compose');
  resetComposeWizard();                 // guarantee a clean slate (also clears saved state)
  parsedHeaders = ['Name','Email','Company','Position'];
  parsedRows    = found.map(function(c){ return [c.name, c.email, c.company, c.position]; });
  uploadedFile  = { name: 'LinkedIn Extract ('+found.length+' contacts)', size: 0 };
  var ss = document.getElementById('upload-status-sub');
  if (ss) ss.textContent = found.length + ' contacts detected';
  setupMappingDropdowns();
  setupMappingPreviewTable();
  if (typeof window.saveComposeState === 'function') window.saveComposeState();
  goStep(2);                            // land on column-mapping with email/name pre-guessed
}
window.sndrCreateCampaignFromFound = sndrCreateCampaignFromFound;

var btnExportCsv = document.getElementById('btn-export-csv');
if (btnExportCsv) btnExportCsv.addEventListener('click', exportFoundCSV);
var btnCreateCampaign = document.getElementById('btn-create-campaign');
if (btnCreateCampaign) btnCreateCampaign.addEventListener('click', sndrCreateCampaignFromFound);

// ── Tag Insertion Logic ──────────────────────────────────────
function showTagDropdown(btnEl, targetInputOrDiv) {
  var existing = document.getElementById('tag-dropdown-menu');
  if (existing) existing.remove();

  var tags = parsedHeaders.length > 0 ? parsedHeaders : ['email', 'name', 'company', 'role'];

  var menu = document.createElement('div');
  menu.id = 'tag-dropdown-menu';
  menu.style.position = 'fixed';
  menu.style.background = '#fff';
  menu.style.border = '1px solid var(--ol2)';
  menu.style.boxShadow = '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)';
  menu.style.borderRadius = '8px';
  menu.style.padding = '4px 0';
  menu.style.zIndex = '999999';
  menu.style.minWidth = '160px';
  menu.style.maxHeight = '200px';
  menu.style.overflowY = 'auto';

  var rect = btnEl.getBoundingClientRect();
  menu.style.top = (rect.bottom + 4) + 'px';
  menu.style.left = rect.left + 'px';

  tags.forEach(function(tag) {
    var item = document.createElement('div');
    item.style.padding = '8px 12px';
    item.style.fontSize = '12px';
    item.style.color = '#374151';
    item.style.cursor = 'pointer';
    item.style.transition = 'background-color 0.15s';
    item.textContent = '{' + tag + '}';

    item.addEventListener('mouseenter', function() {
      item.style.background = 'var(--p05)';
      item.style.color = 'var(--p)';
    });
    item.addEventListener('mouseleave', function() {
      item.style.background = 'transparent';
      item.style.color = '#374151';
    });

    item.addEventListener('click', function(e) {
      e.stopPropagation();
      insertTagAtCursor(targetInputOrDiv, '{' + tag + '}');
      var evt = document.createEvent('HTMLEvents');
      evt.initEvent('input', true, true);
      targetInputOrDiv.dispatchEvent(evt);
      menu.remove();
    });

    menu.appendChild(item);
  });

  document.body.appendChild(menu);

  function closeMenu(e) {
    if (!menu.contains(e.target) && e.target !== btnEl) {
      menu.remove();
      document.removeEventListener('click', closeMenu);
    }
  }
  setTimeout(function() {
    document.addEventListener('click', closeMenu);
  }, 50);
}

// ── Live Preview & Placeholder Resolution ─────────────────────
function resolvePlaceholders(text) {
  if (!text) return '';
  
  var hasRows = parsedRows && parsedRows.length > 0;
  var firstRow = hasRows ? parsedRows[0] : null;

  return text.replace(/\{\{\s*([a-zA-Z0-9_ -]+)\s*\}\}|\{\s*([a-zA-Z0-9_ -]+)\s*\}/gi, function(match, g1, g2) {
    var tagName = g1 || g2 || '';
    var cleanTag = tagName.trim().toLowerCase();
    
    // 1. Exact Match
    var colIdx = -1;
    for (var i = 0; i < parsedHeaders.length; i++) {
      if (parsedHeaders[i].trim().toLowerCase() === cleanTag) {
        colIdx = i;
        break;
      }
    }
    
    // 2. Substring Match
    if (colIdx === -1) {
      for (var i = 0; i < parsedHeaders.length; i++) {
        var h = parsedHeaders[i].trim().toLowerCase();
        if (h.includes(cleanTag) || cleanTag.includes(h)) {
          colIdx = i;
          break;
        }
      }
    }

    // 3. Dropdown Map Match
    if (colIdx === -1) {
      var mapSelectId = '';
      if (cleanTag.includes('name')) mapSelectId = 'map-name-col';
      else if (cleanTag.includes('company')) mapSelectId = 'map-company-col';
      else if (cleanTag.includes('role')) mapSelectId = 'map-role-col';
      else if (cleanTag.includes('email')) mapSelectId = 'map-email-col';

      if (mapSelectId) {
        var selectEl = document.getElementById(mapSelectId);
        if (selectEl && selectEl.value) {
          colIdx = parsedHeaders.indexOf(selectEl.value);
        }
      }
    }

    // 4. Extract first row value
    if (colIdx !== -1 && firstRow && colIdx < firstRow.length) {
      var val = firstRow[colIdx] || '';
      if ((cleanTag === 'first_name' || cleanTag === 'first name' || cleanTag === 'firstname') && val) {
        var nameColSelect = document.getElementById('map-name-col');
        var nameColName = nameColSelect ? nameColSelect.value : '';
        if (parsedHeaders[colIdx] === nameColName) {
          val = val.trim().split(/\s+/)[0] || '';
        }
      }
      if ((cleanTag === 'last_name' || cleanTag === 'last name' || cleanTag === 'lastname') && val) {
        var nameColSelect = document.getElementById('map-name-col');
        var nameColName = nameColSelect ? nameColSelect.value : '';
        if (parsedHeaders[colIdx] === nameColName) {
          var parts = val.trim().split(/\s+/);
          val = parts.length > 1 ? parts[parts.length - 1] : '';
        }
      }
      return val;
    }

    // 5. Fallback Default Dummy Values
    var dummyValues = {
      'name': 'Shubham',
      'first_name': 'Shubham',
      'first name': 'Shubham',
      'last_name': 'Sah',
      'last name': 'Sah',
      'company': 'SNDR',
      'company name': 'SNDR',
      'role': 'Founder',
      'email': 'shubhamsah914@gmail.com'
    };
    
    for (var key in dummyValues) {
      if (cleanTag.includes(key)) {
        return dummyValues[key];
      }
    }
    
    return '[' + tagName + ']';
  });
}

function updateLivePreview() {
  var stepSelect = document.getElementById('preview-step-select');
  var viewMode = stepSelect ? stepSelect.value : 'main';

  var subjectVal = '';
  var bodyVal = '';
  var signatureVal = '';
  var useSignature = false;

  if (viewMode === 'main') {
    subjectVal = document.getElementById('comp-subject') ? document.getElementById('comp-subject').value : '';
    bodyVal = document.getElementById('comp-body') ? document.getElementById('comp-body').innerHTML : '';
    var signatureCheck = document.getElementById('comp-use-signature');
    if (signatureCheck && signatureCheck.checked) {
      signatureVal = document.getElementById('comp-signature-text') ? document.getElementById('comp-signature-text').value : '';
      useSignature = true;
    }
  } else {
    var idx = parseInt(viewMode);
    var step = campaignFollowupSteps[idx];
    if (step) {
      subjectVal = step.subject || ('Re: ' + (document.getElementById('comp-subject') ? document.getElementById('comp-subject').value : ''));
      bodyVal = step.body || '';
      if (step.use_signature) {
        signatureVal = step.signature || '';
        useSignature = true;
      }
    }
  }

  var previewSubject = document.getElementById('preview-subject');
  var previewBody = document.getElementById('preview-body');

  var resolvedSubject = resolvePlaceholders(subjectVal);
  var resolvedBody = resolvePlaceholders(bodyVal);

  if (useSignature && signatureVal) {
    resolvedBody += '<br><br>' + signatureVal.replace(/\n/g, '<br>');
  }

  if (previewSubject) {
    previewSubject.textContent = resolvedSubject || '(No subject line)';
  }
  if (previewBody) {
    previewBody.innerHTML = resolvedBody || '<span style="color:var(--ol)">(No email body composed yet)</span>';
  }
  
  // Update Preview Description
  var descEl = document.getElementById('preview-contact-desc');
  if (descEl) {
    if (parsedRows && parsedRows.length > 0) {
      descEl.textContent = 'Previewing email for first contact (' + (parsedRows.length) + ' total)';
    } else {
      descEl.textContent = 'Previewing with fallback dummy data';
    }
  }
}

var _lastEditorRange = null;
var _lastActiveTextElement = null;
var _lastTextSelection = { start: 0, end: 0 };

function setupSelectionTrackers() {
  // 1. Contenteditable Editor Selection Tracker
  document.addEventListener('selectionchange', function() {
    var editor = document.getElementById('comp-body');
    if (!editor) return;
    var sel = window.getSelection();
    if (sel.rangeCount > 0) {
      var range = sel.getRangeAt(0);
      if (editor.contains(range.commonAncestorContainer)) {
        _lastEditorRange = range.cloneRange();
      }
    }
  });

  // 2. Generic Input/Textarea range tracker for all text inputs
  function saveInputSelection(e) {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
      _lastActiveTextElement = e.target;
      _lastTextSelection.start = e.target.selectionStart;
      _lastTextSelection.end = e.target.selectionEnd;
    }
  }
  document.addEventListener('keyup', saveInputSelection);
  document.addEventListener('click', saveInputSelection);
  document.addEventListener('input', saveInputSelection);
  document.addEventListener('focusin', saveInputSelection);

  // Subject Live Preview
  var subjectInput = document.getElementById('comp-subject');
  if (subjectInput) {
    subjectInput.addEventListener('input', updateLivePreview);
    subjectInput.addEventListener('keyup', updateLivePreview);
  }

  var editor = document.getElementById('comp-body');
  if (editor) {
    editor.addEventListener('input', updateLivePreview);
    editor.addEventListener('keyup', updateLivePreview);
  }

  // Formatting toolbar actions
  document.querySelectorAll('.rich-tb .tb-btn[data-cmd]').forEach(function(btn) {
    btn.addEventListener('mousedown', function(e) {
      e.preventDefault(); // Prevent focus loss on editor
    });
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      var cmd = this.getAttribute('data-cmd');
      if (cmd === 'bold') {
        document.execCommand('bold', false, null);
      } else if (cmd === 'italic') {
        document.execCommand('italic', false, null);
      } else if (cmd === 'underline') {
        document.execCommand('underline', false, null);
      } else if (cmd === 'h1') {
        document.execCommand('formatBlock', false, '<h1>');
      } else if (cmd === 'h2') {
        document.execCommand('formatBlock', false, '<h2>');
      } else if (cmd === 'link') {
        var url = prompt('Enter link URL:');
        if (url) {
          var selection = window.getSelection();
          var selectedText = selection.toString() || url;
          var a = document.createElement('a');
          a.href = url;
          a.textContent = selectedText;
          
          if (selection.rangeCount > 0) {
            var range = selection.getRangeAt(0);
            range.deleteContents();
            range.insertNode(a);
            
            var newRange = document.createRange();
            newRange.setStartAfter(a);
            newRange.collapse(true);
            selection.removeAllRanges();
            selection.addRange(newRange);
          } else {
            var editorEl = document.getElementById('comp-body');
            if (editorEl) editorEl.appendChild(a);
          }
        }
      }
      updateLivePreview();
    });
  });

  // 3. Signature Toggle
  var useSigCheck = document.getElementById('comp-use-signature');
  var sigText = document.getElementById('comp-signature-text');
  if (useSigCheck && sigText) {
    useSigCheck.addEventListener('change', function() {
      var show = useSigCheck.checked;
      sigText.style.display = show ? 'block' : 'none';
      var btnUpload = document.getElementById('btn-upload-main-sig');
      if (btnUpload) btnUpload.style.display = show ? 'inline-block' : 'none';
      updateLivePreview();
    });
    sigText.addEventListener('input', updateLivePreview);

    // Setup main signature file uploader
    var btnUploadMainSig = document.getElementById('btn-upload-main-sig');
    var inputMainSigFile = document.getElementById('comp-main-sig-file');
    if (btnUploadMainSig && inputMainSigFile) {
      btnUploadMainSig.addEventListener('click', function() {
        inputMainSigFile.click();
      });
      inputMainSigFile.addEventListener('change', function() {
        var file = inputMainSigFile.files[0];
        if (!file) return;
        var reader = new FileReader();
        var isImg = file.type.startsWith('image/') || /\.(png|jpg|jpeg|gif|webp|svg|bmp|ico)$/i.test(file.name);
        if (isImg) {
          reader.onload = function(e) {
            sigText.value += '\n<img src="' + e.target.result + '" style="max-width:150px; max-height:80px; object-fit:contain;">';
            updateLivePreview();
            if (typeof window.saveComposeState === 'function') window.saveComposeState();
          };
          reader.readAsDataURL(file);
        } else {
          reader.onload = function(e) {
            var txt = e.target.result || '';
            var lower = txt.trim().toLowerCase();
            if (lower.startsWith('<!doctype') || lower.startsWith('<html') || txt.includes('<!-- saved from')) {
              showToast('Warning: Uploaded file appears to be a full webpage, not a signature snippet.', true);
              return;
            }
            sigText.value = txt;
            updateLivePreview();
            if (typeof window.saveComposeState === 'function') window.saveComposeState();
          };
          reader.readAsText(file);
        }
      });
    }
  }

  // 4. Attachments Selector
  var attachmentsInput = document.getElementById('comp-attachments');
  var attachmentsListEl = document.getElementById('attachments-list');
  if (attachmentsInput && attachmentsListEl) {
    attachmentsInput.addEventListener('change', function() {
      campaignAttachments = [];
      attachmentsListEl.innerHTML = '';
      
      var files = attachmentsInput.files;
      if (files.length === 0) return;

      Array.from(files).forEach(function(file) {
        var reader = new FileReader();
        reader.onload = function(e) {
          campaignAttachments.push({
            filename: file.name,
            contentType: file.type,
            content: e.target.result
          });
          
          var fileEl = document.createElement('div');
          fileEl.style.display = 'flex';
          fileEl.style.alignItems = 'center';
          fileEl.style.gap = '6px';
          fileEl.style.background = 'var(--p05)';
          fileEl.style.padding = '4px 8px';
          fileEl.style.borderRadius = '4px';
          fileEl.style.color = 'var(--p)';
          fileEl.style.fontWeight = '500';
          fileEl.innerHTML = escHtml(file.name) + ' <span style="font-size:10px; color:var(--ol)">(' + Math.round(file.size / 1024) + ' KB)</span>';
          attachmentsListEl.appendChild(fileEl);
          if (typeof window.saveComposeState === 'function') {
            window.saveComposeState();
          }
        };
        reader.readAsDataURL(file);
      });
    });
  }
}

function insertTagAtCursor(target, tagText) {
  if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
    var start = (target === _lastActiveTextElement) ? _lastTextSelection.start : target.value.length;
    var end = (target === _lastActiveTextElement) ? _lastTextSelection.end : target.value.length;
    var text = target.value;
    target.value = text.substring(0, start) + tagText + text.substring(end);
    target.focus();
    target.selectionStart = target.selectionEnd = start + tagText.length;
    _lastTextSelection.start = _lastTextSelection.end = start + tagText.length;
    _lastActiveTextElement = target;
  } else {
    target.focus();
    var sel = window.getSelection();
    var range = _lastEditorRange;
    
    if (range && target.contains(range.commonAncestorContainer)) {
      sel.removeAllRanges();
      sel.addRange(range);
      
      range.deleteContents();
      var el = document.createTextNode(tagText);
      range.insertNode(el);
      
      var newRange = document.createRange();
      newRange.setStartAfter(el);
      newRange.collapse(true);
      sel.removeAllRanges();
      sel.addRange(newRange);
      
      _lastEditorRange = newRange.cloneRange();
    } else {
      target.focus();
      var newRange = document.createRange();
      newRange.selectNodeContents(target);
      newRange.collapse(false);
      sel.removeAllRanges();
      sel.addRange(newRange);
      
      var el = document.createTextNode(tagText);
      newRange.insertNode(el);
      
      var postRange = document.createRange();
      postRange.setStartAfter(el);
      postRange.collapse(true);
      sel.removeAllRanges();
      sel.addRange(postRange);
      
      _lastEditorRange = postRange.cloneRange();
    }
  }
}

// Bind tag buttons
var btnTagSubject = document.getElementById('btn-tag-subject');
if (btnTagSubject) {
  btnTagSubject.addEventListener('click', function(e) {
    e.preventDefault();
    e.stopPropagation();
    var target = document.getElementById('comp-subject');
    if (target) showTagDropdown(btnTagSubject, target);
  });
}

var btnTagBody = document.getElementById('btn-tag-body');
if (btnTagBody) {
  btnTagBody.addEventListener('click', function(e) {
    e.preventDefault();
    e.stopPropagation();
    var target = document.getElementById('comp-body');
    if (target) showTagDropdown(btnTagBody, target);
  });
}

// ── Templates load/save handlers ─────────────────────────────
var savedTemplates = [];

async function loadTemplatesList() {
  var select = document.getElementById('comp-template-select');
  if (!select) return;

  try {
    var list = await apiCall('GET', '/campaigns/templates');
    savedTemplates = list;
    
    // Clear other options except placeholder
    select.innerHTML = '<option value="">-- Load Saved Template --</option>';
    
    list.forEach(function(tpl) {
      var opt = document.createElement('option');
      opt.value = tpl.id;
      opt.textContent = tpl.name;
      select.appendChild(opt);
    });
  } catch (err) {
    console.error('Error loading templates:', err);
  }
}

// Shared delete used by the main-email template dropdown and the per-step follow-up
// dropdowns (templates are shared, so refresh both lists after deleting).
async function deleteSavedTemplate(id, name) {
  if (!id) { showToast('Select a saved template to delete first.', true); return; }
  if (!confirm('Delete the saved template "' + (name || id) + '"? This cannot be undone.')) return;
  try {
    await apiCall('DELETE', '/campaigns/templates/' + id);
    showToast('Template deleted.');
    await loadTemplatesList();
    if (typeof renderFollowupSteps === 'function') renderFollowupSteps();
  } catch (err) {
    showToast('Failed to delete template: ' + err.message, true);
  }
}

function setupTemplateHandlers() {
  var select = document.getElementById('comp-template-select');
  var btnSave = document.getElementById('btn-save-template');
  var btnDelete = document.getElementById('btn-delete-template');
  var subjectInput = document.getElementById('comp-subject');
  var editor = document.getElementById('comp-body');

  if (btnDelete) {
    btnDelete.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      var id = select ? select.value : '';
      var tpl = savedTemplates.find(function(t) { return t.id === id; });
      deleteSavedTemplate(id, tpl ? tpl.name : '');
    });
  }

  if (select) {
    select.addEventListener('change', function() {
      var val = select.value;
      if (!val) return;
      
      var tpl = savedTemplates.find(function(t) { return t.id === val; });
      if (tpl) {
        if (subjectInput) {
          subjectInput.value = tpl.subject || '';
        }
        if (editor) {
          editor.innerHTML = tpl.body_html || '';
        }
        updateLivePreview();
        if (typeof window.saveComposeState === 'function') {
          window.saveComposeState();
        }
      }
    });
  }

  if (btnSave) {
    btnSave.addEventListener('click', async function(e) {
      e.preventDefault();
      e.stopPropagation();

      var name = prompt('Enter a name for this template:');
      if (!name || name.trim() === '') {
        return;
      }

      var subject = subjectInput ? subjectInput.value : '';
      var bodyHtml = editor ? editor.innerHTML : '';

      try {
        btnSave.disabled = true;
        var res = await apiCall('POST', '/campaigns/templates', {
          name: name.trim(),
          subject: subject,
          body_html: bodyHtml
        });
        showToast('Template saved successfully!');
        await loadTemplatesList();
        if (select) {
          select.value = res.id;
        }
      } catch (err) {
        showToast('Failed to save template: ' + err.message, true);
      } finally {
        btnSave.disabled = false;
      }
    });
  }
}

// ── Live Polling for Real-time Updates ───────────────────────
function startLivePolling() {
  // Guard against ever starting two loops (would double every request).
  if (window._pollingStarted) return;
  window._pollingStarted = true;

  var POLL_MS = 8000;     // serialized; the old 4s setInterval stacked on cold starts
  var inFlight = false;   // never run a new poll while the previous hasn't settled

  function schedule() { setTimeout(tick, POLL_MS); }

  async function tick() {
    // Skip work when the tab is hidden or a previous poll is still running.
    if (document.hidden || inFlight) { schedule(); return; }
    inFlight = true;
    try {
      if (!activeAccount) {
        await loadSidebar(false);
        if (activeAccount) {
          var s0 = document.querySelector('.screen.on');
          if (s0 && s0.id === 'screen-overview') await loadOverview(true);
        }
      } else {
        var activeScreen = document.querySelector('.screen.on');
        if (activeScreen) {
          var screenId = activeScreen.id;
          if (screenId === 'screen-overview') await loadOverview(true);
          else if (screenId === 'screen-contacts') await loadContacts(true, true);
          else if (screenId === 'screen-timing') await loadTiming();
          else if (screenId === 'screen-campaigns') await loadCampaigns(true);
        }
      }
    } catch (e) {
      console.error('Polling error:', e);
    } finally {
      inFlight = false;
      schedule();   // schedule the NEXT poll only after this one fully settles
    }
  }

  schedule();
}

// Call setup
setupSelectionTrackers();
setupTemplateHandlers();
setupFollowupStepHandlers();

function setupFollowupStepHandlers() {
  var btnAdd = document.getElementById('btn-add-followup');
  if (btnAdd) {
    btnAdd.addEventListener('click', function() {
      campaignFollowupSteps.push({
        step: campaignFollowupSteps.length + 1,
        subject: '',
        body: '',
        delay_days: 3,
        specific_date: '',
        send_time: '09:00',
        trigger: 'no_reply',
        signature: '',
        use_signature: true,
        attachments: []
      });
      renderFollowupSteps();
      updatePreviewStepSelect();
      updateLivePreview();
      if (typeof window.saveComposeState === 'function') {
        window.saveComposeState();
      }
    });
  }

  var previewStepSelect = document.getElementById('preview-step-select');
  if (previewStepSelect) {
    previewStepSelect.addEventListener('change', function() {
      updateLivePreview();
    });
  }
}

// ── Initial Boot ────────────────────────────────────────────
async function initDashboard() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    await new Promise(function(resolve) {
      chrome.storage.local.get(['custom_api_url'], async function(data) {
        if (data.custom_api_url) {
          API_URL = data.custom_api_url;
          console.log('[SNDR] Dashboard using API URL:', API_URL);
        }
        resolve();
      });
    });
  } else {
    if (window.location.hostname === 'localhost') {
      API_URL = window.location.origin;
    }
  }

  var urlParams = new URLSearchParams(window.location.search);
  var isAuthView = urlParams.get('view') === 'forgot' || urlParams.get('view') === 'reset';

  // Pre-load from localStorage cache synchronously for instant UI rendering
  try {
    // Read any legacy localStorage session copy for instant UI only, then purge it.
    // The session token's source of truth is chrome.storage.local (read in loadSidebar/apiCall).
    var sess = localStorage.getItem('sndr_session');
    localStorage.removeItem('sndr_session');
    if (sess && !isAuthView) {
      var session = JSON.parse(sess);
      var welcomeName = bestDisplayName(session);
      var nameEl = document.getElementById('u-name');
      var emailEl = document.getElementById('u-email');
      var avEl = document.getElementById('u-av');
      if (nameEl) nameEl.textContent = welcomeName;
      if (avEl) avEl.textContent = welcomeName.substring(0, 2).toUpperCase() || 'U';
      var greetingNameEls = document.querySelectorAll('.user-greeting-name');
      greetingNameEls.forEach(function(el) {
        el.textContent = welcomeName;
      });
    }

    var cachedAccounts = localStorage.getItem('sndr_cached_accounts');
    if (cachedAccounts && !isAuthView) {
      var accounts = JSON.parse(cachedAccounts);
      if (accounts && accounts.length > 0) {
        activeAccount = accounts[0];
        sidebarInitialized = true;
        var displayName = activeAccount.name || (session && session.username) || activeAccount.email.split('@')[0];
        var nameEl = document.getElementById('u-name');
        var emailEl = document.getElementById('u-email');
        var avEl = document.getElementById('u-av');
        if (nameEl) nameEl.textContent = displayName;
        if (emailEl) emailEl.textContent = activeAccount.email;
        if (avEl) avEl.textContent = displayName.substring(0, 2).toUpperCase() || 'G';
        var greetingNameEls = document.querySelectorAll('.user-greeting-name');
        greetingNameEls.forEach(function(el) {
          el.textContent = displayName;
        });

        var cachedUsage = localStorage.getItem('sndr_cached_usage_' + activeAccount.id);
        if (cachedUsage) {
          var usage = JSON.parse(cachedUsage);
          var used = usage.todaySends || 0;
          var limit = usage.dailyLimit || 500;
          var pct = Math.min(100, Math.round((used / limit) * 100));
          var fillEl = document.getElementById('sb-usage-fill');
          var labelEl = document.getElementById('sb-usage-label');
          if (fillEl) {
            fillEl.style.width = pct + '%';
            fillEl.style.background = used / limit > 0.9 ? 'var(--red)' : used / limit > 0.7 ? 'var(--amber)' : 'var(--p)';
          }
          if (labelEl) {
            labelEl.textContent = used + ' / ' + limit + ' Usage (Daily)';
          }
        }
      }
    }
  } catch (e) {
    console.warn('Error loading sync cache on boot:', e);
  }

  if (!window._authHandlersSet) {
    setupDashboardAuth();
    setupDashboardSignout();
    window._authHandlersSet = true;
  }
  setupComposeAutoSave();

  // Read the session token from chrome.storage.local (source of truth);
  // fall back to localStorage only in non-extension contexts.
  var sessionExistsPromise;
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    sessionExistsPromise = new Promise(function(resolve) {
      chrome.storage.local.get(['session'], function(data) {
        resolve(!isAuthView && !!(data.session && data.session.token));
      });
    });
  } else {
    var sessionExists = false;
    try {
      var sessFallback = localStorage.getItem('sndr_session');
      if (sessFallback && !isAuthView) {
        var parsed = JSON.parse(sessFallback);
        if (parsed && parsed.token) {
          sessionExists = true;
        }
      }
    } catch(e) {}
    sessionExistsPromise = Promise.resolve(sessionExists);
  }

  // Reveal the screen immediately (no 1-second timeout delay) to achieve seamless reload
  function revealDashboard() {
    document.documentElement.classList.remove('app-loading');
    document.documentElement.classList.add('fonts-loaded');
  }

  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(revealDashboard).catch(revealDashboard);
  } else {
    revealDashboard();
  }

  sessionExistsPromise.then(function(sessionExists) {
    if (sessionExists) {
      // Reveal the app immediately based on the real (chrome.storage) session,
      // overriding the inline localStorage-based gate so refresh never dumps a
      // logged-in user onto the login overlay.
      setAuthVisibility(true);
      var savedNav = localStorage.getItem('sndr_active_nav') || 'overview';
      // The LinkedIn overlay's "Done, take me to sender" opens us with ?view=find
      // so the user lands straight on the Find screen with their extracted names.
      var _vparam = new URLSearchParams(window.location.search).get('view');
      if (_vparam === 'find') savedNav = 'find';
      goNav(savedNav);
      // If the account is already known from cache, start warming the contacts
      // cache right now (don't wait for the sidebar's accounts round-trip).
      prefetchContactsCache();
      loadSidebar(true).then(function() {
        startLivePolling();
        // Warm the Contacts cache in the background so that tab opens instantly.
        prefetchContactsCache();
      }).catch(function(e) {
        console.error('Failed to load sidebar:', e);
        startLivePolling();
      });
    } else {
      // No real session -> show the login overlay, hide the app.
      setAuthVisibility(false);
    }
  });
}

// ── AI Toolbar ────────────────────────────────────────────────

function setupAIToolbar() {
  var aiBtn = document.getElementById('btn-ai-toolbar');
  var aiPanel = document.getElementById('ai-panel');
  var aiClose = document.getElementById('ai-panel-close');
  var aiSettingsBtn = document.getElementById('ai-settings-btn');
  var aiSettingsSection = document.getElementById('ai-settings-section');
  var aiEndpointInput = document.getElementById('ai-endpoint-input');
  var aiModelInput = document.getElementById('ai-model-input');
  var aiSettingsSave = document.getElementById('ai-settings-save');
  var aiGenerateBtn = document.getElementById('ai-generate-btn');
  var aiInsertBtn = document.getElementById('ai-insert-btn');
  var aiRegenerateBtn = document.getElementById('ai-regenerate-btn');
  var aiPromptEl = document.getElementById('ai-prompt');
  var aiPromptTemplate = document.getElementById('ai-prompt-template');
  var aiPromptContainer = document.getElementById('ai-prompt-container');
  var aiToneEl = document.getElementById('ai-tone');
  var aiResult = document.getElementById('ai-result');
  var aiResultActions = document.getElementById('ai-result-actions');
  var aiLoading = document.getElementById('ai-loading');

  // Toggle prompt visibility based on template dropdown
  if (aiPromptTemplate && aiPromptContainer) {
    aiPromptTemplate.addEventListener('change', function() {
      aiPromptContainer.style.display = this.value === 'custom' ? 'block' : 'none';
    });
  }

  // Toggle panel
  aiBtn.addEventListener('mousedown', function(e) { e.preventDefault(); });
  aiBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    aiPanel.classList.toggle('open');
  });

  // Close button
  if (aiClose) {
    aiClose.addEventListener('click', function() {
      aiPanel.classList.remove('open');
    });
  }

  // Close when clicking outside
  document.addEventListener('click', function(e) {
    if (aiPanel.classList.contains('open') && !aiPanel.contains(e.target) && e.target !== aiBtn) {
      aiPanel.classList.remove('open');
    }
  });

  var toneDescriptions = {
    professional: 'formal and professional',
    friendly: 'warm and friendly',
    concise: 'brief and direct (under 90 words)',
    persuasive: 'compelling and persuasive with a strong CTA',
    casual: 'conversational and casual like talking to a colleague'
  };

  async function generateEmail() {

    var templateVal = aiPromptTemplate ? aiPromptTemplate.value : 'custom';
    var finalPrompt = '';

    if (templateVal === 'spellcheck') {
      var editor = document.getElementById('comp-body');
      var content = editor ? editor.innerText.trim() : '';
      if (!content) { showToast('Please write or insert an email into the editor first to spell check & improve flow.', true); return; }
      finalPrompt = 'Spell check and improve the flow of this email content:\n\n' + content;
    } else if (templateVal === 'internship') {
      finalPrompt = 'Draft a cold email reaching out to a company/person requesting an internship opportunity.';
    } else if (templateVal === 'job') {
      finalPrompt = 'Draft a professional cold email reaching out to a hiring manager about a job opening.';
    } else if (templateVal === 'partnership') {
      finalPrompt = 'Draft a cold outreach email proposing a business partnership or collaboration.';
    } else if (templateVal === 'formal') {
      var editor = document.getElementById('comp-body');
      var content = editor ? editor.innerText.trim() : '';
      if (!content) { showToast('Please write or insert an email into the editor first to change tone.', true); return; }
      finalPrompt = 'Rewrite the following email to make it highly formal and professional:\n\n' + content;
    } else if (templateVal === 'casual') {
      var editor = document.getElementById('comp-body');
      var content = editor ? editor.innerText.trim() : '';
      if (!content) { showToast('Please write or insert an email into the editor first to change tone.', true); return; }
      finalPrompt = 'Rewrite the following email to make it casual and warm:\n\n' + content;
    } else if (templateVal === 'concise') {
      var editor = document.getElementById('comp-body');
      var content = editor ? editor.innerText.trim() : '';
      if (!content) { showToast('Please write or insert an email into the editor first to change tone.', true); return; }
      finalPrompt = 'Rewrite the following email to make it extremely concise and direct:\n\n' + content;
    } else {
      var userPrompt = aiPromptEl ? aiPromptEl.value.trim() : '';
      if (!userPrompt) { showToast('Please enter your custom prompt instructions.', true); return; }
      finalPrompt = userPrompt;
    }

    var tone = aiToneEl ? aiToneEl.value : 'professional';

    aiGenerateBtn.disabled = true;
    aiGenerateBtn.innerHTML = '&#x23F3;';
    if (aiLoading) aiLoading.style.display = 'block';
    if (aiResult) aiResult.style.display = 'none';
    if (aiResultActions) aiResultActions.style.display = 'none';

    var systemMsg = 'You are an expert cold email copywriter. Write effective, personalized, human-sounding cold outreach emails.\n' +
      'Tone: ' + (toneDescriptions[tone] || tone) + '.\n' +
      'Use merge tag placeholders like {first_name}, {company}, {role} where appropriate to personalize.\n' +
      'Output EXACTLY in this format (two lines then body):\nSubject: <subject line here>\nBody:\n<email body here>\n' +
      'Keep the body under 150 words. Start with a direct, engaging opener. No extra explanation.';

    try {
      var resp = await fetch(API_URL + '/api/ai/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: 'Write a cold email. Output EXACTLY:\nSubject: <subject>\nBody:\n<email body under 150 words>\nTone: ' + (toneDescriptions[tone] || tone) + '.\nInstruction: ' + finalPrompt, history: [] })
      });

      if (!resp.ok) {
        var errObj2 = await resp.json().catch(function() { return {}; });
        throw new Error((errObj2.error && errObj2.error.message) || ('HTTP ' + resp.status + ' ' + resp.statusText));
      }

      var data = await resp.json();
      var text = data.reply.trim();
      // Strip out any subject prefix line if the backend AI returns one
      text = text.replace(/^(Subject|subject):\s*.*?\n+/i, '').trim();

      if (aiResult) { aiResult.textContent = text; aiResult.style.display = 'block'; }
      if (aiResultActions) { aiResultActions.style.display = 'flex'; }
    } catch (err) {
      showToast('AI error: ' + err.message, true);
    } finally {
      aiGenerateBtn.disabled = false;
      aiGenerateBtn.innerHTML = '&#x2726; Generate';
      if (aiLoading) aiLoading.style.display = 'none';
    }
  }

  if (aiGenerateBtn) aiGenerateBtn.addEventListener('click', generateEmail);
  if (aiRegenerateBtn) aiRegenerateBtn.addEventListener('click', generateEmail);

  if (aiInsertBtn) {
    aiInsertBtn.addEventListener('click', function() {
      var text = aiResult ? aiResult.textContent : '';
      if (!text) return;
      var editor = document.getElementById('comp-body');
      if (editor) {
        editor.innerHTML = text.replace(/\n\n/g, '</p><p>').replace(/\n/g, '<br>');
        if (typeof updateLivePreview === 'function') updateLivePreview();
      }
      aiPanel.classList.remove('open');
      showToast('\u2726 AI email inserted into body!');
    });
  }
}

setupAIToolbar();

function setupSubjectAI() {
  var subjectAiBtn = document.getElementById('btn-subject-ai');
  var subjectAiPanel = document.getElementById('ai-subject-panel');
  var templateSelect = document.getElementById('ai-subject-template');
  var promptContainer = document.getElementById('ai-subject-prompt-container');
  var promptInput = document.getElementById('ai-subject-prompt');
  var generateBtn = document.getElementById('btn-ai-subject-generate');
  var loadingEl = document.getElementById('ai-subject-loading');
  var subjectInput = document.getElementById('comp-subject');

  if (!subjectAiBtn || !subjectAiPanel) return;

  // Toggle prompt visibility
  if (templateSelect && promptContainer) {
    templateSelect.addEventListener('change', function() {
      promptContainer.style.display = this.value === 'custom' ? 'block' : 'none';
    });
  }

  // Toggle panel
  subjectAiBtn.addEventListener('click', function(e) {
    e.preventDefault();
    e.stopPropagation();
    subjectAiPanel.style.display = subjectAiPanel.style.display === 'none' ? 'block' : 'none';
  });

  // Close when clicking outside
  document.addEventListener('click', function(e) {
    if (subjectAiPanel.style.display === 'block' && !subjectAiPanel.contains(e.target) && e.target !== subjectAiBtn) {
      subjectAiPanel.style.display = 'none';
    }
  });

  // Generate button click
  if (generateBtn) {
    generateBtn.addEventListener('click', async function(e) {
      e.preventDefault();
      e.stopPropagation();

      var mode = templateSelect ? templateSelect.value : 'context';
      var finalPrompt = '';
      
      if (mode === 'context') {
        var mainEditor = document.getElementById('comp-body');
        var mainBody = mainEditor ? mainEditor.innerText.trim() : '';
        if (!mainBody) {
          showToast('The email body is currently empty. Please write or generate it first.', true);
          return;
        }
        finalPrompt = 'Write a highly effective, engaging, professional subject line based on the email body content provided. Output ONLY the subject line itself. No "Subject:" prefix, no quotation marks, no emojis, and no extra explanation. Email body:\n\n' + mainBody;
      } else if (mode === 'spellcheck') {
        var currentSubject = subjectInput ? subjectInput.value.trim() : '';
        if (!currentSubject) {
          showToast('Please write a subject line first to spell check & improve flow.', true);
          return;
        }
        finalPrompt = 'Spell check and improve the flow of this email subject line: "' + currentSubject + '". Output ONLY the improved subject line. No "Subject:" prefix, no quotation marks, no emojis, and no extra explanation.';
      } else {
        var customPromptText = promptInput ? promptInput.value.trim() : '';
        if (!customPromptText) {
          showToast('Please enter custom prompt instructions for the subject.', true);
          return;
        }
        finalPrompt = 'Write a highly effective, engaging, professional email subject line applying these instructions: ' + customPromptText + '. Output ONLY the subject line itself. No "Subject:" prefix, no quotation marks, no emojis, and no extra explanation.';
      }

      if (loadingEl) loadingEl.style.display = 'inline';
      generateBtn.disabled = true;
      var originalBtnText = generateBtn.innerHTML;
      generateBtn.innerHTML = '&#x23F3;';

      try {
        var resp = await fetch(API_URL + '/api/ai/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: 'Write a cold email subject line. Output ONLY the subject line itself, no labels, no quotes, no emojis, no extra explanation. Instruction: ' + finalPrompt,
            history: []
          })
        });
        if (!resp.ok) {
          var errObj2 = await resp.json().catch(function() { return {}; });
          throw new Error((errObj2.error && errObj2.error.message) || ('HTTP ' + resp.status + ' ' + resp.statusText));
        }

        var data = await resp.json();
        var rawText = data.reply.trim();
        
        // Clean any quotes or "Subject:" prefix if model returned them anyway
        var cleanText = rawText.replace(/^(Subject|subject):\s*/i, '').replace(/^["']|["']$/g, '').replace(/^(Re|re):\s*/i, '').trim();

        if (subjectInput) {
          subjectInput.value = cleanText;
          // Trigger change/input events
          subjectInput.dispatchEvent(new Event('input'));
          subjectInput.dispatchEvent(new Event('change'));
        }
        
        if (typeof updateLivePreview === 'function') updateLivePreview();

        subjectAiPanel.style.display = 'none';
        showToast('AI subject line generated and inserted!');
      } catch (err) {
        showToast('AI error: ' + err.message, true);
      } finally {
        if (loadingEl) loadingEl.style.display = 'none';
        generateBtn.disabled = false;
        generateBtn.innerHTML = originalBtnText;
      }
    });
  }
}

setupSubjectAI();

function setupDashboardAuth() {
  var overlay = document.getElementById('auth-overlay');
  
  // Views
  var mainView = document.getElementById('auth-main-view');
  var forgotView = document.getElementById('auth-forgot-view');
  var resetView = document.getElementById('auth-reset-view');

  // Login/Signup Elements
  var authForm = document.getElementById('db-auth-form');
  var usernameInput = document.getElementById('db-auth-username');
  var emailGroup = document.getElementById('db-auth-email-group');
  var emailInput = document.getElementById('db-auth-email');
  var passwordInput = document.getElementById('db-auth-password');
  var authSubmitBtn = document.getElementById('btn-db-auth-submit');
  var authErrorDiv = document.getElementById('db-auth-error');
  var toggleBtn = document.getElementById('btn-db-auth-toggle');
  var toggleMsg = document.getElementById('db-auth-toggle-msg');
  var subtitle = document.getElementById('db-auth-title');
  var forgotLink = document.getElementById('btn-forgot-password-link');
  var forgotLinkWrap = document.getElementById('db-forgot-password-link-wrap');

  // Forgot Password Elements
  var forgotForm = document.getElementById('db-forgot-form');
  var forgotUsernameInput = document.getElementById('db-forgot-username');
  var forgotSubmitBtn = document.getElementById('btn-db-forgot-submit');
  var forgotErrorDiv = document.getElementById('db-forgot-error');
  var forgotBackBtn = document.getElementById('btn-db-forgot-back');

  // Reset Password Elements
  var resetForm = document.getElementById('db-reset-form');
  var resetOtpInput = document.getElementById('db-reset-otp');
  var resetNewPasswordInput = document.getElementById('db-reset-new-password');
  var resetSubmitBtn = document.getElementById('btn-db-reset-submit');
  var resetErrorDiv = document.getElementById('db-reset-error');
  var resetResendBtn = document.getElementById('btn-db-reset-resend');
  var resetCancelBtn = document.getElementById('btn-db-reset-cancel');
  var resetEmailMasked = document.getElementById('db-reset-email-masked');

  if (!authForm) return;

  var dbAuthMode = 'signup'; // 'signup' | 'login'
  var forgotPasswordUsername = ''; // Cache the username for reset state

  function updateDbAuthUI() {
    var usernameText = document.getElementById('db-lbl-username-text');
    var usernameRequired = document.getElementById('db-lbl-username-required');
    var usernameHelp = document.getElementById('db-lbl-username-help');
    var passwordRequired = document.getElementById('db-lbl-password-required');
    var passwordHelp = document.getElementById('db-lbl-password-help');
    var emailRequired = document.getElementById('db-lbl-email-required');

    if (dbAuthMode === 'signup') {
      subtitle.textContent = 'Create your account';
      authSubmitBtn.textContent = 'Sign Up';
      toggleMsg.textContent = 'Already have an account?';
      toggleBtn.textContent = 'Log in';
      emailGroup.style.display = 'block';
      emailInput.required = true;
      if (forgotLinkWrap) forgotLinkWrap.style.display = 'none';

      if (usernameText) usernameText.textContent = 'Username';
      if (usernameRequired) usernameRequired.style.display = '';
      if (usernameHelp) usernameHelp.style.display = '';
      if (passwordRequired) passwordRequired.style.display = '';
      if (passwordHelp) passwordHelp.style.display = '';
      if (emailRequired) emailRequired.style.display = '';
      usernameInput.placeholder = 'e.g. johndoe';
    } else {
      subtitle.textContent = 'Log in to your account';
      authSubmitBtn.textContent = 'Log In';
      toggleMsg.textContent = "Don't have an account?";
      toggleBtn.textContent = 'Sign up';
      emailGroup.style.display = 'none';
      emailInput.required = false;
      if (forgotLinkWrap) forgotLinkWrap.style.display = 'flex';

      if (usernameText) usernameText.textContent = 'Username or Email';
      if (usernameRequired) usernameRequired.style.display = '';
      if (usernameHelp) usernameHelp.style.display = 'none';
      if (passwordRequired) passwordRequired.style.display = '';
      if (passwordHelp) passwordHelp.style.display = 'none';
      if (emailRequired) emailRequired.style.display = 'none';
      usernameInput.placeholder = 'username or name@company.com';
    }
  }

  // Set default view on load (check if forgot password view is requested)
  var urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('view') === 'forgot') {
    dbAuthMode = 'login';
    updateDbAuthUI();
    if (mainView) mainView.style.display = 'none';
    if (forgotView) forgotView.style.display = 'block';
    if (resetView) resetView.style.display = 'none';
    if (forgotUsernameInput) {
      setTimeout(function() {
        forgotUsernameInput.focus();
      }, 100);
    }
  } else {
    updateDbAuthUI();
  }

  // Password Visibility Toggle
  function setupPasswordToggle(inputEl, btnEl) {
    if (!inputEl || !btnEl) return;
    btnEl.addEventListener('click', function(e) {
      e.preventDefault();
      var isPass = inputEl.type === 'password';
      inputEl.type = isPass ? 'text' : 'password';
      var icon = btnEl.querySelector('.mi');
      if (icon) {
        icon.textContent = isPass ? 'visibility_off' : 'visibility';
      }
    });
  }

  setupPasswordToggle(passwordInput, document.getElementById('btn-toggle-password-auth'));
  setupPasswordToggle(resetNewPasswordInput, document.getElementById('btn-toggle-password-reset'));

  // Toggle Login/Signup
  toggleBtn.addEventListener('click', function(e) {
    e.preventDefault();
    dbAuthMode = (dbAuthMode === 'login') ? 'signup' : 'login';
    updateDbAuthUI();
    if (authErrorDiv) authErrorDiv.style.display = 'none';
  });

  // Main Form Submit (Login / Sign Up)
  authForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    var username = usernameInput.value.trim();
    var password = passwordInput.value;
    var email = emailInput.value.trim();

    if (!username || !password || (dbAuthMode === 'signup' && !email)) {
      if (authErrorDiv) {
        authErrorDiv.textContent = 'All fields are required';
        authErrorDiv.style.display = 'block';
      }
      return;
    }

    if (authErrorDiv) authErrorDiv.style.display = 'none';
    authSubmitBtn.disabled = true;
    authSubmitBtn.textContent = 'Please wait...';

    var endpoint = dbAuthMode === 'login' ? '/auth/login' : '/auth/signup';
    var payload = dbAuthMode === 'login' ? { username, password } : { username, email, password };

    try {
      var r = await fetch(API_URL + endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      var d = await r.json();
      if (!r.ok) {
        throw new Error(d.error || 'Authentication failed');
      }

      // Save session
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        await new Promise(function(resolve) {
          chrome.storage.local.set({ session: d }, resolve);
        });
      }
      // Token persists only in chrome.storage.local (source of truth); no localStorage copy.

      showToast(dbAuthMode === 'login' ? 'Logged in successfully!' : 'Account registered successfully!');
      
      // Clear inputs
      usernameInput.value = '';
      emailInput.value = '';
      passwordInput.value = '';

      // Clear URL parameter so we don't think we are in auth view anymore
      if (window.history && window.history.pushState) {
        var cleanUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
        window.history.pushState({ path: cleanUrl }, '', cleanUrl);
      }

      // Initialize the dashboard!
      await initDashboard();

    } catch (err) {
      if (authErrorDiv) {
        authErrorDiv.textContent = err.message;
        authErrorDiv.style.display = 'block';
      }
    } finally {
      authSubmitBtn.disabled = false;
      authSubmitBtn.textContent = dbAuthMode === 'login' ? 'Log In' : 'Sign Up';
    }
  });

  // Forgot Password link click
  if (forgotLink) {
    forgotLink.addEventListener('click', function(e) {
      e.preventDefault();
      mainView.style.display = 'none';
      forgotView.style.display = 'block';
      if (forgotErrorDiv) forgotErrorDiv.style.display = 'none';
      if (forgotUsernameInput) {
        forgotUsernameInput.value = '';
        forgotUsernameInput.focus();
      }
      // Update URL to ?view=forgot
      if (window.history && window.history.pushState) {
        var newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname + "?view=forgot";
        window.history.pushState({ path: newUrl }, '', newUrl);
      }
    });
  }

  // Back from Forgot Password to Login
  if (forgotBackBtn) {
    forgotBackBtn.addEventListener('click', function(e) {
      e.preventDefault();
      forgotView.style.display = 'none';
      mainView.style.display = 'block';
      if (authErrorDiv) authErrorDiv.style.display = 'none';
      // Clear URL parameter
      if (window.history && window.history.pushState) {
        var cleanUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
        window.history.pushState({ path: cleanUrl }, '', cleanUrl);
      }
    });
  }

  // Cancel from Reset Password to Login
  if (resetCancelBtn) {
    resetCancelBtn.addEventListener('click', function(e) {
      e.preventDefault();
      resetView.style.display = 'none';
      mainView.style.display = 'block';
      if (authErrorDiv) authErrorDiv.style.display = 'none';
      // Clear URL parameter
      if (window.history && window.history.pushState) {
        var cleanUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
        window.history.pushState({ path: cleanUrl }, '', cleanUrl);
      }
    });
  }

  // Submit Forgot Password Request (Sends OTP)
  if (forgotForm) {
    forgotForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      var usernameVal = forgotUsernameInput.value.trim();
      if (!usernameVal) return;

      if (forgotErrorDiv) forgotErrorDiv.style.display = 'none';
      forgotSubmitBtn.disabled = true;
      forgotSubmitBtn.textContent = 'Sending code...';

      try {
        var r = await fetch(API_URL + '/auth/forgot-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: usernameVal })
        });
        var d = await r.json();
        if (!r.ok) {
          throw new Error(d.error || 'Failed to request password reset');
        }

        // Cache username and show next step
        forgotPasswordUsername = usernameVal;
        if (resetEmailMasked) resetEmailMasked.textContent = d.email || 'your email';
        forgotView.style.display = 'none';
        resetView.style.display = 'block';
        if (resetErrorDiv) resetErrorDiv.style.display = 'none';
        if (resetOtpInput) {
          resetOtpInput.value = '';
          resetOtpInput.focus();
        }
        if (resetNewPasswordInput) resetNewPasswordInput.value = '';

        showToast('Verification code sent to registered recovery email.');
      } catch (err) {
        if (forgotErrorDiv) {
          forgotErrorDiv.textContent = err.message;
          forgotErrorDiv.style.display = 'block';
        }
      } finally {
        forgotSubmitBtn.disabled = false;
        forgotSubmitBtn.textContent = 'Send Verification Code';
      }
    });
  }

  // Submit Reset Password (Verifies OTP & updates password)
  if (resetForm) {
    resetForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      var otpVal = resetOtpInput.value.trim();
      var newPasswordVal = resetNewPasswordInput.value;

      if (!otpVal || !newPasswordVal) return;

      if (resetErrorDiv) resetErrorDiv.style.display = 'none';
      resetSubmitBtn.disabled = true;
      resetSubmitBtn.textContent = 'Resetting password...';

      try {
        var r = await fetch(API_URL + '/auth/reset-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: forgotPasswordUsername,
            otp: otpVal,
            newPassword: newPasswordVal
          })
        });
        var d = await r.json();
        if (!r.ok) {
          throw new Error(d.error || 'Failed to reset password');
        }

        showToast('Password reset successfully! Please log in.');
        resetView.style.display = 'none';
        mainView.style.display = 'block';
        if (authErrorDiv) authErrorDiv.style.display = 'none';
        if (usernameInput) usernameInput.value = forgotPasswordUsername;
        if (passwordInput) {
          passwordInput.value = '';
          passwordInput.focus();
        }
      } catch (err) {
        if (resetErrorDiv) {
          resetErrorDiv.textContent = err.message;
          resetErrorDiv.style.display = 'block';
        }
      } finally {
        resetSubmitBtn.disabled = false;
        resetSubmitBtn.textContent = 'Reset Password';
      }
    });
  }

  // Resend OTP Code
  if (resetResendBtn) {
    resetResendBtn.addEventListener('click', async function(e) {
      e.preventDefault();
      if (!forgotPasswordUsername) return;

      resetResendBtn.disabled = true;
      resetResendBtn.textContent = 'Sending...';

      try {
        var r = await fetch(API_URL + '/auth/forgot-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: forgotPasswordUsername })
        });
        var d = await r.json();
        if (!r.ok) {
          throw new Error(d.error || 'Failed to resend code');
        }
        showToast('Verification code resent successfully.');
        alert('Verification code has been resent successfully!\n\n(Note: Since SMTP is not configured in your backend .env file, the 6-digit code has been printed directly to your backend server console for testing.)');
      } catch (err) {
        showToast(err.message, true);
      } finally {
        resetResendBtn.disabled = false;
        resetResendBtn.textContent = 'Resend Code';
      }
    });
  }
}

function setupDashboardSignout() {
  var btn = document.getElementById('btn-db-signout');
  if (!btn) return;

  btn.addEventListener('click', async function(e) {
    e.preventDefault();
    e.stopPropagation();

    if (!confirm('Are you sure you want to sign out?')) return;

    try {
      // Call logout endpoint (fire-and-forget)
      await apiCall('POST', '/auth/logout').catch(function() {});
    } catch(err) {}

    // Clear session
    localStorage.removeItem('sndr_session');
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.remove(['session'], function() {
        window.location.reload();
      });
    } else {
      window.location.reload();
    }
  });
}


initDashboard();

