// Feedback in the dashboard: "Write to the SNDR team" (sidebar → Feedback),
// a compose window like an email, and a one-tap reaction after big moments
// (first emails found, first campaign sent, first reply). Notes go to
// POST /feedback with the user's sign-in; the founders read them in the
// analytics page (Feedback tab) and may pin ones the writer allowed on the
// website's wall. See backend/services/feedback.js.
(function () {
  var MOODS = [
    ['love', 'favorite', 'I love this'],
    ['idea', 'lightbulb', 'I have an idea'],
    ['broke', 'bug_report', 'Something broke'],
    ['unhappy', 'sentiment_dissatisfied', 'Not happy'],
  ];
  var PLACEHOLDERS = [
    'Spill the tea. What should SNDR do better?',
    'What made you smile, or want to throw your laptop?',
    'One thing you\'d change about SNDR…',
    'Tell us what happened. The more detail, the faster we fix it.',
  ];
  var FACES = [['love', 'sentiment_very_satisfied', 'Loved it'], ['good', 'sentiment_satisfied', 'Good'],
    ['okay', 'sentiment_neutral', 'Okay'], ['bad', 'sentiment_dissatisfied', 'Bad']];
  var MOMENTS = {
    emails_found: 'Emails found. How did SNDR do?',
    campaign_sent: 'Campaign on its way. How was setting it up?',
    reply: 'You got a reply. How did SNDR do?',
  };
  // A face's note subject, when they choose to say more.
  var FACE_TO_MOOD = { love: 'love', good: 'love', okay: 'idea', bad: 'unhappy' };
  var REACTION_GAP_MS = 7 * 24 * 3600 * 1000; // at most one reaction ask a week

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function version() { try { return chrome.runtime.getManifest().version; } catch (e) { return ''; } }
  function screen() { var a = document.querySelector('.ni.active[data-nav]'); return a ? a.getAttribute('data-nav') : ''; }
  function firstName() { var n = (document.getElementById('u-name') || {}).textContent || ''; n = n.trim(); return /loading/i.test(n) ? '' : n.split(/\s+/)[0]; }
  function send(body) {
    body.version = version(); body.screen = screen();
    if (typeof apiCall === 'function') return apiCall('POST', '/feedback', body, false, 20000);
    return Promise.reject(new Error('Not ready'));
  }

  // ── The compose window ──────────────────────────────────────────────────
  function openCompose(mood) {
    closeReaction();
    var old = document.getElementById('fbk-bg');
    if (old) old.remove();
    var bg = document.createElement('div');
    bg.id = 'fbk-bg';
    bg.className = 'fc-confirm-bg fbk-bg';
    var name = firstName();
    bg.innerHTML =
      '<form class="fbk-card" role="dialog" aria-modal="true" aria-labelledby="fbk-title" novalidate>' +
        '<div class="fbk-top"><span id="fbk-title"><span class="mi" aria-hidden="true">edit_note</span>New message</span>' +
          '<button type="button" class="fbk-x" aria-label="Close"><span class="mi" aria-hidden="true">close</span></button></div>' +
        '<div class="fbk-row"><span class="fbk-k">To</span>The SNDR team</div>' +
        '<div class="fbk-row fbk-subject"><span class="fbk-k">Subject</span><div class="fbk-chips" role="radiogroup" aria-label="What it\'s about">' +
          MOODS.map(function (m) {
            return '<button type="button" class="fbk-chip" role="radio" aria-checked="false" data-mood="' + m[0] + '"><span class="mi" aria-hidden="true">' + m[1] + '</span>' + esc(m[2]) + '</button>';
          }).join('') + '</div></div>' +
        '<textarea class="fbk-body" rows="5" maxlength="2000" aria-label="Your message" placeholder="' + esc(PLACEHOLDERS[Math.floor(Math.random() * PLACEHOLDERS.length)]) + '"></textarea>' +
        '<label class="fbk-pin"><input type="checkbox" class="fbk-pin-ok"> OK to show this on sndr.co.in as ' +
          '<input type="text" class="fbk-name" maxlength="40" value="' + esc(name) + '" placeholder="your first name" aria-label="Name shown with your note"></label>' +
        '<div class="fbk-err" role="alert"></div>' +
        '<div class="fbk-foot"><span class="fbk-hint">Your SNDR version and screen are attached, so we can fix bugs faster.</span>' +
          '<button type="submit" class="fbk-send"><span class="mi fbk-plane" aria-hidden="true">send</span><span class="fbk-send-t">Send</span></button></div>' +
      '</form>';
    document.body.appendChild(bg);
    var card = bg.querySelector('.fbk-card'), body = bg.querySelector('.fbk-body'), err = bg.querySelector('.fbk-err');
    var picked = null;
    function pick(m) {
      picked = m;
      Array.prototype.forEach.call(bg.querySelectorAll('.fbk-chip'), function (c) { c.setAttribute('aria-checked', String(c.getAttribute('data-mood') === m)); });
      err.textContent = '';
    }
    if (mood) pick(mood);
    function close() { bg.remove(); document.removeEventListener('keydown', onKey, true); }
    function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }
    document.addEventListener('keydown', onKey, true);
    bg.addEventListener('mousedown', function (e) { if (e.target === bg) close(); });
    bg.querySelector('.fbk-x').addEventListener('click', close);
    bg.querySelector('.fbk-chips').addEventListener('click', function (e) { var c = e.target.closest('.fbk-chip'); if (c) pick(c.getAttribute('data-mood')); });
    body.addEventListener('input', function () { err.textContent = ''; });
    bg.querySelector('.fbk-name').addEventListener('focus', function () { bg.querySelector('.fbk-pin-ok').checked = true; });
    card.addEventListener('submit', function (e) {
      e.preventDefault();
      var text = body.value.trim();
      if (!picked) { err.textContent = 'Pick a subject first.'; return; }
      if (text.length < 2) { err.textContent = 'Write a line first.'; body.focus(); return; }
      var btn = bg.querySelector('.fbk-send');
      btn.disabled = true;
      btn.querySelector('.fbk-send-t').textContent = 'Sending…';
      var canPin = bg.querySelector('.fbk-pin-ok').checked;
      send({ kind: 'note', mood: picked, message: text, canPin: canPin, wallName: canPin ? bg.querySelector('.fbk-name').value.trim() : '' })
        .then(function () {
          // The paper plane takes off, then the card says it landed.
          card.classList.add('fbk-flying');
          setTimeout(function () {
            card.innerHTML = '<div class="fbk-done"><span class="mi" aria-hidden="true">mark_email_read</span>' +
              '<b>Delivered to the SNDR team</b><span>Thanks for writing. It goes straight to the people building SNDR.</span></div>';
            card.classList.remove('fbk-flying');
            setTimeout(close, 2600);
          }, 650);
          if (typeof window.sndrTrack === 'function') window.sndrTrack('feedback_sent', { mood: picked });
        })
        .catch(function (e2) {
          btn.disabled = false;
          btn.querySelector('.fbk-send-t').textContent = 'Send';
          err.textContent = (e2 && e2.message) || 'Couldn\'t send that. Try again in a minute.';
        });
    });
    (mood ? body : bg.querySelector('.fbk-chip')).focus();
  }
  window.sndrOpenFeedback = openCompose;

  // ── One-tap reactions after big moments ──────────────────────────────────
  // Each moment is asked about once ever, and at most one ask a week; never
  // while the compose window is open. The bar leaves on its own after 15s.
  var reactionTimer = null;
  function closeReaction() {
    clearTimeout(reactionTimer);
    var r = document.getElementById('fbk-react');
    if (r) r.remove();
  }
  function askReaction(moment) {
    if (!MOMENTS[moment] || typeof chrome === 'undefined' || !chrome.storage) return;
    chrome.storage.local.get(['feedbackAsked'], function (d) {
      var asked = d.feedbackAsked || {};
      if (asked[moment] || (asked.last && Date.now() - asked.last < REACTION_GAP_MS)) return;
      if (document.getElementById('fbk-bg') || document.getElementById('fbk-react')) return;
      asked[moment] = asked.last = Date.now();
      chrome.storage.local.set({ feedbackAsked: asked });
      showReaction(moment);
    });
  }
  function showReaction(moment) {
    var bar = document.createElement('div');
    bar.id = 'fbk-react';
    bar.className = 'fbk-react';
    bar.setAttribute('role', 'dialog');
    bar.setAttribute('aria-label', 'Quick feedback');
    bar.innerHTML = '<span class="fbk-react-q">' + esc(MOMENTS[moment]) + '</span><span class="fbk-faces">' +
      FACES.map(function (f) { return '<button type="button" class="fbk-face" data-face="' + f[0] + '" title="' + esc(f[2]) + '" aria-label="' + esc(f[2]) + '"><span class="mi" aria-hidden="true">' + f[1] + '</span></button>'; }).join('') +
      '</span><button type="button" class="fbk-react-x" aria-label="Not now"><span class="mi" aria-hidden="true">close</span></button>';
    document.body.appendChild(bar);
    reactionTimer = setTimeout(closeReaction, 15000);
    bar.querySelector('.fbk-react-x').addEventListener('click', closeReaction);
    bar.querySelector('.fbk-faces').addEventListener('click', function (e) {
      var b = e.target.closest('.fbk-face');
      if (!b) return;
      var face = b.getAttribute('data-face');
      clearTimeout(reactionTimer);
      send({ kind: 'reaction', moment: moment, mood: face }).catch(function () {});
      bar.innerHTML = '<span class="fbk-react-q">Thanks. Want to tell us more?</span>' +
        '<button type="button" class="fbk-more">Write a note</button><button type="button" class="fbk-react-x" aria-label="Close"><span class="mi" aria-hidden="true">close</span></button>';
      bar.querySelector('.fbk-more').addEventListener('click', function () { openCompose(FACE_TO_MOOD[face]); });
      bar.querySelector('.fbk-react-x').addEventListener('click', closeReaction);
      reactionTimer = setTimeout(closeReaction, 8000);
    });
  }
  window.sndrAskReaction = askReaction;

  var nav = document.getElementById('nav-feedback');
  if (nav) nav.addEventListener('click', function () { openCompose(null); });
})();
