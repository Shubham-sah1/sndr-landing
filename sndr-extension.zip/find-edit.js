// Fixing names and company names on Find Emails before they go into a
// campaign. LinkedIn names come as "Kunal Joshi CA", "Meera Iyer | HR" or in
// full when the user wants a short form, and the first word of the name is
// what {first_name} becomes ("Hi CA,"). Two ways to fix them:
//  • click a name or company on a card and type the right one;
//  • tell SNDR AI how they should look ("first names only", "call the
//    company IIFL Capital"); it suggests changes for everyone, shown before
//    anything changes, and Apply can be undone.
// Edits are saved on the contact (editName / editCompany) and used on the
// cards, in Download CSV and in Create Campaign. The address never changes:
// the finder keeps building it from the LinkedIn name.
(function () {
  var BATCH = 100; // the server takes up to 100 contacts per call
  var lastUndo = null; // [{ key, editName, editCompany }] from the last Apply
  var pending = null;  // suggested changes waiting for Apply / Discard

  function esc(s) { return typeof escHtml === 'function' ? escHtml(s) : String(s == null ? '' : s).replace(/[&<>"']/g, function (ch) { return '&#' + ch.charCodeAt(0) + ';'; }); }
  function keyOf(c) { return typeof window._findContactKey === 'function' ? window._findContactKey(c) : (c.id || c.profileUrl || c.name); }
  function shownName(c) { return c.editName || c.name || ''; }
  function shownCompany(c) { return c.editCompany || c.company || c.headline || ''; }
  // Contacts on screen that have an address (the ones that get exported).
  function withEmail() {
    return (window._findContacts || []).filter(function (c) {
      var r = window._emailResults && window._emailResults[c.id || c.profileUrl || ''];
      return r && r.email;
    });
  }

  // Store edits on the contacts (memory and saved list). An edit equal to
  // the LinkedIn value, or blank, goes back to the LinkedIn value.
  function setEdits(edits) {
    var byKey = {};
    edits.forEach(function (e) {
      var c = e.contact;
      ['editName', 'editCompany'].forEach(function (f) {
        if (!(f in e)) return;
        var orig = f === 'editName' ? (c.name || '') : (c.company || c.headline || '');
        var v = String(e[f] == null ? '' : e[f]).replace(/\s+/g, ' ').trim();
        if (!v || v === orig) delete c[f]; else c[f] = v;
      });
      byKey[keyOf(c)] = { editName: c.editName, editCompany: c.editCompany };
    });
    if (typeof window._findUpdateSaved !== 'function') return;
    window._findUpdateSaved(function (list) {
      var changed = false;
      list.forEach(function (c) {
        var e = c && byKey[keyOf(c)];
        if (!e) return;
        ['editName', 'editCompany'].forEach(function (f) {
          if (e[f]) { if (c[f] !== e[f]) { c[f] = e[f]; changed = true; } }
          else if (f in c) { delete c[f]; changed = true; }
        });
      });
      return changed;
    });
  }

  function redraw() {
    if (typeof window.renderFindScreen === 'function') window.renderFindScreen();
  }

  // ── Click a name or company to edit it ────────────────────────────────────
  function startEdit(el) {
    if (el.querySelector('input')) return;
    var card = el.closest('.fc');
    var id = card && card.getAttribute('data-cid');
    var c = (window._findContacts || []).find(function (x) { return (x.id || x.profileUrl || '') === id; });
    if (!c) return;
    var field = el.getAttribute('data-edit');
    var before = field === 'name' ? shownName(c) : shownCompany(c);
    var input = document.createElement('input');
    input.className = 'fc-edit-input';
    input.value = before;
    input.maxLength = 120;
    input.setAttribute('aria-label', field === 'name' ? 'Name used in emails' : 'Company name used in emails');
    el.textContent = '';
    el.appendChild(input);
    input.focus();
    input.select();
    var done = false;
    // refocus: only when finished from the keyboard, not by clicking elsewhere.
    function finish(save, refocus) {
      if (done) return;
      done = true;
      var v = input.value.replace(/\s+/g, ' ').trim();
      if (save && v !== before) {
        var e = { contact: c };
        e[field === 'name' ? 'editName' : 'editCompany'] = v;
        setEdits([e]);
      }
      el.textContent = (field === 'name' ? shownName(c) : shownCompany(c)) || (field === 'name' ? 'Unknown' : '—');
      if (field === 'name') {
        var av = card.querySelector('.fc-av');
        if (av) av.textContent = shownName(c).split(' ').map(function (w) { return w[0] || ''; }).slice(0, 2).join('').toUpperCase();
      }
      if (refocus) el.focus();
    }
    // stopPropagation: the Enter that saves must not reach the "Enter starts
    // editing" shortcut below, which reopened the box straight away.
    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter') { ev.preventDefault(); ev.stopPropagation(); finish(true, true); }
      else if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); finish(false, true); }
    });
    input.addEventListener('blur', function () { finish(true, false); });
  }

  document.addEventListener('click', function (ev) {
    var el = ev.target.closest && ev.target.closest('#find-grid [data-edit]');
    if (el && !ev.target.closest('input')) startEdit(el);
  });
  document.addEventListener('keydown', function (ev) {
    if (ev.key !== 'Enter' && ev.key !== 'F2') return;
    var el = ev.target;
    if (el && el.matches && el.matches('#find-grid [data-edit]')) { ev.preventDefault(); startEdit(el); }
  });

  // ── Fix with AI ───────────────────────────────────────────────────────────
  function $(id) { return document.getElementById(id); }
  function setResult(html) { var r = $('fi-fix-result'); if (r) r.innerHTML = html; }
  function busy(on, text) {
    var go = $('fi-fix-go'), input = $('fi-fix-input');
    if (go) { go.disabled = on; go.innerHTML = '<span class="mi" style="font-size:15px">auto_awesome</span>' + (on ? esc(text || 'Fixing…') : 'Fix with AI'); }
    if (input) input.disabled = on;
    document.querySelectorAll('.fi-fix-chip').forEach(function (b) { b.disabled = on; });
  }

  async function runFix(instruction) {
    instruction = String(instruction || '').trim();
    if (!instruction) { var i0 = $('fi-fix-input'); if (i0) i0.focus(); return; }
    var people = withEmail();
    if (!people.length) return;
    pending = null;
    setResult('');
    var changes = [];
    try {
      for (var start = 0; start < people.length; start += BATCH) {
        var part = people.slice(start, start + BATCH);
        busy(true, people.length > BATCH ? 'Fixing ' + Math.min(start + BATCH, people.length) + ' of ' + people.length + '…' : 'Fixing…');
        var res = await apiCall('POST', '/api/ai/fix-contacts', {
          instruction: instruction,
          contacts: part.map(function (c) { return { name: shownName(c), company: shownCompany(c) }; }),
        }, false, 90000);
        (res && res.changes || []).forEach(function (ch) {
          var c = part[ch.i];
          if (!c) return;
          var e = { contact: c, fromName: shownName(c), fromCompany: shownCompany(c) };
          if (ch.name) e.editName = ch.name;
          if (ch.company) e.editCompany = ch.company;
          changes.push(e);
        });
      }
    } catch (err) {
      busy(false);
      setResult('<div class="fi-fix-err">' + esc(err && err.message ? err.message : 'SNDR AI is unavailable right now. Try again in a minute.') + '</div>');
      return;
    }
    busy(false);
    if (typeof window.sndrTrack === 'function') window.sndrTrack('ai_used', { feature: 'fix_contacts', count: people.length, changed: changes.length });
    if (!changes.length) { setResult('<div class="fi-fix-note">Nothing to change for that.</div>'); return; }
    pending = changes;
    showPreview(changes);
  }

  // Before anything changes: what would change. Identical company renames
  // ("IIFL Capital Services Limited → IIFL Capital") are listed once.
  function showPreview(changes) {
    var lines = [], seen = {};
    changes.forEach(function (e) {
      if (e.editName) lines.push({ from: e.fromName, to: e.editName });
      if (e.editCompany) {
        var k = e.fromCompany + '\u0000' + e.editCompany;
        if (seen[k]) { seen[k].n++; return; }
        seen[k] = { from: e.fromCompany, to: e.editCompany, n: 1 };
        lines.push(seen[k]);
      }
    });
    var count = changes.length;
    var rows = lines.slice(0, 60).map(function (l) {
      return '<li><span class="fi-fix-from">' + esc(l.from || '—') + '</span><span class="mi" aria-hidden="true">arrow_forward</span>' +
        '<span class="fi-fix-to">' + esc(l.to) + '</span>' + (l.n > 1 ? '<span class="fi-fix-n">' + l.n + ' people</span>' : '') + '</li>';
    }).join('');
    setResult(
      '<div class="fi-fix-preview">' +
        '<div class="fi-fix-title">SNDR AI suggests changes for ' + count + ' contact' + (count === 1 ? '' : 's') + '</div>' +
        '<ul class="fi-fix-list">' + rows + (lines.length > 60 ? '<li class="fi-fix-more">and ' + (lines.length - 60) + ' more</li>' : '') + '</ul>' +
        '<div class="fi-fix-actions">' +
          '<button type="button" class="fi-act-btn fi-act-csv" id="fi-fix-discard">Discard</button>' +
          '<button type="button" class="fi-act-btn fi-act-camp" id="fi-fix-apply">Apply ' + count + ' change' + (count === 1 ? '' : 's') + '</button>' +
        '</div>' +
      '</div>');
    $('fi-fix-discard').addEventListener('click', function () { pending = null; setResult(''); });
    $('fi-fix-apply').addEventListener('click', applyPending);
    $('fi-fix-apply').focus();
  }

  function applyPending() {
    if (!pending) return;
    var applied = pending;
    pending = null;
    lastUndo = applied.map(function (e) { return { contact: e.contact, editName: e.contact.editName || '', editCompany: e.contact.editCompany || '' }; });
    setEdits(applied.map(function (e) {
      var x = { contact: e.contact };
      if (e.editName) x.editName = e.editName;
      if (e.editCompany) x.editCompany = e.editCompany;
      return x;
    }));
    redraw();
    setResult('<div class="fi-fix-note">Changed ' + applied.length + ' contact' + (applied.length === 1 ? '' : 's') + '. ' +
      '<button type="button" class="fi-fix-undo" id="fi-fix-undo">Undo</button></div>');
    $('fi-fix-undo').addEventListener('click', function () {
      if (!lastUndo) return;
      setEdits(lastUndo);
      lastUndo = null;
      redraw();
      setResult('<div class="fi-fix-note">Undone.</div>');
    });
  }

  // Shown once there are addresses to fix (called from _updateFindActions).
  window._findEditRefresh = function () {
    var box = $('fi-fix');
    if (box) box.hidden = !withEmail().length;
  };

  function wire() {
    var form = $('fi-fix-form');
    if (!form || form._wired) return;
    form._wired = true;
    form.addEventListener('submit', function (ev) { ev.preventDefault(); runFix($('fi-fix-input').value); });
    document.querySelectorAll('.fi-fix-chip').forEach(function (b) {
      b.addEventListener('click', function () {
        var text = b.getAttribute('data-fix');
        $('fi-fix-input').value = text;
        runFix(text);
      });
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
})();
