// Fixing a name or company name on a Find Emails card: click it, type the
// right one, Enter (Escape cancels). Fixing many at once, with SNDR AI, is in
// the campaign's Map Columns step (map-fix.js).
// Edits are saved on the contact (editName / editCompany) and used on the
// cards, in Download CSV and in Create Campaign. The address never changes:
// the finder keeps building it from the LinkedIn name.
(function () {
  function keyOf(c) { return typeof window._findContactKey === 'function' ? window._findContactKey(c) : (c.id || c.profileUrl || c.name); }
  function shownName(c) { return c.editName || c.name || ''; }
  function shownCompany(c) { return c.editCompany || c.company || c.headline || ''; }
  // Store edits on the contacts (memory and saved list). An edit equal to
  // the LinkedIn value, or blank, goes back to the LinkedIn value.
  function setEdits(edits) {
    var byKey = {};
    edits.forEach(function (e) {
      var c = e.contact;
      ['editName', 'editCompany'].forEach(function (f) {
        if (!(f in e)) return;
        var orig = f === 'editName' ? (c.name || '') : (c.company || c.headline || '');
        var v = String(e[f] == null ? '' : e[f]).replace(/\s+/g, ' ').trim();
        if (!v || v === orig) delete c[f]; else c[f] = v;
      });
      byKey[keyOf(c)] = { editName: c.editName, editCompany: c.editCompany };
    });
    if (typeof window._findUpdateSaved !== 'function') return;
    window._findUpdateSaved(function (list) {
      var changed = false;
      list.forEach(function (c) {
        var e = c && byKey[keyOf(c)];
        if (!e) return;
        ['editName', 'editCompany'].forEach(function (f) {
          if (e[f]) { if (c[f] !== e[f]) { c[f] = e[f]; changed = true; } }
          else if (f in c) { delete c[f]; changed = true; }
        });
      });
      return changed;
    });
  }

  // ── Click a name or company to edit it ────────────────────────────────────
  function startEdit(el) {
    if (el.querySelector('input')) return;
    var card = el.closest('.fc');
    var id = card && card.getAttribute('data-cid');
    var c = (window._findContacts || []).find(function (x) { return (x.id || x.profileUrl || '') === id; });
    if (!c) return;
    var field = el.getAttribute('data-edit');
    var before = field === 'name' ? shownName(c) : shownCompany(c);
    var input = document.createElement('input');
    input.className = 'fc-edit-input';
    input.value = before;
    input.maxLength = 120;
    input.setAttribute('aria-label', field === 'name' ? 'Name used in emails' : 'Company name used in emails');
    el.textContent = '';
    el.appendChild(input);
    input.focus();
    input.select();
    var done = false;
    // refocus: only when finished from the keyboard, not by clicking elsewhere.
    function finish(save, refocus) {
      if (done) return;
      done = true;
      var v = input.value.replace(/\s+/g, ' ').trim();
      if (save && v !== before) {
        var e = { contact: c };
        e[field === 'name' ? 'editName' : 'editCompany'] = v;
        setEdits([e]);
      }
      el.textContent = (field === 'name' ? shownName(c) : shownCompany(c)) || (field === 'name' ? 'Unknown' : '—');
      if (field === 'name') {
        var av = card.querySelector('.fc-av');
        if (av) av.textContent = shownName(c).split(' ').map(function (w) { return w[0] || ''; }).slice(0, 2).join('').toUpperCase();
      }
      if (refocus) el.focus();
    }
    // stopPropagation: the Enter that saves must not reach the "Enter starts
    // editing" shortcut below, which reopened the box straight away.
    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter') { ev.preventDefault(); ev.stopPropagation(); finish(true, true); }
      else if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); finish(false, true); }
    });
    input.addEventListener('blur', function () { finish(true, false); });
  }

  document.addEventListener('click', function (ev) {
    var el = ev.target.closest && ev.target.closest('#find-grid [data-edit]');
    if (el && !ev.target.closest('input')) startEdit(el);
  });
  document.addEventListener('keydown', function (ev) {
    if (ev.key !== 'Enter' && ev.key !== 'F2') return;
    var el = ev.target;
    if (el && el.matches && el.matches('#find-grid [data-edit]')) { ev.preventDefault(); startEdit(el); }
  });

})();
