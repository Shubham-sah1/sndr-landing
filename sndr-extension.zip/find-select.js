// Selecting several people on Find Emails to remove them at once (removing
// one by one with the red × takes too long on a long list). "Select" turns on
// a checkbox on each card; click cards (Shift-click for a run) or Select all,
// then Remove selected: one confirmation, one save (finder-card.js
// _removeContacts). Esc or Cancel leaves without changing anything.
(function () {
  var grid = document.getElementById('find-grid');
  var btn = document.getElementById('btn-select-contacts');
  var bar = document.getElementById('find-select-bar');
  if (!grid || !btn || !bar) return;
  var countEl = document.getElementById('find-select-count');
  var allBtn = document.getElementById('find-select-all');
  var removeBtn = document.getElementById('find-select-remove');
  var cancelBtn = document.getElementById('find-select-cancel');
  var on = false, selected = {}, lastIdx = -1;

  function cards() { return Array.prototype.slice.call(grid.querySelectorAll('.fc[data-cid]')); }
  function n() { return Object.keys(selected).length; }

  // Each card gets a checkbox while selecting (cards are redrawn as emails
  // arrive, so this runs again after every redraw).
  function decorate() {
    cards().forEach(function (card) {
      var id = card.getAttribute('data-cid');
      var box = card.querySelector('.fc-check');
      if (on && !box) {
        box = document.createElement('span');
        box.className = 'fc-check';
        box.setAttribute('aria-hidden', 'true');
        box.innerHTML = '<span class="mi">check</span>';
        card.insertBefore(box, card.firstChild);
      } else if (!on && box) box.remove();
      card.classList.toggle('fc-selectable', on);
      card.classList.toggle('fc-sel', on && !!selected[id]);
      if (on) {
        card.setAttribute('role', 'checkbox');
        card.setAttribute('tabindex', '0');
        card.setAttribute('aria-checked', String(!!selected[id]));
      } else {
        card.removeAttribute('role'); card.removeAttribute('tabindex'); card.removeAttribute('aria-checked');
      }
    });
  }
  function refresh() {
    // Forget anyone no longer on the screen.
    var present = {};
    cards().forEach(function (c) { present[c.getAttribute('data-cid')] = true; });
    Object.keys(selected).forEach(function (id) { if (!present[id]) delete selected[id]; });
    var total = cards().length, k = n();
    countEl.textContent = k ? k + ' of ' + total + ' selected' : 'Click people to select them';
    allBtn.textContent = k && k === total ? 'Select none' : 'Select all';
    removeBtn.disabled = !k;
    removeBtn.innerHTML = '<span class="mi">delete</span>' + (k ? 'Remove ' + k : 'Remove selected');
    decorate();
  }
  function setOn(v) {
    on = v; selected = {}; lastIdx = -1;
    bar.hidden = !on;
    btn.setAttribute('aria-pressed', String(on));
    btn.classList.toggle('on', on);
    grid.classList.toggle('find-selecting', on);
    refresh();
    if (on && cards()[0]) cards()[0].focus();
  }
  function toggle(card, range) {
    var list = cards(), idx = list.indexOf(card), id = card.getAttribute('data-cid');
    if (range && lastIdx >= 0 && lastIdx < list.length) {
      var want = !selected[id];
      var a = Math.min(lastIdx, idx), b = Math.max(lastIdx, idx);
      for (var i = a; i <= b; i++) { var cid = list[i].getAttribute('data-cid'); if (want) selected[cid] = true; else delete selected[cid]; }
    } else if (selected[id]) delete selected[id];
    else selected[id] = true;
    lastIdx = idx;
    refresh();
  }

  btn.addEventListener('click', function () { setOn(!on); });
  cancelBtn.addEventListener('click', function () { setOn(false); btn.focus(); });
  allBtn.addEventListener('click', function () {
    var all = cards(), every = n() === all.length && all.length > 0;
    selected = {};
    if (!every) all.forEach(function (c) { selected[c.getAttribute('data-cid')] = true; });
    refresh();
  });
  // While selecting, a click anywhere on a card selects it: the card's own
  // buttons and the name/company editor (find-edit.js) stay out of the way.
  grid.addEventListener('click', function (e) {
    if (!on) return;
    var card = e.target.closest && e.target.closest('.fc[data-cid]');
    if (!card) return;
    e.preventDefault(); e.stopPropagation();
    toggle(card, e.shiftKey);
  }, true);
  grid.addEventListener('keydown', function (e) {
    if (!on) return;
    var card = e.target.closest && e.target.closest('.fc[data-cid]');
    if (card && (e.key === ' ' || e.key === 'Enter')) { e.preventDefault(); e.stopPropagation(); toggle(card, e.shiftKey); }
  }, true);
  document.addEventListener('keydown', function (e) {
    if (on && e.key === 'Escape' && !document.getElementById('fc-confirm-bg')) { setOn(false); btn.focus(); }
  });

  removeBtn.addEventListener('click', function () {
    var ids = Object.keys(selected);
    if (!ids.length) return;
    var old = document.getElementById('fc-confirm-bg');
    if (old) old.remove();
    var back = document.createElement('div');
    back.id = 'fc-confirm-bg';
    back.className = 'fc-confirm-bg';
    var who = ids.length === 1 ? 'this person' : ids.length + ' people';
    back.innerHTML =
      '<div class="fc-confirm" role="dialog" aria-modal="true" aria-labelledby="fc-confirm-title">' +
        '<h3 id="fc-confirm-title">Remove ' + who + '?</h3>' +
        '<p>They won\'t be in your list, downloads or campaigns.</p>' +
        '<div class="fc-confirm-actions">' +
          '<button type="button" id="fc-confirm-cancel">Cancel</button>' +
          '<button type="button" class="fc-confirm-remove" id="fc-confirm-ok">Remove ' + (ids.length === 1 ? '' : ids.length) + '</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(back);
    function close() { document.removeEventListener('keydown', onKey, true); back.remove(); removeBtn.focus(); }
    function confirm() {
      document.removeEventListener('keydown', onKey, true);
      back.remove();
      if (typeof window._findRemoveContacts === 'function') window._findRemoveContacts(ids);
      setOn(false);
      if (typeof window.showToast === 'function') window.showToast('Removed ' + who + '.');
    }
    function onKey(e) {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
      else if (e.key === 'Enter' && e.target && e.target.id !== 'fc-confirm-cancel') { e.preventDefault(); confirm(); }
    }
    document.addEventListener('keydown', onKey, true);
    back.addEventListener('click', function (e) { if (e.target === back) close(); });
    document.getElementById('fc-confirm-cancel').addEventListener('click', close);
    document.getElementById('fc-confirm-ok').addEventListener('click', confirm);
    document.getElementById('fc-confirm-ok').focus();
  });

  // Cards come and go (emails arriving, removals, a new search): keep the
  // checkboxes and the count right, and hide Select when there's no one.
  new MutationObserver(function () {
    var has = cards().length > 0;
    btn.hidden = !has;
    if (!has && on) setOn(false);
    else if (on) refresh();
  }).observe(grid, { childList: true });
  btn.hidden = cards().length === 0;
})();
