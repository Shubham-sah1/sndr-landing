// ── SNDR Finder Card ─────────────────────────────────────────────────────────
// Handles: plain-text company input (no autocomplete dropdown — removed on
// purpose, see sndrOpenLinkedIn below), backend email-pattern lookup (100%
// free — SQLite cache / email-format.com / SMTP probe / Bedrock / site-
// scrape+search, no paid provider), LinkedIn redirect, and bulk email
// generation for all extracted contacts.
// ─────────────────────────────────────────────────────────────────────────────

var _sndrDom      = null;   // resolved domain for manual generate button
var _sndrPattern  = null;   // email pattern fetched from the backend (e.g. {first}_{last})
var _sndrSrc      = null;   // which free source resolved the pattern (emailformat/smtp/websearch/cache/…)
var _fiPositions  = [];     // chips: multiple positions to filter LinkedIn People by

var _API = window.API_URL || 'https://api.sndr.co.in';

// HTML-escape dynamic (server/scraped) data before interpolating into innerHTML.
function _escHtml(s){ return String(s==null?'':s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

// ── safeId: same as dashboard-app.js ─────────────────────────────────────────
function _safeId(str) { return (str || '').replace(/[^a-z0-9]/gi, ''); }

// ── Position chips (multi-select) ─────────────────────────────────────────────
function _renderPosChips() {
  var box = document.getElementById('fi-pos-chips');
  if (!box) return;
  box.innerHTML = '';
  _fiPositions.forEach(function(p, i) {
    var chip = document.createElement('span');
    chip.className = 'fi-pos-chip';
    chip.innerHTML = '<span>' + _escHtml(p) + '</span>';
    var x = document.createElement('button');
    x.type = 'button'; x.setAttribute('aria-label', 'Remove'); x.textContent = '×';
    x.addEventListener('click', function(e) { e.stopPropagation(); _fiPositions.splice(i, 1); _renderPosChips(); });
    chip.appendChild(x);
    box.appendChild(chip);
  });
  var hint = document.getElementById('fi-pos-hint');
  if (hint) hint.style.display = _fiPositions.length ? 'none' : '';
}
function _addPos(val) {
  val = (val || '').trim();
  if (!val) return;
  // de-dupe case-insensitively
  var exists = _fiPositions.some(function(p){ return p.toLowerCase() === val.toLowerCase(); });
  if (!exists) _fiPositions.push(val);
  _renderPosChips();
}
// All positions to filter by — committed chips plus any half-typed text still in the box.
function _collectPositions() {
  var inp = document.getElementById('fi-position');
  var pending = inp ? inp.value.trim() : '';
  var list = _fiPositions.slice();
  if (pending && !list.some(function(p){ return p.toLowerCase() === pending.toLowerCase(); })) list.push(pending);
  return list;
}

// ── chrome.storage helper ─────────────────────────────────────────────────────
function _getHint(cb) {
  try { chrome.storage.local.get(['finderHint'], function(d) { cb(d.finderHint || null); }); }
  catch(e) { cb(null); }
}
function _setHint(obj) {
  try { chrome.storage.local.set({ finderHint: obj }); } catch(e) {}
}

// ── Status helpers ────────────────────────────────────────────────────────────
function _setStatus(html) {
  var el = document.getElementById('fi-gen-status'); if (el) el.innerHTML = html;
}
function _setBtn(id, html, disabled) {
  var el = document.getElementById(id);
  if (el) { el.innerHTML = html; el.disabled = !!disabled; }
}

// ─────────────────────────────────────────────────────────────────────────────
// Promise-wrapped client-side (browser, real IP) pattern search, for callers that
// need to await the result (e.g. before deciding whether to fall back to
// the manual-entry UI).
function _sndrClientSearchAsync(company, domain) {
  return new Promise(function(resolve) {
    try {
      chrome.runtime.sendMessage({ type: 'CLIENT_PATTERN_SEARCH', company: company, domain: domain }, function(res) {
        if (chrome.runtime.lastError || !res || !res.ok || !res.result) return resolve(null);
        resolve(res.result);
      });
    } catch (e) { resolve(null); }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// OPEN LINKEDIN
// ─────────────────────────────────────────────────────────────────────────────
window.sndrOpenLinkedIn = function() {
  var co = (document.getElementById('fi-company') || {value:''}).value.trim();
  var positions = _collectPositions();
  var cv = (document.getElementById('fi-country')  || {value:'IN'}).value;
  var ci = document.getElementById('fi-company');
  if (!co) {
    if (ci) {
      ci.style.borderColor = '#ba1a1a'; ci.style.boxShadow = '0 0 0 3px rgba(186,26,26,.15)'; ci.focus();
      setTimeout(function() { ci.style.borderColor=''; ci.style.boxShadow=''; }, 1800);
    }
    return;
  }

  // Clear any hint left over from a previous company search — the real
  // domain for THIS company comes from LinkedIn itself once its /people/
  // page loads (see linkedin.js's reportCompanyDomainFromUrl), not a guess
  // made here. Carrying over a stale domain/pattern would apply the wrong
  // company's pattern to these contacts.
  _sndrDom = null; _sndrPattern = null; _sndrSrc = null;
  _setHint({ company: co, domain: null, pattern: null });

  // Open LinkedIn's own company search for the typed name; the content script
  // (linkedin.js checkPendingCompanyRedirect) picks the matching company from
  // the results and goes to its /people/ page with the position filter. If no
  // result matches, it falls back to the plain people search below.
  var fallbackUrl = sndrBuildLIUrl(co, positions, cv);
  try {
    chrome.storage.local.set({
      pendingCompanySlugLookup: { company: co, positions: positions, fallbackUrl: fallbackUrl, ts: Date.now() }
    });
  } catch (e) {}

  var url = 'https://www.linkedin.com/search/results/companies/?keywords=' + encodeURIComponent(co);

  // Visual feedback on button
  var lb = document.getElementById('fi-linkedin-btn');
  if (lb) { lb.style.opacity='0.7'; lb.style.pointerEvents='none'; setTimeout(function(){ lb.style.opacity=''; lb.style.pointerEvents=''; }, 2500); }

  // Always show fallback link
  _setStatus('Opening LinkedIn… <a href="' + url + '" target="_blank" rel="noopener noreferrer" ' +
    'style="color:var(--p);text-decoration:underline;font-weight:600">Click here if nothing opens</a>');

  // 4-layer open strategy
  var done = false;
  try { chrome.runtime.sendMessage({ type: 'OPEN_TAB', url: url }, function(res) { if (!chrome.runtime.lastError && res && res.ok) done = true; }); } catch(e) {}
  setTimeout(function() { if (done) return; try { chrome.tabs.create({ url: url }); done=true; } catch(e) {} }, 150);
  setTimeout(function() { if (done) return; try { var w=window.open(url,'_blank'); if(w) done=true; } catch(e) {} }, 300);
  setTimeout(function() {
    if (done) return;
    var a=document.createElement('a'); a.href=url; a.target='_blank'; a.rel='noopener noreferrer';
    document.body.appendChild(a); a.click(); setTimeout(function(){ a.parentNode&&a.parentNode.removeChild(a); }, 500);
  }, 450);
};

// ─────────────────────────────────────────────────────────────────────────────
// GENERATE EMAILS (manual — uses selected domain card or typed domain)
// ─────────────────────────────────────────────────────────────────────────────
window.sndrGenerateEmails = function() {
  var mi     = document.getElementById('fi-domain-manual');
  var domain = _sndrDom || (mi ? mi.value.trim() : '');
  if (!domain) return;
  var names = (window._findContacts || []).map(function(c){ return c.name; }).filter(Boolean);
  if (!names.length) {
    _setStatus('<span style="color:#ba1a1a">No contacts yet — go to LinkedIn and scroll the People page first.</span>');
    return;
  }
  _setBtn('fi-generate-btn', 'Generating…', true);
  _setStatus('Generating ' + names.length + ' emails for <strong>' + _escHtml(domain) + '</strong>…');
  var companyName = (document.getElementById('fi-company') || {value:''}).value.trim();
  fetch(_API + '/finder/generate-emails', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ domain: domain, pattern: _sndrPattern, names: names, company: companyName })
  }).then(function(r){ return r.json(); }).then(function(d){
    _setBtn('fi-generate-btn', 'Generate Emails', false);
    _applyEmailResults(d.emails || [], 'generated', !!d.guess);
    _setStatus('<span style="color:#059669">✓ Generated ' + (d.found||0) + ' emails</span>');
  }).catch(function(){
    _setBtn('fi-generate-btn', 'Generate Emails', false);
    _setStatus('<span style="color:#ba1a1a">Backend offline.</span>');
  });
};

// ─────────────────────────────────────────────────────────────────────────────
// BULK FINDER — runs when Find tab opens (overrides autoFindAll)
// ─────────────────────────────────────────────────────────────────────────────
// unverified = no email format could be confirmed for this company, so the
// address uses the most common format; the card says so instead of passing
// a guess off as a found address.
function _applyEmailResults(emails, src, unverified) {
  var contacts = window._findContacts || [];
  emails.forEach(function(e) {
    var c   = contacts.find(function(x){ return x.name === e.name; });
    var id  = c ? (c.id || c.profileUrl || e.name) : e.name;
    var el  = document.getElementById('fcr-' + _safeId(id));
    if (!e.email) {
      if (el) el.innerHTML = '<span class="fc-pending" style="color:#e67e00" title="LinkedIn shows only part of this person\'s name, so their address can\'t be built">Name incomplete</span>';
      return;
    }
    if (el) el.innerHTML = '<span class="fc-email">' + _escHtml(e.email) + '</span>' +
      (unverified ? '<span class="fc-src fc-src-unverified" title="This company\'s email format couldn\'t be confirmed — this uses the most common format">unverified</span>' : '');
    if (window._emailResults && id) window._emailResults[id] = { email: e.email, source: unverified ? 'unverified' : (src || 'pattern') };
  });
  if (typeof window._updateFindActions === 'function') window._updateFindActions();
}

var _CONF_RANK = { high: 3, medium: 2, low: 1 };
function _confBetter(a, b) { return (_CONF_RANK[a] || 0) > (_CONF_RANK[b] || 0); }

function _post(path, body) {
  return fetch(_API + path, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  }).then(function(r) { return r.json(); });
}

// Real @domain addresses found on the open web, searched from this browser.
function _sndrDomainEmailsAsync(domain) {
  return new Promise(function(resolve) {
    try {
      chrome.runtime.sendMessage({ type: 'CLIENT_DOMAIN_EMAILS', domain: domain }, function(res) {
        if (chrome.runtime.lastError || !res || !res.ok) return resolve([]);
        resolve(res.emails || []);
      });
    } catch (e) { resolve([]); }
  });
}

// Finds the company's email format, strongest evidence first, stopping as
// soon as it's confirmed:
//   1. backend cache / email-format.com / company website
//   2. real employees' addresses checked against the company's mail system
//   3. published "email format" snippets (searched from this browser)
//   4. real @domain addresses on the web, matched to these employees' names
// Then applies it to every contact. If nothing turned up, the most common
// format is used and every card is marked "unverified".
async function _sndrBulkFind(domain, company, opts) {
  opts = opts || {};
  var contacts = window._findContacts || [];
  if (!contacts.length) return;
  var names = contacts.map(function(c){ return c.name; }).filter(Boolean);

  var btn = document.getElementById('btn-find-all');
  function stage(text) {
    if (btn) { btn.innerHTML = '<span class="mi" style="font-size:15px">hourglass_top</span>' + _escHtml(text); btn.disabled = true; }
  }
  function done(html) {
    if (btn) { btn.innerHTML = html; btn.disabled = false; }
  }

  var best = { pattern: opts.pattern || null, source: opts.source || null, confidence: opts.pattern ? (opts.confidence || 'medium') : null };
  function consider(p, src, conf) {
    if (p && _confBetter(conf, best.confidence)) best = { pattern: p, source: src, confidence: conf };
  }

  try {
    if (best.confidence !== 'high') {
      stage('Looking up email format…');
      var d1 = await _post('/finder/company-lookup', { domain: domain, company: company || '', domainSource: opts.domainSource || undefined });
      consider(d1.pattern, (d1.source || '').replace('_cache', ''), d1.confidence || 'low');
    }
  } catch (e) {
    _setStatus('<span style="color:#ba1a1a">Can\'t reach the SNDR server — please try again in a minute.</span>');
    done('<span class="mi" style="font-size:15px">search</span>Find All Emails');
    return;
  }

  if (best.confidence !== 'high') {
    stage('Verifying with real employees…');
    try {
      var v = await _post('/finder/verify-pattern', { domain: domain, names: names });
      consider(v.pattern, 'verified', 'high');
    } catch (e) {}
  }

  if (best.confidence !== 'high' && company) {
    stage('Searching the web…');
    var found = await _sndrClientSearchAsync(company, domain);
    if (found && _confBetter(found.confidence || 'low', best.confidence)) {
      consider(found.pattern, 'client_search', found.confidence || 'low');
      _post('/finder/report-pattern', { domain: domain, pattern: found.pattern, sampleEmail: found.sampleEmail || null, confidence: found.confidence || 'low' }).catch(function() {});
    }
  }

  if (best.confidence !== 'high') {
    stage('Checking real @' + domain + ' addresses…');
    var webEmails = await _sndrDomainEmailsAsync(domain);
    if (webEmails.length) {
      try {
        var inf = await _post('/finder/infer-from-emails', { domain: domain, emails: webEmails, names: names });
        consider(inf.pattern, 'web_evidence', inf.confidence || 'low');
      } catch (e) {}
    }
  }

  _setHint({ company: company, domain: domain, pattern: best.pattern, source: best.source, confidence: best.confidence, domainSource: opts.domainSource || null });

  try {
    stage('Generating emails…');
    var gen = await _post('/finder/generate-emails', { domain: domain, pattern: best.pattern, names: names, company: company });
    var unverified = !!gen.guess || best.confidence === 'low';
    var count = (gen.emails || []).filter(function(e){ return e.email; }).length;
    _applyEmailResults(gen.emails || [], best.source, unverified);
    done('<span class="mi" style="font-size:15px">check_circle</span>' + count + '/' + contacts.length + (unverified ? ' emails (unverified)' : ' emails found'));
  } catch (e) {
    _setStatus('<span style="color:#ba1a1a">Can\'t reach the SNDR server — please try again in a minute.</span>');
    done('<span class="mi" style="font-size:15px">search</span>Find All Emails');
  }
}

// Override dashboard-app.js's loadFindScreen with the ONE email-finding
// pipeline: read finderHint (normally already set by LinkedIn itself — see
// linkedin.js's reportCompanyDomainFromUrl, which resolves the domain from
// the actual company page opened, not a guess from typed text) and run the
// bulk finder. If no hint exists yet (e.g. LinkedIn hasn't been opened for
// this company, or the lookup couldn't resolve one), fall back to resolving
// the domain from the typed company name directly — same bulk pipeline
// either way, never a separate/legacy code path.
// This must run BEFORE the user navigates to the Find tab.
// Since finder-card.js loads after dashboard-app.js, window.loadFindScreen exists now.
(function overrideLoadFindScreen() {
  var _origLoad = window.loadFindScreen;
  if (typeof _origLoad !== 'function') return;

  window.loadFindScreen = function() {
    // Step 1: still render contact cards using original logic
    if (typeof chrome === 'undefined' || !chrome.storage) {
      if (typeof window.renderFindEmpty === 'function') window.renderFindEmpty();
      return;
    }
    chrome.storage.local.get(['extractedContacts'], function(data) {
      window._findContacts = data.extractedContacts || [];
      if (typeof window.renderFindScreen === 'function') window.renderFindScreen();

      if (!window._findContacts.length) return;

      // Step 2: read finderHint to get domain+pattern
      _getHint(function(hint) {
        var domain       = hint && hint.domain       ? hint.domain       : null;
        var pattern      = hint && hint.pattern      ? hint.pattern      : null;
        var company      = hint && hint.company      ? hint.company      : '';
        var source       = hint && hint.source       ? hint.source       : null;
        var confidence   = hint && hint.confidence   ? hint.confidence   : null;
        var domainSource = hint && hint.domainSource ? hint.domainSource : null;

        // Pre-fill the finder card with the company info
        var ci = document.getElementById('fi-company');
        if (ci && company && !ci.value) ci.value = company;

        if (domain) {
          setTimeout(function() {
            _sndrBulkFind(domain, company, { pattern: pattern, source: source, confidence: confidence, domainSource: domainSource });
          }, 400);
          return;
        }

        // No hint yet — resolve the domain from the typed company name
        // (the same fallback _sndrBulkFind itself would use, just done up
        // front since _sndrBulkFind needs a domain to start with).
        var typedCompany = company || (ci ? ci.value.trim() : '');
        if (!typedCompany) return;
        fetch(_API + '/finder/company-lookup', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ company: typedCompany })
        })
        .then(function(r) { return r.json(); })
        .then(function(d) {
          if (!d.domain) {
            // Couldn't work out which domain this company emails from — the
            // one case where the manual domain box is needed.
            sndrShowDomainSection([{ _domain: null }]);
            _setStatus('<span style="color:#e67e00">Couldn\'t find ' + _escHtml(typedCompany) + '\'s email domain. Enter it above (e.g. company.com) and click Generate.</span>');
            return;
          }
          var src = (d.source || '').replace('_cache', '') || null;
          _setHint({ company: typedCompany, domain: d.domain, pattern: d.pattern || null, source: src, confidence: d.confidence || null });
          setTimeout(function() {
            _sndrBulkFind(d.domain, typedCompany, { pattern: d.pattern || null, source: src, confidence: d.confidence || null });
          }, 100);
        })
        .catch(function() {});
      });
    });
  };
})();

// ─────────────────────────────────────────────────────────────────────────────
// BUILD LINKEDIN URL
// ─────────────────────────────────────────────────────────────────────────────
// positions may be a single string (legacy) or an array of position strings.
// Multiple positions are combined with LinkedIn boolean OR, e.g.
//   "HR Manager" OR "Talent Acquisition" OR Recruiter
// Fallback destination only — used when LinkedIn's company search has no
// result matching the typed name (see linkedin.js checkPendingCompanyRedirect).
function sndrBuildLIUrl(co, positions, country) {
  var posList = Array.isArray(positions) ? positions : (positions ? [positions] : []);
  posList = posList.map(function(p){ return (p||'').trim(); }).filter(Boolean);
  // Quote multi-word phrases so LinkedIn treats them as one term in the OR.
  function term(p){ return /\s/.test(p) ? '"' + p + '"' : p; }
  var posKw = posList.length === 1
    ? posList[0]
    : posList.map(term).join(' OR ');

  var geo = '';
  if      (country === 'IN') geo = '&geoUrn=%5B%22102713980%22%5D';
  else if (country === 'US') geo = '&geoUrn=%5B%22103644278%22%5D';
  else if (country === 'GB') geo = '&geoUrn=%5B%22101165590%22%5D';
  else if (country === 'SG') geo = '&geoUrn=%5B%22102454443%22%5D';
  else if (country === 'AE') geo = '&geoUrn=%5B%22104305776%22%5D';

  var kw = posKw ? (posKw + ' ' + co) : co;
  return 'https://www.linkedin.com/search/results/people/?keywords=' + encodeURIComponent(kw) + '&origin=FACETED_SEARCH' + geo;
}

// ─────────────────────────────────────────────────────────────────────────────
// DOMAIN SECTION UI — the resolved domain is always auto-selected (there is
// only ever one real candidate for a given company search), so this just
// shows it pre-filled in the manual input rather than asking the user to
// click a card with a single, non-optional choice on it. The input stays
// editable so a domain can still be overridden by hand if needed.
// ─────────────────────────────────────────────────────────────────────────────
function sndrShowDomainSection(opts) {
  var ds = document.getElementById('fi-domain-section');
  var mi = document.getElementById('fi-domain-manual');
  var gb = document.getElementById('fi-generate-btn');
  if (!ds) return;
  ds.style.display = 'block';
  var domain = (opts && opts[0] && opts[0]._domain) || null;
  _sndrDom = domain;
  if (mi) mi.value = domain || '';
  if (gb) gb.disabled = !domain;
}

// ─────────────────────────────────────────────────────────────────────────────
// INIT — wire up input events
// ─────────────────────────────────────────────────────────────────────────────
function sndrFiInit() {
  var mi = document.getElementById('fi-domain-manual');
  var gb = document.getElementById('fi-generate-btn');

  // ── Position: chip-style multi-input ──────────────────────────────────────
  var posInput = document.getElementById('fi-position');
  var posBox   = document.getElementById('fi-pos-box');
  if (posBox && posInput) {
    posBox.addEventListener('click', function() { posInput.focus(); });
    posInput.addEventListener('focus', function() { posBox.classList.add('focus'); });
    posInput.addEventListener('blur',  function() { posBox.classList.remove('focus'); _addPos(posInput.value); posInput.value=''; });
    posInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ',' ) {
        e.preventDefault(); _addPos(posInput.value); posInput.value='';
      } else if (e.key === 'Backspace' && !posInput.value && _fiPositions.length) {
        _fiPositions.pop(); _renderPosChips();
      }
    });
    // Support typing/pasting comma-separated lists
    posInput.addEventListener('input', function() {
      if (posInput.value.indexOf(',') !== -1) {
        posInput.value.split(',').forEach(function(part){ _addPos(part); });
        posInput.value='';
      }
    });
  }

  if (mi) {
    mi.addEventListener('input', function() {
      if (mi.value.trim()) {
        _sndrDom = mi.value.trim(); if (gb) gb.disabled = false;
      } else { _sndrDom = null; if (gb) gb.disabled = true; }
    });
  }

  // Restore last session hint — silently, same as a fresh lookup: no
  // domain/pattern text shown anywhere.
  _getHint(function(hint) {
    if (!hint) return;
    var ci2 = document.getElementById('fi-company');
    if (hint.company && ci2 && !ci2.value) ci2.value = hint.company;
    if (hint.domain) {
      _sndrDom = hint.domain;
      _sndrPattern = hint.pattern || null;
      _sndrSrc = hint.source || null;
      if (hint.pattern) _setStatus('<span style="color:#059669">Ready — click Open LinkedIn &amp; Extract Names.</span>');
    }
  });
}

if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', sndrFiInit); }
else { sndrFiInit(); }

// ─────────────────────────────────────────────────────────────────────────────
// LINKEDIN BUTTON — belt-and-suspenders binding
// ─────────────────────────────────────────────────────────────────────────────
(function bindLinkedInBtn() {
  function attach() {
    var btn = document.getElementById('fi-linkedin-btn');
    if (btn && !btn._sndrBound) {
      btn._sndrBound = true;
      btn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); window.sndrOpenLinkedIn(); });
    }
    // The Generate button relied on an inline onclick, which the extension CSP
    // (script-src 'self') blocks — bind it here like the LinkedIn button.
    var gbtn = document.getElementById('fi-generate-btn');
    if (gbtn && !gbtn._sndrBound) {
      gbtn._sndrBound = true;
      gbtn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); window.sndrGenerateEmails(); });
    }
  }
  attach();
  // Also re-attach whenever Find tab is shown
  var _g = window.goNav;
  if (typeof _g === 'function') {
    window.goNav = function(n) { _g(n); if (n==='find') setTimeout(attach, 100); };
  } else {
    Object.defineProperty(window, 'goNav', {
      configurable: true,
      set: function(fn) {
        var w = function(n) { fn(n); if (n==='find') setTimeout(attach, 100); };
        Object.defineProperty(window, 'goNav', { value: w, writable: true, configurable: true });
      }
    });
  }
})();