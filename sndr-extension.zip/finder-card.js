// ── SNDR Finder Card ─────────────────────────────────────────────────────────
// Handles: plain-text company input (no autocomplete dropdown — removed on
// purpose, see sndrOpenLinkedIn below), backend email-pattern lookup (100%
// free — SQLite cache / email-format.com / SMTP probe / Bedrock / site-
// scrape+search, no paid provider), LinkedIn redirect, and bulk email
// generation for all extracted contacts.
// ─────────────────────────────────────────────────────────────────────────────

var _sndrDom      = null;   // resolved domain for manual generate button
var _sndrPattern  = null;   // email pattern fetched from the backend (e.g. {first}_{last})
var _sndrSrc      = null;   // which free source resolved the pattern (emailformat/smtp/websearch/cache/…)
var _fiPositions  = [];     // chips: multiple positions to filter LinkedIn People by

var _API = window.API_URL || 'https://api.sndr.co.in';

// HTML-escape dynamic (server/scraped) data before interpolating into innerHTML.
function _escHtml(s){ return String(s==null?'':s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

// ── safeId: same as dashboard-app.js ─────────────────────────────────────────
function _safeId(str) { return (str || '').replace(/[^a-z0-9]/gi, ''); }

// ── Position chips (multi-select) ─────────────────────────────────────────────
function _renderPosChips() {
  var box = document.getElementById('fi-pos-chips');
  if (!box) return;
  box.innerHTML = '';
  _fiPositions.forEach(function(p, i) {
    var chip = document.createElement('span');
    chip.className = 'fi-pos-chip';
    chip.innerHTML = '<span>' + _escHtml(p) + '</span>';
    var x = document.createElement('button');
    x.type = 'button'; x.setAttribute('aria-label', 'Remove'); x.textContent = '×';
    x.addEventListener('click', function(e) { e.stopPropagation(); _fiPositions.splice(i, 1); _renderPosChips(); });
    chip.appendChild(x);
    box.appendChild(chip);
  });
  var hint = document.getElementById('fi-pos-hint');
  if (hint) hint.style.display = _fiPositions.length ? 'none' : '';
}
function _addPos(val) {
  val = (val || '').trim();
  if (!val) return;
  // de-dupe case-insensitively
  var exists = _fiPositions.some(function(p){ return p.toLowerCase() === val.toLowerCase(); });
  if (!exists) _fiPositions.push(val);
  _renderPosChips();
}
// All positions to filter by — committed chips plus any half-typed text still in the box.
function _collectPositions() {
  var inp = document.getElementById('fi-position');
  var pending = inp ? inp.value.trim() : '';
  var list = _fiPositions.slice();
  if (pending && !list.some(function(p){ return p.toLowerCase() === pending.toLowerCase(); })) list.push(pending);
  return list;
}

// ── chrome.storage helper ─────────────────────────────────────────────────────
function _getHint(cb) {
  try { chrome.storage.local.get(['finderHint'], function(d) { cb(d.finderHint || null); }); }
  catch(e) { cb(null); }
}
function _setHint(obj) {
  try { chrome.storage.local.set({ finderHint: obj }); } catch(e) {}
}

// ── Status helpers ────────────────────────────────────────────────────────────
function _setStatus(html) {
  var el = document.getElementById('fi-gen-status'); if (el) el.innerHTML = html;
}
function _setBtn(id, html, disabled) {
  var el = document.getElementById(id);
  if (el) { el.innerHTML = html; el.disabled = !!disabled; }
}

// ─────────────────────────────────────────────────────────────────────────────
// DOMAIN + PATTERN LOOKUP — called from the typed company name alone (no
// autocomplete dropdown/domain hint anymore — see sndrOpenLinkedIn). The
// backend resolves the domain itself now (known-company map -> Bedrock/
// Claude, MX-verified -> Clearbit -> DNS-guessing -> Google), so this just
// sends the company name and uses whatever comes back. Deliberately silent
// (no domain/pattern text shown anywhere in the UI) — the result is only
// ever used internally to generate emails once LinkedIn profiles are
// extracted; sndrShowDomainSection (the manual domain/Generate-button
// fallback) is only revealed if this silently fails end to end.
function sndrLookupDomain(company) {
  if (!company) return;
  _sndrDom = null;
  _sndrPattern = null;

  _setStatus('<span style="color:var(--ol)">Preparing…</span>');
  _setHint({ company: company, domain: null, pattern: null });

  fetch(_API + '/finder/company-lookup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ company: company })
  })
  .then(function(r) { return r.json(); })
  .then(function(data) {
    _sndrDom = data.domain || null;
    _sndrPattern = data.pattern || null;
    _sndrSrc = (data.source || '').replace('_cache', '') || null;
    _setHint({ company: company, domain: _sndrDom, pattern: _sndrPattern, sampleEmail: data.sampleEmail || null, source: _sndrSrc });
    // Silent either way — a missing pattern just means generation falls back
    // to trying common formats later; nothing about this is surfaced here.
    _setStatus('<span style="color:#059669">Ready — click Open LinkedIn &amp; Extract Names.</span>');

    // Backend couldn't resolve a pattern at all, OR resolved it with low/
    // medium confidence (e.g. email-format.com's database can just be wrong
    // for a specific company — confirmed live, it stated the wrong pattern
    // for one real company while still reporting non-'high' confidence) —
    // try from here instead, on this browser's own real IP, which none of
    // the sources that block the server (RocketReach/DDG/Google) block.
    // Fully silent, fire-and-forget: doesn't affect the status line either
    // way, and reports what it finds back to the backend for every future
    // user. A high-confidence backend result is trusted outright and not
    // re-checked, to avoid launching a background window for every lookup.
    if (_sndrDom && (!_sndrPattern || data.confidence !== 'high')) _sndrTryClientSearch(_sndrDom, company);
  })
  .catch(function() {
    _setStatus('<span style="color:#ba1a1a">Backend offline — start the server.</span>');
  });
}

function _sndrTryClientSearch(domain, company) {
  if (!company) return;
  try {
    chrome.runtime.sendMessage({ type: 'CLIENT_PATTERN_SEARCH', company: company, domain: domain }, function(res) {
      if (chrome.runtime.lastError || !res || !res.ok || !res.result) return;
      var found = res.result;
      _sndrPattern = found.pattern;
      _sndrSrc = 'client_search';
      _setHint({ company: company, domain: domain, pattern: found.pattern, sampleEmail: found.sampleEmail || null, source: _sndrSrc });
      fetch(_API + '/finder/report-pattern', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: domain, pattern: found.pattern, sampleEmail: found.sampleEmail || null, confidence: found.confidence || 'low' })
      }).catch(function() {});
    });
  } catch (e) {}
}

// Promise-wrapped version of the same client-side search, for callers that
// need to await the result (e.g. before deciding whether to fall back to
// the manual-entry UI).
function _sndrClientSearchAsync(company, domain) {
  return new Promise(function(resolve) {
    try {
      chrome.runtime.sendMessage({ type: 'CLIENT_PATTERN_SEARCH', company: company, domain: domain }, function(res) {
        if (chrome.runtime.lastError || !res || !res.ok || !res.result) return resolve(null);
        resolve(res.result);
      });
    } catch (e) { resolve(null); }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// OPEN LINKEDIN
// ─────────────────────────────────────────────────────────────────────────────
window.sndrOpenLinkedIn = function() {
  var co = (document.getElementById('fi-company') || {value:''}).value.trim();
  var positions = _collectPositions();
  var cv = (document.getElementById('fi-country')  || {value:'IN'}).value;
  var ci = document.getElementById('fi-company');
  if (!co) {
    if (ci) {
      ci.style.borderColor = '#ba1a1a'; ci.style.boxShadow = '0 0 0 3px rgba(186,26,26,.15)'; ci.focus();
      setTimeout(function() { ci.style.borderColor=''; ci.style.boxShadow=''; }, 1800);
    }
    return;
  }

  // Kick off domain/pattern resolution in the background — it runs in
  // parallel with opening LinkedIn and scrolling to capture profiles, which
  // takes measurably longer, so it's normally done well before "Find All
  // Emails" is ever clicked.
  sndrLookupDomain(co);

  // Two-step LinkedIn navigation: open the reliable generic people-search
  // first (works for every company, no guessing), then let the content
  // script upgrade it to the company's own /people/ page IF it can resolve
  // the real LinkedIn slug via LinkedIn's own lookup — never a guessed slug
  // (a prior attempt at guessing the slug from the domain/company name hit
  // real dead ends: LinkedIn slugs aren't derivable from either, e.g.
  // Alvarez & Marsal's domain is alvarezandmarsal.com but their real slug
  // is "alvarez-&-marsal"). If the lookup fails for any reason, the tab
  // just stays on the already-good fallback search results.
  try {
    chrome.storage.local.set({
      pendingCompanySlugLookup: { company: co, positions: positions, ts: Date.now() }
    });
  } catch (e) {}

  var url = sndrBuildLIUrl(co, positions, cv);

  // Visual feedback on button
  var lb = document.getElementById('fi-linkedin-btn');
  if (lb) { lb.style.opacity='0.7'; lb.style.pointerEvents='none'; setTimeout(function(){ lb.style.opacity=''; lb.style.pointerEvents=''; }, 2500); }

  // Always show fallback link
  _setStatus('Opening LinkedIn… <a href="' + url + '" target="_blank" rel="noopener noreferrer" ' +
    'style="color:var(--p);text-decoration:underline;font-weight:600">Click here if nothing opens</a>');

  // 4-layer open strategy
  var done = false;
  try { chrome.runtime.sendMessage({ type: 'OPEN_TAB', url: url }, function(res) { if (!chrome.runtime.lastError && res && res.ok) done = true; }); } catch(e) {}
  setTimeout(function() { if (done) return; try { chrome.tabs.create({ url: url }); done=true; } catch(e) {} }, 150);
  setTimeout(function() { if (done) return; try { var w=window.open(url,'_blank'); if(w) done=true; } catch(e) {} }, 300);
  setTimeout(function() {
    if (done) return;
    var a=document.createElement('a'); a.href=url; a.target='_blank'; a.rel='noopener noreferrer';
    document.body.appendChild(a); a.click(); setTimeout(function(){ a.parentNode&&a.parentNode.removeChild(a); }, 500);
  }, 450);
};

// ─────────────────────────────────────────────────────────────────────────────
// GENERATE EMAILS (manual — uses selected domain card or typed domain)
// ─────────────────────────────────────────────────────────────────────────────
window.sndrGenerateEmails = function() {
  var mi     = document.getElementById('fi-domain-manual');
  var domain = _sndrDom || (mi ? mi.value.trim() : '');
  if (!domain) return;
  var names = (window._findContacts || []).map(function(c){ return c.name; }).filter(Boolean);
  if (!names.length) {
    _setStatus('<span style="color:#ba1a1a">No contacts yet — go to LinkedIn and scroll the People page first.</span>');
    return;
  }
  _setBtn('fi-generate-btn', 'Generating…', true);
  _setStatus('Generating ' + names.length + ' emails for <strong>' + _escHtml(domain) + '</strong>…');
  var companyName = (document.getElementById('fi-company') || {value:''}).value.trim();
  fetch(_API + '/finder/generate-emails', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ domain: domain, pattern: _sndrPattern, names: names, company: companyName })
  }).then(function(r){ return r.json(); }).then(function(d){
    _setBtn('fi-generate-btn', 'Generate Emails', false);
    _applyEmailResults(d.emails || [], d.source || 'generated');
    _setStatus('<span style="color:#059669">✓ Generated ' + (d.found||0) + ' emails</span>');
  }).catch(function(){
    _setBtn('fi-generate-btn', 'Generate Emails', false);
    _setStatus('<span style="color:#ba1a1a">Backend offline.</span>');
  });
};

// ─────────────────────────────────────────────────────────────────────────────
// BULK FINDER — runs when Find tab opens (overrides autoFindAll)
// ─────────────────────────────────────────────────────────────────────────────
function _applyEmailResults(emails, src) {
  var contacts = window._findContacts || [];
  emails.forEach(function(e) {
    if (!e.email) return;
    var c   = contacts.find(function(x){ return x.name === e.name; });
    var id  = c ? (c.id || c.profileUrl || e.name) : e.name;
    var sid = _safeId(id);
    var el  = document.getElementById('fcr-' + sid);
    if (el) el.innerHTML = '<span class="fc-email">' + _escHtml(e.email) + '</span>';
    if (window._emailResults && id) window._emailResults[id] = { email: e.email, source: src || 'pattern' };
  });
  if (typeof window._updateFindActions === 'function') window._updateFindActions();
}

async function _sndrBulkFind(domain, pattern, company, knownSrc) {
  var contacts = window._findContacts || [];
  if (!contacts.length) return;

  var btn = document.getElementById('btn-find-all');
  function setBtn(html, dis) { if (btn) { btn.innerHTML=html; btn.disabled=!!dis; } }

  setBtn('<span class="mi" style="font-size:15px">hourglass_top</span>Finding emails…', true);
  _setStatus('Finding emails…');

  // If we already have the pattern (looked up when company was selected), skip company-lookup
  var pat = pattern || null;
  var src = knownSrc || 'cache';

  if (!pat) {
    try {
      var r1 = await fetch(_API + '/finder/company-lookup', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: domain, company: company || '' })
      });
      var d1 = await r1.json();
      pat = d1.pattern || null;
      src = (d1.source || 'pattern').replace('_cache','');
      var d1Confidence = d1.confidence || null;
    } catch(e) {
      _setStatus('<span style="color:#ba1a1a">Backend offline — run <strong>npm start</strong> in the backend folder.</span>');
      setBtn('<span class="mi" style="font-size:15px">search</span>Find All Emails', false);
      return;
    }

    // Backend has nothing, OR resolved it with low/medium confidence (a
    // free source's own database can just be wrong for a specific company —
    // confirmed live) — cross-check from here (this browser's own real IP)
    // before falling back to the manual-entry UI below. A high-confidence
    // backend result is trusted outright, no re-check.
    if ((!pat || d1Confidence !== 'high') && company) {
      var found = await _sndrClientSearchAsync(company, domain);
      if (found) {
        pat = found.pattern;
        src = 'client_search';
        fetch(_API + '/finder/report-pattern', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ domain: domain, pattern: found.pattern, sampleEmail: found.sampleEmail || null, confidence: found.confidence || 'low' })
        }).catch(function() {});
      }
    }
  }

  if (!pat) {
    // Genuine fallback: nothing could be resolved automatically — this is the
    // one case the manual domain/Generate UI is shown for.
    sndrShowDomainSection([{ _domain: domain, name: company || domain }]);
    _setStatus('<span style="color:#e67e00">Couldn\'t find an email pattern automatically. Enter the domain above and click Generate.</span>');
    setBtn('<span class="mi" style="font-size:15px">search</span>Find All Emails', false);
    return;
  }

  // Generate all emails
  var names = contacts.map(function(c){ return c.name; }).filter(Boolean);
  try {
    var r2  = await fetch(_API + '/finder/generate-emails', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: domain, pattern: pat, names: names, company: company })
    });
    var gen = await r2.json();
    var found = (gen.emails||[]).filter(function(e){ return e.email; }).length;
    _applyEmailResults(gen.emails || [], src);
    setBtn('<span class="mi" style="font-size:15px">check_circle</span>' + found + '/' + contacts.length + ' emails found', false);
    _setStatus('<strong>' + found + '</strong> emails generated');
  } catch(e) {
    _setStatus('<span style="color:#ba1a1a">Backend offline.</span>');
    setBtn('<span class="mi" style="font-size:15px">search</span>Find All Emails', false);
  }
}

// Override dashboard-app.js loadFindScreen so OUR bulk finder runs instead of autoFindAll
// This must run BEFORE the user navigates to the Find tab.
// Since finder-card.js loads after dashboard-app.js, window.loadFindScreen exists now.
(function overrideLoadFindScreen() {
  var _origLoad = window.loadFindScreen;
  if (typeof _origLoad !== 'function') return;

  window.loadFindScreen = function() {
    // Step 1: still render contact cards using original logic
    if (typeof chrome === 'undefined' || !chrome.storage) {
      if (typeof window.renderFindEmpty === 'function') window.renderFindEmpty();
      return;
    }
    chrome.storage.local.get(['extractedContacts'], function(data) {
      window._findContacts = data.extractedContacts || [];
      if (typeof window.renderFindScreen === 'function') window.renderFindScreen();

      if (!window._findContacts.length) return;

      // Step 2: read finderHint to get domain+pattern
      _getHint(function(hint) {
        var domain  = hint && hint.domain   ? hint.domain   : null;
        var pattern = hint && hint.pattern  ? hint.pattern  : null;
        var company = hint && hint.company  ? hint.company  : '';
        var source  = hint && hint.source   ? hint.source   : null;

        if (domain) {
          // Pre-fill the finder card with the company info
          var ci = document.getElementById('fi-company');
          if (ci && company && !ci.value) ci.value = company;

          // Run bulk find after a short delay (cards need to render first)
          window._finding = false;
          setTimeout(function() { _sndrBulkFind(domain, pattern, company, source); }, 400);
        } else {
          // No hint — fall back to original per-person finder
          if (typeof window._origAutoFindAll === 'function') {
            setTimeout(window._origAutoFindAll, 800);
          } else if (typeof _origLoad === 'function') {
            // Let original handle it
          }
        }
      });
    });
  };

  // Keep a reference to the original autoFindAll as backup
  window._origAutoFindAll = window.autoFindAll;
})();

// ─────────────────────────────────────────────────────────────────────────────
// BUILD LINKEDIN URL
// ─────────────────────────────────────────────────────────────────────────────
// positions may be a single string (legacy) or an array of position strings.
// Multiple positions are combined with LinkedIn boolean OR, e.g.
//   "HR Manager" OR "Talent Acquisition" OR Recruiter
// This is the reliable fallback destination — always returns a valid
// results page, no guessing involved. The content script (linkedin.js)
// separately tries to upgrade this to the company's own /people/ page
// using LinkedIn's own slug lookup (never a guessed slug — see
// resolveCompanySlug/checkPendingCompanyRedirect there for why: a
// domain/name-derived guess doesn't correspond to LinkedIn's real slug
// often enough to be usable, e.g. Alvarez & Marsal's domain is
// alvarezandmarsal.com but their real slug is "alvarez-&-marsal").
function sndrBuildLIUrl(co, positions, country) {
  var posList = Array.isArray(positions) ? positions : (positions ? [positions] : []);
  posList = posList.map(function(p){ return (p||'').trim(); }).filter(Boolean);
  // Quote multi-word phrases so LinkedIn treats them as one term in the OR.
  function term(p){ return /\s/.test(p) ? '"' + p + '"' : p; }
  var posKw = posList.length === 1
    ? posList[0]
    : posList.map(term).join(' OR ');

  var geo = '';
  if      (country === 'IN') geo = '&geoUrn=%5B%22102713980%22%5D';
  else if (country === 'US') geo = '&geoUrn=%5B%22103644278%22%5D';
  else if (country === 'GB') geo = '&geoUrn=%5B%22101165590%22%5D';
  else if (country === 'SG') geo = '&geoUrn=%5B%22102454443%22%5D';
  else if (country === 'AE') geo = '&geoUrn=%5B%22104305776%22%5D';

  var kw = posKw ? (posKw + ' ' + co) : co;
  return 'https://www.linkedin.com/search/results/people/?keywords=' + encodeURIComponent(kw) + '&origin=FACETED_SEARCH' + geo;
}

// ─────────────────────────────────────────────────────────────────────────────
// DOMAIN SECTION UI — the resolved domain is always auto-selected (there is
// only ever one real candidate for a given company search), so this just
// shows it pre-filled in the manual input rather than asking the user to
// click a card with a single, non-optional choice on it. The input stays
// editable so a domain can still be overridden by hand if needed.
// ─────────────────────────────────────────────────────────────────────────────
function sndrShowDomainSection(opts) {
  var ds = document.getElementById('fi-domain-section');
  var mi = document.getElementById('fi-domain-manual');
  var gb = document.getElementById('fi-generate-btn');
  if (!ds) return;
  ds.style.display = 'block';
  var domain = (opts && opts[0] && opts[0]._domain) || null;
  _sndrDom = domain;
  if (mi) mi.value = domain || '';
  if (gb) gb.disabled = !domain;
}

// ─────────────────────────────────────────────────────────────────────────────
// INIT — wire up input events
// ─────────────────────────────────────────────────────────────────────────────
function sndrFiInit() {
  var mi = document.getElementById('fi-domain-manual');
  var gb = document.getElementById('fi-generate-btn');

  // ── Position: chip-style multi-input ──────────────────────────────────────
  var posInput = document.getElementById('fi-position');
  var posBox   = document.getElementById('fi-pos-box');
  if (posBox && posInput) {
    posBox.addEventListener('click', function() { posInput.focus(); });
    posInput.addEventListener('focus', function() { posBox.classList.add('focus'); });
    posInput.addEventListener('blur',  function() { posBox.classList.remove('focus'); _addPos(posInput.value); posInput.value=''; });
    posInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ',' ) {
        e.preventDefault(); _addPos(posInput.value); posInput.value='';
      } else if (e.key === 'Backspace' && !posInput.value && _fiPositions.length) {
        _fiPositions.pop(); _renderPosChips();
      }
    });
    // Support typing/pasting comma-separated lists
    posInput.addEventListener('input', function() {
      if (posInput.value.indexOf(',') !== -1) {
        posInput.value.split(',').forEach(function(part){ _addPos(part); });
        posInput.value='';
      }
    });
  }

  if (mi) {
    mi.addEventListener('input', function() {
      if (mi.value.trim()) {
        _sndrDom = mi.value.trim(); if (gb) gb.disabled = false;
      } else { _sndrDom = null; if (gb) gb.disabled = true; }
    });
  }

  // Restore last session hint — silently, same as a fresh lookup: no
  // domain/pattern text shown anywhere.
  _getHint(function(hint) {
    if (!hint) return;
    var ci2 = document.getElementById('fi-company');
    if (hint.company && ci2 && !ci2.value) ci2.value = hint.company;
    if (hint.domain) {
      _sndrDom = hint.domain;
      _sndrPattern = hint.pattern || null;
      _sndrSrc = hint.source || null;
      if (hint.pattern) _setStatus('<span style="color:#059669">Ready — click Open LinkedIn &amp; Extract Names.</span>');
    }
  });
}

if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', sndrFiInit); }
else { sndrFiInit(); }

// ─────────────────────────────────────────────────────────────────────────────
// LINKEDIN BUTTON — belt-and-suspenders binding
// ─────────────────────────────────────────────────────────────────────────────
(function bindLinkedInBtn() {
  function attach() {
    var btn = document.getElementById('fi-linkedin-btn');
    if (btn && !btn._sndrBound) {
      btn._sndrBound = true;
      btn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); window.sndrOpenLinkedIn(); });
    }
    // The Generate button relied on an inline onclick, which the extension CSP
    // (script-src 'self') blocks — bind it here like the LinkedIn button.
    var gbtn = document.getElementById('fi-generate-btn');
    if (gbtn && !gbtn._sndrBound) {
      gbtn._sndrBound = true;
      gbtn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); window.sndrGenerateEmails(); });
    }
  }
  attach();
  // Also re-attach whenever Find tab is shown
  var _g = window.goNav;
  if (typeof _g === 'function') {
    window.goNav = function(n) { _g(n); if (n==='find') setTimeout(attach, 100); };
  } else {
    Object.defineProperty(window, 'goNav', {
      configurable: true,
      set: function(fn) {
        var w = function(n) { fn(n); if (n==='find') setTimeout(attach, 100); };
        Object.defineProperty(window, 'goNav', { value: w, writable: true, configurable: true });
      }
    });
  }
})();