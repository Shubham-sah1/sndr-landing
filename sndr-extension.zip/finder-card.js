// ── SNDR Finder Card ─────────────────────────────────────────────────────────
// Handles: plain-text company input (no autocomplete dropdown — removed on
// purpose, see sndrOpenLinkedIn below), backend email-pattern lookup (100%
// free — SQLite cache / email-format.com / SMTP probe / Bedrock / site-
// scrape+search, no paid provider), LinkedIn redirect, and bulk email
// generation for all extracted contacts.
// ─────────────────────────────────────────────────────────────────────────────

var _sndrDom      = null;   // resolved domain for manual generate button
var _sndrPattern  = null;   // email pattern fetched from the backend (e.g. {first}_{last})
var _sndrSrc      = null;   // which free source resolved the pattern (emailformat/smtp/websearch/cache/…)
var _fiPositions  = [];     // chips: multiple positions to filter LinkedIn People by

var _API = window.API_URL || 'https://api.sndr.co.in';

// HTML-escape dynamic (server/scraped) data before interpolating into innerHTML.
function _escHtml(s){ return String(s==null?'':s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

// ── safeId: same as dashboard-app.js ─────────────────────────────────────────
function _safeId(str) { return (str || '').replace(/[^a-z0-9]/gi, ''); }

// ── Position chips (multi-select) ─────────────────────────────────────────────
function _renderPosChips() {
  var box = document.getElementById('fi-pos-chips');
  if (!box) return;
  box.innerHTML = '';
  _fiPositions.forEach(function(p, i) {
    var chip = document.createElement('span');
    chip.className = 'fi-pos-chip';
    chip.innerHTML = '<span>' + _escHtml(p) + '</span>';
    var x = document.createElement('button');
    x.type = 'button'; x.setAttribute('aria-label', 'Remove'); x.textContent = '×';
    x.addEventListener('click', function(e) { e.stopPropagation(); _fiPositions.splice(i, 1); _renderPosChips(); });
    chip.appendChild(x);
    box.appendChild(chip);
  });
  var hint = document.getElementById('fi-pos-hint');
  if (hint) hint.style.display = _fiPositions.length ? 'none' : '';
}
function _addPos(val) {
  val = (val || '').trim();
  if (!val) return;
  // de-dupe case-insensitively
  var exists = _fiPositions.some(function(p){ return p.toLowerCase() === val.toLowerCase(); });
  if (!exists) _fiPositions.push(val);
  _renderPosChips();
}
// All positions to filter by — committed chips plus any half-typed text still in the box.
function _collectPositions() {
  var inp = document.getElementById('fi-position');
  var pending = inp ? inp.value.trim() : '';
  var list = _fiPositions.slice();
  if (pending && !list.some(function(p){ return p.toLowerCase() === pending.toLowerCase(); })) list.push(pending);
  return list;
}

// The Country picker's value, as a name the backend can give Claude as
// context ("Zepto" + India → the Indian company, not a same-name one).
var _COUNTRY_NAMES = { IN: 'India', US: 'United States', GB: 'United Kingdom', SG: 'Singapore', AE: 'United Arab Emirates' };
function _countryName() {
  var el = document.getElementById('fi-country');
  return (el && _COUNTRY_NAMES[el.value]) || '';
}

// ── chrome.storage helper ─────────────────────────────────────────────────────
function _getHint(cb) {
  try { chrome.storage.local.get(['finderHint'], function(d) { cb(d.finderHint || null); }); }
  catch(e) { cb(null); }
}
function _setHint(obj) {
  try { chrome.storage.local.set({ finderHint: obj }); } catch(e) {}
}

// ── Status helpers ────────────────────────────────────────────────────────────
function _setStatus(html) {
  var el = document.getElementById('fi-gen-status'); if (el) el.innerHTML = html;
}
function _setBtn(id, html, disabled) {
  var el = document.getElementById(id);
  if (el) { el.innerHTML = html; el.disabled = !!disabled; }
}

// ─────────────────────────────────────────────────────────────────────────────
// Promise-wrapped email-format search (done by the SNDR server; the background
// worker only steps in when the server can't search — never with a tab).
function _sndrClientSearchAsync(company, domain) {
  return new Promise(function(resolve) {
    try {
      chrome.runtime.sendMessage({ type: 'CLIENT_PATTERN_SEARCH', company: company, domain: domain }, function(res) {
        if (chrome.runtime.lastError || !res || !res.ok || !res.result) return resolve(null);
        resolve(res.result);
      });
    } catch (e) { resolve(null); }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// OPEN LINKEDIN
// ─────────────────────────────────────────────────────────────────────────────
window.sndrOpenLinkedIn = function() {
  var co = (document.getElementById('fi-company') || {value:''}).value.trim();
  var positions = _collectPositions();
  var cv = (document.getElementById('fi-country')  || {value:'IN'}).value;
  var ci = document.getElementById('fi-company');
  if (!co) {
    if (ci) {
      ci.style.borderColor = '#ba1a1a'; ci.style.boxShadow = '0 0 0 3px rgba(186,26,26,.15)'; ci.focus();
      setTimeout(function() { ci.style.borderColor=''; ci.style.boxShadow=''; }, 1800);
    }
    return;
  }

  // Clear any hint left over from a previous company search — the real
  // domain for THIS company comes from LinkedIn itself once its /people/
  // page loads (see linkedin.js's reportCompanyDomainFromUrl), not a guess
  // made here. Carrying over a stale domain/pattern would apply the wrong
  // company's pattern to these contacts.
  _sndrDom = null; _sndrPattern = null; _sndrSrc = null;
  // A new search: contacts captured from here on are grouped under this ID.
  // `positions` lets the LinkedIn panel offer one search per role — LinkedIn
  // cuts every list short, so separate role searches reach more people than
  // one combined "A OR B" search.
  _setHint({ company: co, domain: null, pattern: null, country: _countryName(), searchId: String(Date.now()), positions: positions });

  // Open LinkedIn's own company search for the typed name; the content script
  // (linkedin.js checkPendingCompanyRedirect) lists the results and the user
  // picks the right company (many share a name), then it goes to that
  // company's /people/ page with the position filter. "Not listed?" there
  // offers the plain people search below.
  var fallbackUrl = sndrBuildLIUrl(co, positions, cv);
  try {
    chrome.storage.local.set({
      pendingCompanySlugLookup: { company: co, positions: positions, fallbackUrl: fallbackUrl, ts: Date.now() }
    });
  } catch (e) {}

  var url = 'https://www.linkedin.com/search/results/companies/?keywords=' + encodeURIComponent(co);

  // Visual feedback on button
  var lb = document.getElementById('fi-linkedin-btn');
  if (lb) { lb.style.opacity='0.7'; lb.style.pointerEvents='none'; setTimeout(function(){ lb.style.opacity=''; lb.style.pointerEvents=''; }, 2500); }

  // Always show fallback link
  _setStatus('Opening LinkedIn… <a href="' + url + '" target="_blank" rel="noopener noreferrer" ' +
    'style="color:var(--p);text-decoration:underline;font-weight:600">Click here if nothing opens</a>');

  // 4-layer open strategy
  var done = false;
  try { chrome.runtime.sendMessage({ type: 'OPEN_TAB', url: url }, function(res) { if (!chrome.runtime.lastError && res && res.ok) done = true; }); } catch(e) {}
  setTimeout(function() { if (done) return; try { chrome.tabs.create({ url: url }); done=true; } catch(e) {} }, 150);
  setTimeout(function() { if (done) return; try { var w=window.open(url,'_blank'); if(w) done=true; } catch(e) {} }, 300);
  setTimeout(function() {
    if (done) return;
    var a=document.createElement('a'); a.href=url; a.target='_blank'; a.rel='noopener noreferrer';
    document.body.appendChild(a); a.click(); setTimeout(function(){ a.parentNode&&a.parentNode.removeChild(a); }, 500);
  }, 450);
};

// ─────────────────────────────────────────────────────────────────────────────
// GENERATE EMAILS (manual — uses selected domain card or typed domain)
// ─────────────────────────────────────────────────────────────────────────────
window.sndrGenerateEmails = function() {
  var mi     = document.getElementById('fi-domain-manual');
  var domain = _sndrDom || (mi ? mi.value.trim() : '');
  if (!domain) return;
  var names = (window._findContacts || []).map(function(c){ return c.name; }).filter(Boolean);
  if (!names.length) {
    _setStatus('<span style="color:#ba1a1a">No contacts yet — go to LinkedIn and scroll the People page first.</span>');
    return;
  }
  _setBtn('fi-generate-btn', 'Generating…', true);
  _setStatus('Generating ' + names.length + ' emails for <strong>' + _escHtml(domain) + '</strong>…');
  var companyName = (document.getElementById('fi-company') || {value:''}).value.trim();
  fetch(_API + '/finder/generate-emails', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ domain: domain, pattern: _sndrPattern, names: names, company: companyName })
  }).then(function(r){ return r.json(); }).then(function(d){
    _setBtn('fi-generate-btn', 'Generate Emails', false);
    _applyEmailResults(d.emails || [], 'generated', !!d.guess);
    _setStatus('<span style="color:#059669">✓ Generated ' + (d.found||0) + ' emails</span>');
  }).catch(function(){
    _setBtn('fi-generate-btn', 'Generate Emails', false);
    _setStatus('<span style="color:#ba1a1a">Backend offline.</span>');
  });
};

// ─────────────────────────────────────────────────────────────────────────────
// BULK FINDER — runs when Find tab opens (overrides autoFindAll)
// ─────────────────────────────────────────────────────────────────────────────
// unverified = no email format could be confirmed for this company, so the
// address uses the most common format; the card says so instead of passing
// a guess off as a found address.
//
// `contacts` are the contacts the emails were generated for, in the same
// order as the names sent: results are matched by position (never by name
// across the whole list), so two people with the same name at different
// companies can't get each other's address.
function _applyEmailResults(emails, src, unverified, contacts) {
  contacts = contacts || (window._findContacts || []).filter(function(c){ return c.name; });
  emails.forEach(function(e, i) {
    var c   = (contacts[i] && contacts[i].name === e.name) ? contacts[i] : contacts.find(function(x){ return x.name === e.name; });
    var id  = c ? (c.id || c.profileUrl || e.name) : e.name;
    var el  = document.getElementById('fcr-' + _safeId(id));
    if (!e.email) {
      if (el) el.innerHTML = '<span class="fc-pending" style="color:#e67e00" title="LinkedIn shows only part of this person\'s name, so their address can\'t be built">Name incomplete</span>';
      return;
    }
    if (el) el.innerHTML = '<span class="fc-email">' + _escHtml(e.email) + '</span>' +
      (unverified ? '<span class="fc-src fc-src-unverified" title="This company\'s email format couldn\'t be confirmed — this uses the most common format">unverified</span>' : '');
    if (window._emailResults && id) window._emailResults[id] = { email: e.email, source: unverified ? 'unverified' : (src || 'pattern') };
  });
  if (typeof window._updateFindActions === 'function') window._updateFindActions();
}

var _CONF_RANK = { high: 3, medium: 2, low: 1 };
function _confBetter(a, b) { return (_CONF_RANK[a] || 0) > (_CONF_RANK[b] || 0); }

function _post(path, body) {
  return fetch(_API + path, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  }).then(function(r) {
    return r.text().then(function(raw) {
      try { return raw ? JSON.parse(raw) : {}; }
      catch (e) { throw new Error('Unexpected response from SNDR server (' + path + ', HTTP ' + r.status + ')'); }
    });
  });
}

// Does `alt`'s website forward to `primary`'s (same organisation)?
function _sndrSameSiteAsync(alt, primary) {
  return new Promise(function(resolve) {
    try {
      chrome.runtime.sendMessage({ type: 'CLIENT_SAME_SITE', alt: alt, primary: primary }, function(res) {
        if (chrome.runtime.lastError || !res) return resolve(false);
        resolve(!!res.same);
      });
    } catch (e) { resolve(false); }
  });
}

// Real @domain addresses found on the open web (searched by the SNDR server).
function _sndrDomainEmailsAsync(domain) {
  return new Promise(function(resolve) {
    try {
      chrome.runtime.sendMessage({ type: 'CLIENT_DOMAIN_EMAILS', domain: domain }, function(res) {
        if (chrome.runtime.lastError || !res || !res.ok) return resolve([]);
        resolve(res.emails || []);
      });
    } catch (e) { resolve([]); }
  });
}

// While emails are being found, the button shows one upbeat line to read
// instead of which source is being checked (sources stay behind the scenes).
// One line per search, kept short enough to fit the button.
var _FIND_QUOTES = [
  'Main character energy loading',
  'Manifesting replies rn',
  'It\'s giving hired',
  'Rejection? Just redirection',
  'Your dream job is typing…',
  'Plot twist: they reply',
  'Delulu is the solulu',
  'No cap, you\'ve got this',
  'Trust the process, bestie',
  'Your era of yeses starts now',
  'Shoot your shot',
  'Lowkey proud of you rn',
  'Big things loading…',
  'Inbox about to be busy',
  'Glow up, career edition',
  'This is your sign to keep going',
  'Hustle now, flex later',
  'Built different, apply different',
];
var _findQuote = null;

function _findBtnStage() {
  var btn = document.getElementById('btn-find-all');
  if (!btn) return;
  if (!_findQuote) _findQuote = _FIND_QUOTES[Math.floor(Math.random() * _FIND_QUOTES.length)];
  btn.disabled = true;
  btn.title = 'Finding emails for you…';
  btn.classList.add('is-finding');
  if (btn.getAttribute('data-quote') === _findQuote) return; // already showing — no flicker
  btn.setAttribute('data-quote', _findQuote);
  btn.innerHTML = '<span class="mi fb-sparkle" style="font-size:15px">auto_awesome</span>' + _escHtml(_findQuote);
}
function _findBtnDone(html) {
  _findQuote = null;
  var btn = document.getElementById('btn-find-all');
  if (!btn) return;
  btn.classList.remove('is-finding');
  btn.removeAttribute('data-quote');
  btn.title = '';
  btn.innerHTML = html;
  btn.disabled = false;
}
function _setCard(c, html) {
  var el = document.getElementById('fcr-' + _safeId(c.id || c.profileUrl || c.name));
  if (el) el.innerHTML = html;
}

// "Bistro by Blinkit" -> "Blinkit", "Swiggy Instamart, a Swiggy company" ->
// "Swiggy": the parent company named in a sub-brand's name, or null.
function _parentBrand(name) {
  var n = String(name || '').trim();
  var m = /^.+?\s+(?:by|from|powered by)\s+(.+)$/i.exec(n) || /,?\s+an?\s+(.+?)\s+(?:company|brand|venture)\s*$/i.exec(n);
  var p = m ? m[1].replace(/\s*\(.*\)\s*$/, '').trim() : '';
  return p.length >= 2 && p.toLowerCase() !== n.toLowerCase() ? p : null;
}

// Finds ONE company's email domain and format.
// RocketReach-style results ("The most common Varaha email format is
// [first].[last] (ex. jane.doe@varaha.earth), used by 72.9%") are the primary
// source for both the email domain and the format: when they answer for this
// company, that answer is used and nothing else overrides it. Only companies
// they don't cover fall back to: a saved result from another source → real
// employees checked against the company's mail system → real @domain
// addresses on the web → the most common format (cards marked "unverified").
// Applies the result to that company's contacts (opts.contacts).
// Returns { count, total, unverified }, or null on failure.
async function _sndrBulkFind(domain, company, opts) {
  opts = opts || {};
  var contacts = (opts.contacts || window._findContacts || []).filter(function(c){ return c.name; });
  if (!contacts.length) return null;
  var names = contacts.map(function(c){ return c.name; });
  var stage = _findBtnStage;

  var best = null;  // the answer emails are generated from
  // Best non-RocketReach candidate, used only if RocketReach has no answer.
  var fallback = { pattern: opts.pattern || null, source: opts.source || null, confidence: opts.pattern ? (opts.confidence || 'low') : null };
  function consider(p, src, conf) {
    if (p && _confBetter(conf, fallback.confidence)) fallback = { pattern: p, source: src, confidence: conf };
  }
  var strongClaim = function(conf) { return conf === 'high' || conf === 'medium'; };
  // A RocketReach answer: used as-is, and saved so every later lookup of
  // this domain (by anyone) gets it instantly.
  function useRocketReach(p, conf, sample) {
    best = { pattern: p, source: 'client_search', confidence: conf };
    _post('/finder/report-pattern', { domain: domain, pattern: p, sampleEmail: sample || null, confidence: conf }).catch(function() {});
  }

  // 1. A saved RocketReach answer for this domain is used directly.
  try {
    stage();
    var d1 = await _post('/finder/company-lookup', { domain: domain, company: company || '', domainSource: opts.domainSource || undefined, country: _countryName() || undefined });
    var src1 = (d1.source || '').replace('_cache', '');
    if (src1 === 'client_search' && d1.pattern && strongClaim(d1.confidence)) {
      best = { pattern: d1.pattern, source: src1, confidence: d1.confidence };
    } else {
      consider(d1.pattern, src1, d1.confidence || 'low');
    }
  } catch (e) {
    _setStatus('<span style="color:#ba1a1a">Can\'t reach the SNDR server — please try again in a minute.</span>');
    return null;
  }

  // 2. RocketReach-style results — the primary source. A sub-brand ("Bistro
  // by Blinkit") is searched under its own name first, then its parent's
  // ("Blinkit"), whose email its staff usually share.
  var searchNames = [company];
  var parent = _parentBrand(company);
  if (parent) searchNames.push(parent);
  for (var si = 0; si < searchNames.length && !best && searchNames[si]; si++) {
    stage();
    var rr = await _sndrClientSearchAsync(searchNames[si], domain);
    if (rr && rr.pattern && strongClaim(rr.confidence)) {
      useRocketReach(rr.pattern, rr.confidence, rr.sampleEmail);
    } else if (rr && rr.pattern) {
      consider(rr.pattern, 'client_search', 'low');
    } else if (rr && rr.alternates && rr.alternates.length) {
      // RocketReach lists this company's emails under a different domain
      // than ours — the company emails from another domain than its website
      // (zepto.com site, zeptonow.com email), or our domain was only guessed
      // from the name. Take the entry that is THIS company:
      //  • its website forwards to the company's own site, or
      //  • with no LinkedIn website to compare against, its company name
      //    matches exactly ("Varaha Email Format | varaha.earth Emails").
      var strongDomain = opts.domainSource === 'linkedin';
      for (var ai = 0; ai < Math.min(rr.alternates.length, 3) && !best; ai++) {
        var alt = rr.alternates[ai];
        stage();
        var accept = (!strongDomain && alt.exactName) || await _sndrSameSiteAsync(alt.domain, domain);
        if (!accept) continue;
        var d2 = null;
        try { d2 = await _post('/finder/company-lookup', { domain: alt.domain, company: company || '', domainSource: 'linkedin', country: _countryName() || undefined }); } catch (e) {}
        if (!d2 || d2.domain !== alt.domain) continue; // doesn't receive email
        domain = alt.domain;
        fallback = { pattern: null, source: null, confidence: null };
        var src2 = (d2.source || '').replace('_cache', '');
        if (alt.pattern && strongClaim(alt.confidence)) useRocketReach(alt.pattern, alt.confidence, alt.sampleEmail);
        else if (src2 === 'client_search' && d2.pattern && strongClaim(d2.confidence)) best = { pattern: d2.pattern, source: src2, confidence: d2.confidence };
        else { consider(alt.pattern, 'client_search', 'low'); consider(d2.pattern, src2, d2.confidence || 'low'); break; }
      }
    }
  }

  // 3. Fallbacks — only for companies RocketReach has no answer for.
  if (!best) {
    if (fallback.confidence !== 'high') {
      stage();
      try {
        var v = await _post('/finder/verify-pattern', { domain: domain, names: names });
        consider(v.pattern, 'verified', 'high');
      } catch (e) {}
    }
    if (fallback.confidence !== 'high') {
      stage();
      var webEmails = await _sndrDomainEmailsAsync(domain);
      if (webEmails.length) {
        try {
          var inf = await _post('/finder/infer-from-emails', { domain: domain, emails: webEmails, names: names });
          consider(inf.pattern, 'web_evidence', inf.confidence || 'low');
        } catch (e) {}
      }
    }
    best = fallback;
  }

  if (opts.saveHint) {
    var newHint = { company: company, domain: domain, pattern: best.pattern, source: best.source, confidence: best.confidence, domainSource: opts.domainSource || null, country: _countryName(), searchId: opts.searchId, pageKey: opts.pageKey };
    // Keep the roles from the same search, so the LinkedIn panel can still
    // offer them if the user goes back for more people.
    _getHint(function(old) {
      if (old && old.searchId === opts.searchId && old.positions) newHint.positions = old.positions;
      _setHint(newHint);
    });
  }

  try {
    stage();
    var gen = await _post('/finder/generate-emails', { domain: domain, pattern: best.pattern, names: names, company: company });
    var unverified = !!gen.guess || best.confidence === 'low';
    _applyEmailResults(gen.emails || [], best.source, unverified, contacts);
    return { count: (gen.emails || []).filter(function(e){ return e.email; }).length, total: contacts.length, unverified: unverified };
  } catch (e) {
    _setStatus('<span style="color:#ba1a1a">Can\'t reach the SNDR server — please try again in a minute.</span>');
    return null;
  }
}

// Contacts from different searches (companies) can sit in the list together.
// Each search is found separately with its own domain and format — applying
// one company's domain to everyone gave earlier companies' contacts wrong
// addresses. Contacts saved before search IDs existed group by company name.
function _groupKey(c) {
  return c.searchId ? 's:' + c.searchId : 'c:' + String(c.company || '').trim().toLowerCase();
}

async function _sndrFindAll(hint) {
  var all = (window._findContacts || []).filter(function(c){ return c.name; });
  if (!all.length) return;
  hint = hint || {};

  var curKey = hint.searchId ? 's:' + hint.searchId : (hint.company ? 'c:' + hint.company.trim().toLowerCase() : null);
  var groups = {}, order = [];
  all.forEach(function(c) {
    var k = _groupKey(c);
    if (!groups[k]) { groups[k] = { contacts: [], company: c.company || '' }; order.push(k); }
    groups[k].contacts.push(c);
  });
  order.sort(function(a, b) { return a === curKey ? -1 : (b === curKey ? 1 : 0); });

  var found = 0, anyUnverified = false;
  for (var i = 0; i < order.length; i++) {
    var g = groups[order[i]];
    var isCurrent = order[i] === curKey;
    var company = (isCurrent && hint.company) || g.company;
    var base = { contacts: g.contacts, saveHint: isCurrent, searchId: isCurrent ? hint.searchId : undefined, pageKey: isCurrent ? hint.pageKey : undefined };
    var res = null;

    if (isCurrent && hint.domain) {
      base.pattern = hint.pattern; base.source = hint.source; base.confidence = hint.confidence; base.domainSource = hint.domainSource;
      res = await _sndrBulkFind(hint.domain, company, base);
    } else if (!company) {
      g.contacts.forEach(function(c) { _setCard(c, '<span class="fc-pending" style="color:#e67e00">Company unknown</span>'); });
    } else {
      _findBtnStage();
      var d = null;
      try { d = await _post('/finder/company-lookup', { company: company, country: (isCurrent && hint.country) || _countryName() || undefined }); } catch (e) {}
      if (!d || !d.domain) {
        g.contacts.forEach(function(c) { _setCard(c, '<span class="fc-pending" style="color:#e67e00" title="Couldn\'t determine this company\'s email domain">Domain not found</span>'); });
        if (isCurrent) {
          sndrShowDomainSection([{ _domain: null }]);
          _setStatus('<span style="color:#e67e00">Couldn\'t find ' + _escHtml(company) + '\'s email domain. Enter it above (e.g. company.com) and click Generate.</span>');
        }
      } else {
        base.pattern = d.pattern || null; base.source = (d.source || '').replace('_cache', '') || null; base.confidence = d.confidence || null;
        res = await _sndrBulkFind(d.domain, company, base);
      }
    }
    if (res) { found += res.count; anyUnverified = anyUnverified || res.unverified; }
  }
  _findBtnDone('<span class="mi" style="font-size:15px">check_circle</span>' + found + '/' + all.length + (anyUnverified ? ' emails (some unverified)' : ' emails found'));
  if (typeof window.sndrTrack === 'function') window.sndrTrack('emails_found', { company: hint.company || (order.length > 1 ? order.length + ' companies' : (groups[order[0]] || {}).company || ''), found: found, total: all.length, unverified: anyUnverified });
}

// Override dashboard-app.js's loadFindScreen with the ONE email-finding
// pipeline: read finderHint (normally already set by LinkedIn itself — see
// linkedin.js's reportCompanyDomainFromUrl, which resolves the domain from
// the actual company page opened, not a guess from typed text) and run the
// bulk finder. If no hint exists yet (e.g. LinkedIn hasn't been opened for
// this company, or the lookup couldn't resolve one), fall back to resolving
// the domain from the typed company name directly — same bulk pipeline
// either way, never a separate/legacy code path.
// This must run BEFORE the user navigates to the Find tab.
// Since finder-card.js loads after dashboard-app.js, window.loadFindScreen exists now.
(function overrideLoadFindScreen() {
  var _origLoad = window.loadFindScreen;
  if (typeof _origLoad !== 'function') return;

  window.loadFindScreen = function() {
    // Step 1: still render contact cards using original logic
    if (typeof chrome === 'undefined' || !chrome.storage) {
      if (typeof window.renderFindEmpty === 'function') window.renderFindEmpty();
      return;
    }
    chrome.storage.local.get(['extractedContacts'], function(data) {
      window._findContacts = typeof window.onlySavedPeople === 'function'
        ? window.onlySavedPeople(data.extractedContacts)
        : (data.extractedContacts || []);
      if (typeof window.renderFindScreen === 'function') window.renderFindScreen();

      if (!window._findContacts.length) return;

      // Step 2: find emails for every search (company) in the list
      _getHint(function(hint) {
        var ci = document.getElementById('fi-company');
        if (ci && hint && hint.company && !ci.value) ci.value = hint.company;
        // Cards need to render first.
        setTimeout(function() { _sndrFindAll(hint); }, 400);
      });
    });
  };
})();

// ─────────────────────────────────────────────────────────────────────────────
// BUILD LINKEDIN URL
// ─────────────────────────────────────────────────────────────────────────────
// positions may be a single string (legacy) or an array of position strings.
// Multiple positions are combined with LinkedIn boolean OR, e.g.
//   "HR Manager" OR "Talent Acquisition" OR Recruiter
// Fallback destination only — offered as "Not listed?" when LinkedIn's
// company search doesn't show the right company (see linkedin.js).
function sndrBuildLIUrl(co, positions, country) {
  var posList = Array.isArray(positions) ? positions : (positions ? [positions] : []);
  posList = posList.map(function(p){ return (p||'').trim(); }).filter(Boolean);
  // Quote multi-word phrases so LinkedIn treats them as one term in the OR.
  function term(p){ return /\s/.test(p) ? '"' + p + '"' : p; }
  var posKw = posList.length === 1
    ? posList[0]
    : posList.map(term).join(' OR ');

  var geo = '';
  if      (country === 'IN') geo = '&geoUrn=%5B%22102713980%22%5D';
  else if (country === 'US') geo = '&geoUrn=%5B%22103644278%22%5D';
  else if (country === 'GB') geo = '&geoUrn=%5B%22101165590%22%5D';
  else if (country === 'SG') geo = '&geoUrn=%5B%22102454443%22%5D';
  else if (country === 'AE') geo = '&geoUrn=%5B%22104305776%22%5D';

  var kw = posKw ? (posKw + ' ' + co) : co;
  return 'https://www.linkedin.com/search/results/people/?keywords=' + encodeURIComponent(kw) + '&origin=FACETED_SEARCH' + geo;
}

// ─────────────────────────────────────────────────────────────────────────────
// DOMAIN SECTION UI — the resolved domain is always auto-selected (there is
// only ever one real candidate for a given company search), so this just
// shows it pre-filled in the manual input rather than asking the user to
// click a card with a single, non-optional choice on it. The input stays
// editable so a domain can still be overridden by hand if needed.
// ─────────────────────────────────────────────────────────────────────────────
function sndrShowDomainSection(opts) {
  var ds = document.getElementById('fi-domain-section');
  var mi = document.getElementById('fi-domain-manual');
  var gb = document.getElementById('fi-generate-btn');
  if (!ds) return;
  ds.style.display = 'block';
  var domain = (opts && opts[0] && opts[0]._domain) || null;
  _sndrDom = domain;
  if (mi) mi.value = domain || '';
  if (gb) gb.disabled = !domain;
}

// ─────────────────────────────────────────────────────────────────────────────
// INIT — wire up input events
// ─────────────────────────────────────────────────────────────────────────────
function sndrFiInit() {
  var mi = document.getElementById('fi-domain-manual');
  var gb = document.getElementById('fi-generate-btn');

  // ── Position: chip-style multi-input ──────────────────────────────────────
  var posInput = document.getElementById('fi-position');
  var posBox   = document.getElementById('fi-pos-box');
  if (posBox && posInput) {
    posBox.addEventListener('click', function() { posInput.focus(); });
    posInput.addEventListener('focus', function() { posBox.classList.add('focus'); });
    posInput.addEventListener('blur',  function() { posBox.classList.remove('focus'); _addPos(posInput.value); posInput.value=''; });
    posInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ',' ) {
        e.preventDefault(); _addPos(posInput.value); posInput.value='';
      } else if (e.key === 'Backspace' && !posInput.value && _fiPositions.length) {
        _fiPositions.pop(); _renderPosChips();
      }
    });
    // Support typing/pasting comma-separated lists
    posInput.addEventListener('input', function() {
      if (posInput.value.indexOf(',') !== -1) {
        posInput.value.split(',').forEach(function(part){ _addPos(part); });
        posInput.value='';
      }
    });
  }

  if (mi) {
    mi.addEventListener('input', function() {
      if (mi.value.trim()) {
        _sndrDom = mi.value.trim(); if (gb) gb.disabled = false;
      } else { _sndrDom = null; if (gb) gb.disabled = true; }
    });
  }

  // Restore last session hint — silently, same as a fresh lookup: no
  // domain/pattern text shown anywhere.
  _getHint(function(hint) {
    if (!hint) return;
    var ci2 = document.getElementById('fi-company');
    if (hint.company && ci2 && !ci2.value) ci2.value = hint.company;
    if (hint.domain) {
      _sndrDom = hint.domain;
      _sndrPattern = hint.pattern || null;
      _sndrSrc = hint.source || null;
      if (hint.pattern) _setStatus('<span style="color:#059669">Ready — click Open LinkedIn &amp; Extract Names.</span>');
    }
  });
}

if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', sndrFiInit); }
else { sndrFiInit(); }

// ─────────────────────────────────────────────────────────────────────────────
// LINKEDIN BUTTON — belt-and-suspenders binding
// ─────────────────────────────────────────────────────────────────────────────
(function bindLinkedInBtn() {
  function attach() {
    var btn = document.getElementById('fi-linkedin-btn');
    if (btn && !btn._sndrBound) {
      btn._sndrBound = true;
      btn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); window.sndrOpenLinkedIn(); });
    }
    // The Generate button relied on an inline onclick, which the extension CSP
    // (script-src 'self') blocks — bind it here like the LinkedIn button.
    var gbtn = document.getElementById('fi-generate-btn');
    if (gbtn && !gbtn._sndrBound) {
      gbtn._sndrBound = true;
      gbtn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); window.sndrGenerateEmails(); });
    }
  }
  attach();
  // Also re-attach whenever Find tab is shown
  var _g = window.goNav;
  if (typeof _g === 'function') {
    window.goNav = function(n) { _g(n); if (n==='find') setTimeout(attach, 100); };
  } else {
    Object.defineProperty(window, 'goNav', {
      configurable: true,
      set: function(fn) {
        var w = function(n) { fn(n); if (n==='find') setTimeout(attach, 100); };
        Object.defineProperty(window, 'goNav', { value: w, writable: true, configurable: true });
      }
    });
  }
})();