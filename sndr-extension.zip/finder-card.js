// ── SNDR Finder Card ─────────────────────────────────────────────────────────
// Handles: company autocomplete, backend email-pattern lookup (100% free —
// SQLite cache / email-format.com / SMTP probe / site-scrape+search, no paid
// provider), LinkedIn redirect, and bulk email generation for all extracted
// contacts.
// ─────────────────────────────────────────────────────────────────────────────

var _sndrSel      = null;   // selected autocomplete company object
var _sndrDom      = null;   // selected domain for manual generate button
var _sndrPattern  = null;   // email pattern fetched from the backend (e.g. {first}_{last})
var _sndrSrc      = null;   // which free source resolved the pattern (emailformat/smtp/websearch/cache/…)
var _sndrAcTimer  = null;
var _fiPositions  = [];     // chips: multiple positions to filter LinkedIn People by

var _API = window.API_URL || 'https://api.sndr.co.in';

// HTML-escape dynamic (server/scraped) data before interpolating into innerHTML.
function _escHtml(s){ return String(s==null?'':s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

// ── safeId: same as dashboard-app.js ─────────────────────────────────────────
function _safeId(str) { return (str || '').replace(/[^a-z0-9]/gi, ''); }

// ── Position chips (multi-select) ─────────────────────────────────────────────
function _renderPosChips() {
  var box = document.getElementById('fi-pos-chips');
  if (!box) return;
  box.innerHTML = '';
  _fiPositions.forEach(function(p, i) {
    var chip = document.createElement('span');
    chip.className = 'fi-pos-chip';
    chip.innerHTML = '<span>' + _escHtml(p) + '</span>';
    var x = document.createElement('button');
    x.type = 'button'; x.setAttribute('aria-label', 'Remove'); x.textContent = '×';
    x.addEventListener('click', function(e) { e.stopPropagation(); _fiPositions.splice(i, 1); _renderPosChips(); });
    chip.appendChild(x);
    box.appendChild(chip);
  });
  var hint = document.getElementById('fi-pos-hint');
  if (hint) hint.style.display = _fiPositions.length ? 'none' : '';
}
function _addPos(val) {
  val = (val || '').trim();
  if (!val) return;
  // de-dupe case-insensitively
  var exists = _fiPositions.some(function(p){ return p.toLowerCase() === val.toLowerCase(); });
  if (!exists) _fiPositions.push(val);
  _renderPosChips();
}
// All positions to filter by — committed chips plus any half-typed text still in the box.
function _collectPositions() {
  var inp = document.getElementById('fi-position');
  var pending = inp ? inp.value.trim() : '';
  var list = _fiPositions.slice();
  if (pending && !list.some(function(p){ return p.toLowerCase() === pending.toLowerCase(); })) list.push(pending);
  return list;
}

// ── chrome.storage helper ─────────────────────────────────────────────────────
function _getHint(cb) {
  try { chrome.storage.local.get(['finderHint'], function(d) { cb(d.finderHint || null); }); }
  catch(e) { cb(null); }
}
function _setHint(obj) {
  try { chrome.storage.local.set({ finderHint: obj }); } catch(e) {}
}

// ── Status helpers ────────────────────────────────────────────────────────────
function _setStatus(html) {
  var el = document.getElementById('fi-gen-status'); if (el) el.innerHTML = html;
}
function _setBtn(id, html, disabled) {
  var el = document.getElementById(id);
  if (el) { el.innerHTML = html; el.disabled = !!disabled; }
}

// ─────────────────────────────────────────────────────────────────────────────
// DOMAIN PATTERN LOOKUP — called when company is selected (or pattern not in AC)
// ─────────────────────────────────────────────────────────────────────────────
function sndrLookupDomain(domain, company, knownPattern, knownSample) {
  if (!domain) return;

  sndrShowDomainSection([{ _domain: domain, name: company || domain }]);

  // If pattern was already returned by autocomplete, use it immediately — no extra API call
  if (knownPattern) {
    _sndrPattern = knownPattern;
    _sndrSrc = 'cache';
    _setHint({ company: company || '', domain: domain, pattern: knownPattern, sampleEmail: knownSample || null, source: _sndrSrc });
    var s = knownSample ? ' &nbsp;·&nbsp; e.g. <strong>' + _escHtml(knownSample) + '</strong>' : '';
    _setStatus('<span style="color:#059669">✓ Pattern: <strong>' + _escHtml(knownPattern) + '@' + _escHtml(domain) + '</strong>' + s + '</span>');
    return;
  }

  // No pattern yet — resolve it via the backend (SQLite cache → email-format.com →
  // SMTP probe → site-scrape/search — 100% free, no paid provider involved)
  _setStatus('<span style="color:var(--ol)">Looking up email pattern for <strong>' + _escHtml(domain) + '</strong>…</span>');
  _setHint({ company: company || '', domain: domain, pattern: null });

  fetch(_API + '/finder/company-lookup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ domain: domain, company: company || '' })
  })
  .then(function(r) { return r.json(); })
  .then(function(data) {
    _sndrPattern = data.pattern || null;
    _sndrSrc = (data.source || '').replace('_cache', '') || null;
    _setHint({ company: company || '', domain: domain, pattern: _sndrPattern, sampleEmail: data.sampleEmail || null, source: _sndrSrc });

    if (_sndrPattern) {
      var sample = data.sampleEmail ? ' &nbsp;·&nbsp; e.g. <strong>' + _escHtml(data.sampleEmail) + '</strong>' : '';
      _setStatus(
        '<span style="color:#059669">✓ Pattern: <strong>' + _escHtml(_sndrPattern) + '@' + _escHtml(domain) + '</strong>' +
        sample + '</span>'
      );
    } else {
      _setStatus('<span style="color:#e67e00">⚠ No pattern found for <strong>' + _escHtml(domain) +
        '</strong>. Common formats will be tried.</span>');
    }
  })
  .catch(function() {
    _setStatus('<span style="color:#ba1a1a">Backend offline — start the server.</span>');
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// OPEN LINKEDIN
// ─────────────────────────────────────────────────────────────────────────────
window.sndrOpenLinkedIn = function() {
  var co = (document.getElementById('fi-company') || {value:''}).value.trim();
  var positions = _collectPositions();
  var cv = (document.getElementById('fi-country')  || {value:'IN'}).value;
  var ci = document.getElementById('fi-company');
  if (!co) {
    if (ci) {
      ci.style.borderColor = '#ba1a1a'; ci.style.boxShadow = '0 0 0 3px rgba(186,26,26,.15)'; ci.focus();
      setTimeout(function() { ci.style.borderColor=''; ci.style.boxShadow=''; }, 1800);
    }
    return;
  }

  var domain = (_sndrSel && _sndrSel._domain) || null;
  _setHint({ company: co, domain: domain, pattern: _sndrPattern, source: _sndrSrc });
  var url = sndrBuildLIUrl(co, positions, cv, domain);

  // Visual feedback on button
  var lb = document.getElementById('fi-linkedin-btn');
  if (lb) { lb.style.opacity='0.7'; lb.style.pointerEvents='none'; setTimeout(function(){ lb.style.opacity=''; lb.style.pointerEvents=''; }, 2500); }

  // Always show fallback link
  _setStatus('Opening LinkedIn… <a href="' + url + '" target="_blank" rel="noopener noreferrer" ' +
    'style="color:var(--p);text-decoration:underline;font-weight:600">Click here if nothing opens</a>');

  // 4-layer open strategy
  var done = false;
  try { chrome.runtime.sendMessage({ type: 'OPEN_TAB', url: url }, function(res) { if (!chrome.runtime.lastError && res && res.ok) done = true; }); } catch(e) {}
  setTimeout(function() { if (done) return; try { chrome.tabs.create({ url: url }); done=true; } catch(e) {} }, 150);
  setTimeout(function() { if (done) return; try { var w=window.open(url,'_blank'); if(w) done=true; } catch(e) {} }, 300);
  setTimeout(function() {
    if (done) return;
    var a=document.createElement('a'); a.href=url; a.target='_blank'; a.rel='noopener noreferrer';
    document.body.appendChild(a); a.click(); setTimeout(function(){ a.parentNode&&a.parentNode.removeChild(a); }, 500);
  }, 450);
};

// ─────────────────────────────────────────────────────────────────────────────
// GENERATE EMAILS (manual — uses selected domain card or typed domain)
// ─────────────────────────────────────────────────────────────────────────────
window.sndrGenerateEmails = function() {
  var mi     = document.getElementById('fi-domain-manual');
  var domain = _sndrDom || (mi ? mi.value.trim() : '');
  if (!domain) return;
  var names = (window._findContacts || []).map(function(c){ return c.name; }).filter(Boolean);
  if (!names.length) {
    _setStatus('<span style="color:#ba1a1a">No contacts yet — go to LinkedIn and scroll the People page first.</span>');
    return;
  }
  _setBtn('fi-generate-btn', 'Generating…', true);
  _setStatus('Generating ' + names.length + ' emails for <strong>' + _escHtml(domain) + '</strong>…');
  var companyName = (_sndrSel && _sndrSel.name) || '';
  fetch(_API + '/finder/generate-emails', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ domain: domain, pattern: _sndrPattern, names: names, company: companyName })
  }).then(function(r){ return r.json(); }).then(function(d){
    _setBtn('fi-generate-btn', 'Generate Emails', false);
    _applyEmailResults(d.emails || [], d.source || 'generated');
    _setStatus('<span style="color:#059669">✓ Generated ' + (d.found||0) + ' emails</span>');
  }).catch(function(){
    _setBtn('fi-generate-btn', 'Generate Emails', false);
    _setStatus('<span style="color:#ba1a1a">Backend offline.</span>');
  });
};

// ─────────────────────────────────────────────────────────────────────────────
// BULK FINDER — runs when Find tab opens (overrides autoFindAll)
// ─────────────────────────────────────────────────────────────────────────────
function _applyEmailResults(emails, src) {
  var contacts = window._findContacts || [];
  emails.forEach(function(e) {
    if (!e.email) return;
    var c   = contacts.find(function(x){ return x.name === e.name; });
    var id  = c ? (c.id || c.profileUrl || e.name) : e.name;
    var sid = _safeId(id);
    var el  = document.getElementById('fcr-' + sid);
    var srcLabel = src || 'pattern';
    if (el) el.innerHTML = '<span class="fc-email">' + _escHtml(e.email) + '</span>' +
      '<span class="fc-src fc-src-' + _escHtml(srcLabel) + '">' + _escHtml(srcLabel) + '</span>';
    if (window._emailResults && id) window._emailResults[id] = { email: e.email, source: srcLabel };
  });
  if (typeof window._updateFindActions === 'function') window._updateFindActions();
}

async function _sndrBulkFind(domain, pattern, company, knownSrc) {
  var contacts = window._findContacts || [];
  if (!contacts.length) return;

  var btn = document.getElementById('btn-find-all');
  function setBtn(html, dis) { if (btn) { btn.innerHTML=html; btn.disabled=!!dis; } }

  setBtn('<span class="mi" style="font-size:15px">hourglass_top</span>Getting pattern…', true);

  // If we already have the pattern (looked up when company was selected), skip company-lookup
  var pat    = pattern || null;
  var sample = null;
  var src    = knownSrc || 'cache';

  if (!pat) {
    _setStatus('Looking up <strong>' + _escHtml(domain) + '</strong> email pattern…');
    try {
      var r1 = await fetch(_API + '/finder/company-lookup', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: domain, company: company || '' })
      });
      var d1 = await r1.json();
      pat    = d1.pattern || null;
      sample = d1.sampleEmail || null;
      src    = (d1.source || 'pattern').replace('_cache','');
    } catch(e) {
      _setStatus('<span style="color:#ba1a1a">Backend offline — run <strong>npm start</strong> in the backend folder.</span>');
      setBtn('<span class="mi" style="font-size:15px">search</span>Find All Emails', false);
      return;
    }
  }

  if (!pat) {
    _setStatus('<span style="color:#e67e00">No email pattern found for <strong>' + _escHtml(domain) +
      '</strong>. Type domain manually above and click Generate.</span>');
    setBtn('<span class="mi" style="font-size:15px">search</span>Find All Emails', false);
    return;
  }

  var sampleTxt = sample ? ' &nbsp;·&nbsp; e.g. <strong>' + _escHtml(sample) + '</strong>' : '';
  _setStatus('✓ Pattern: <strong>' + _escHtml(pat) + '@' + _escHtml(domain) + '</strong>' + sampleTxt);
  setBtn('<span class="mi" style="font-size:15px">hourglass_top</span>Generating ' + contacts.length + ' emails…', true);

  // Generate all emails
  var names = contacts.map(function(c){ return c.name; }).filter(Boolean);
  try {
    var r2  = await fetch(_API + '/finder/generate-emails', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: domain, pattern: pat, names: names, company: company })
    });
    var gen = await r2.json();
    var found = (gen.emails||[]).filter(function(e){ return e.email; }).length;
    _applyEmailResults(gen.emails || [], src);
    setBtn('<span class="mi" style="font-size:15px">check_circle</span>' + found + '/' + contacts.length + ' emails found', false);
    _setStatus('✓ <strong>' + _escHtml(pat) + '@' + _escHtml(domain) + '</strong>' + sampleTxt +
      ' &nbsp;·&nbsp; <strong>' + found + '</strong> emails generated');
  } catch(e) {
    _setStatus('<span style="color:#ba1a1a">Backend offline.</span>');
    setBtn('<span class="mi" style="font-size:15px">search</span>Find All Emails', false);
  }
}

// Override dashboard-app.js loadFindScreen so OUR bulk finder runs instead of autoFindAll
// This must run BEFORE the user navigates to the Find tab.
// Since finder-card.js loads after dashboard-app.js, window.loadFindScreen exists now.
(function overrideLoadFindScreen() {
  var _origLoad = window.loadFindScreen;
  if (typeof _origLoad !== 'function') return;

  window.loadFindScreen = function() {
    // Step 1: still render contact cards using original logic
    if (typeof chrome === 'undefined' || !chrome.storage) {
      if (typeof window.renderFindEmpty === 'function') window.renderFindEmpty();
      return;
    }
    chrome.storage.local.get(['extractedContacts'], function(data) {
      window._findContacts = data.extractedContacts || [];
      if (typeof window.renderFindScreen === 'function') window.renderFindScreen();

      if (!window._findContacts.length) return;

      // Step 2: read finderHint to get domain+pattern
      _getHint(function(hint) {
        var domain  = hint && hint.domain   ? hint.domain   : null;
        var pattern = hint && hint.pattern  ? hint.pattern  : null;
        var company = hint && hint.company  ? hint.company  : '';
        var source  = hint && hint.source   ? hint.source   : null;

        if (domain) {
          // Pre-fill the finder card with the company info
          var ci = document.getElementById('fi-company');
          if (ci && company && !ci.value) ci.value = company;
          sndrShowDomainSection([{ _domain: domain, name: company || domain }]);

          // Run bulk find after a short delay (cards need to render first)
          window._finding = false;
          setTimeout(function() { _sndrBulkFind(domain, pattern, company, source); }, 400);
        } else {
          // No hint — fall back to original per-person finder
          if (typeof window._origAutoFindAll === 'function') {
            setTimeout(window._origAutoFindAll, 800);
          } else if (typeof _origLoad === 'function') {
            // Let original handle it
          }
        }
      });
    });
  };

  // Keep a reference to the original autoFindAll as backup
  window._origAutoFindAll = window.autoFindAll;
})();

// ─────────────────────────────────────────────────────────────────────────────
// BUILD LINKEDIN URL
// ─────────────────────────────────────────────────────────────────────────────
// positions may be a single string (legacy) or an array of position strings.
// Multiple positions are combined with LinkedIn boolean OR, e.g.
//   "HR Manager" OR "Talent Acquisition" OR Recruiter
// Used to jump straight to https://linkedin.com/company/{guessed-slug}/people/
// by deriving a slug from the domain (stripping the TLD, removing non-
// alphanumerics). That guess has no reliable relationship to a company's
// actual LinkedIn slug — confirmed concretely: Alvarez & Marsal's domain is
// alvarezandmarsal.com, guessing "alvarezandmarsal" as the slug, but their
// real LinkedIn slug is "alvarez-&-marsal" (it even keeps the ampersand).
// LinkedIn slugs are assigned independently of both company name and domain
// with no consistent pattern, so a wrong guess doesn't degrade gracefully —
// it lands on LinkedIn's "This page isn't available" dead end with no way
// back to real results from inside the extension. LinkedIn's own people
// search matches the company by name internally and always returns a valid
// results page, so that's the only path now — no more slug-guessing.
function sndrBuildLIUrl(co, positions, country, domain) {
  var posList = Array.isArray(positions) ? positions : (positions ? [positions] : []);
  posList = posList.map(function(p){ return (p||'').trim(); }).filter(Boolean);
  // Quote multi-word phrases so LinkedIn treats them as one term in the OR.
  function term(p){ return /\s/.test(p) ? '"' + p + '"' : p; }
  var posKw = posList.length === 1
    ? posList[0]
    : posList.map(term).join(' OR ');

  var geo = '';
  if      (country === 'IN') geo = '&geoUrn=%5B%22102713980%22%5D';
  else if (country === 'US') geo = '&geoUrn=%5B%22103644278%22%5D';
  else if (country === 'GB') geo = '&geoUrn=%5B%22101165590%22%5D';
  else if (country === 'SG') geo = '&geoUrn=%5B%22102454443%22%5D';
  else if (country === 'AE') geo = '&geoUrn=%5B%22104305776%22%5D';

  var kw = posKw ? (posKw + ' ' + co) : co;
  return 'https://www.linkedin.com/search/results/people/?keywords=' + encodeURIComponent(kw) + '&origin=FACETED_SEARCH' + geo;
}

// ─────────────────────────────────────────────────────────────────────────────
// DOMAIN SECTION UI — the resolved domain is always auto-selected (there is
// only ever one real candidate for a given company search), so this just
// shows it pre-filled in the manual input rather than asking the user to
// click a card with a single, non-optional choice on it. The input stays
// editable so a domain can still be overridden by hand if needed.
// ─────────────────────────────────────────────────────────────────────────────
function sndrShowDomainSection(opts) {
  var ds = document.getElementById('fi-domain-section');
  var mi = document.getElementById('fi-domain-manual');
  var gb = document.getElementById('fi-generate-btn');
  if (!ds) return;
  ds.style.display = 'block';
  var domain = (opts && opts[0] && opts[0]._domain) || null;
  _sndrDom = domain;
  if (mi) mi.value = domain || '';
  if (gb) gb.disabled = !domain;
}

// ─────────────────────────────────────────────────────────────────────────────
// AUTOCOMPLETE
// ─────────────────────────────────────────────────────────────────────────────
function sndrRenderAC(opts) {
  var ac = document.getElementById('fi-autocomplete'); if (!ac) return;
  if (!opts || !opts.length) { ac.style.display = 'none'; return; }
  ac.innerHTML = '';
  opts.slice(0, 8).forEach(function(o) {
    var div = document.createElement('div'); div.className = 'fi-opt';
    var logo = o.logo
      ? '<img class="fi-opt-logo" src="' + _escHtml(o.logo) + '" onerror="this.hidden=true">'
      : '<div class="fi-opt-logo-fb">' + _escHtml(((o.name||'?')[0]||'?').toUpperCase()) + '</div>';
    // Show pattern badge if the backend already returned it
    var patBadge = o.pattern
      ? '<span class="fi-opt-badge" style="background:#d1fae5;color:#065f46;font-size:10px">' + _escHtml(o.pattern) + '@' + _escHtml(o._domain) + '</span>'
      : '';
    div.innerHTML = logo +
      '<div style="flex:1;min-width:0"><div class="fi-opt-name">' + _escHtml(o.name||o._domain||'') + '</div>' +
      '<div class="fi-opt-desc">' + _escHtml(o.description||o._domain||'') + '</div></div>' +
      patBadge;
    div.addEventListener('mousedown', function(e) { e.preventDefault(); sndrSelectCo(o); });
    ac.appendChild(div);
  });
  ac.style.display = 'block';
}

function sndrSelectCo(o) {
  var ci = document.getElementById('fi-company'); var ac = document.getElementById('fi-autocomplete');
  if (ci) ci.value = o.name || o._domain || '';
  if (ac) ac.style.display = 'none';
  _sndrSel = o;
  // Pass pattern + sampleEmail if the backend already returned them in autocomplete
  if (o._domain) sndrLookupDomain(o._domain, o.name || '', o.pattern || null, o.sampleEmail || null);
}

// ─────────────────────────────────────────────────────────────────────────────
// INIT — wire up input events
// ─────────────────────────────────────────────────────────────────────────────
function sndrFiInit() {
  var ci = document.getElementById('fi-company');
  var mi = document.getElementById('fi-domain-manual');
  var gb = document.getElementById('fi-generate-btn');

  if (ci) {
    ci.addEventListener('input', function() {
      clearTimeout(_sndrAcTimer);
      _sndrSel = null; _sndrPattern = null;
      var q = ci.value.trim(); var ac = document.getElementById('fi-autocomplete'); if (!ac) return;
      if (q.length < 2) { ac.style.display='none'; return; }
      _sndrAcTimer = setTimeout(function() {
        var cv = (document.getElementById('fi-country')||{value:''}).value;
        fetch(_API + '/finder/autocomplete?q=' + encodeURIComponent(q) + '&country=' + encodeURIComponent(cv||''))
          .then(function(r){ return r.json(); }).then(sndrRenderAC).catch(function(){ ac.style.display='none'; });
      }, 280);
    });
  }

  document.addEventListener('mousedown', function(e) {
    var wrap = document.getElementById('fi-company-wrap'); var ac = document.getElementById('fi-autocomplete');
    if (ac && wrap && !wrap.contains(e.target)) ac.style.display = 'none';
  });

  // ── Position: chip-style multi-input ──────────────────────────────────────
  var posInput = document.getElementById('fi-position');
  var posBox   = document.getElementById('fi-pos-box');
  if (posBox && posInput) {
    posBox.addEventListener('click', function() { posInput.focus(); });
    posInput.addEventListener('focus', function() { posBox.classList.add('focus'); });
    posInput.addEventListener('blur',  function() { posBox.classList.remove('focus'); _addPos(posInput.value); posInput.value=''; });
    posInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ',' ) {
        e.preventDefault(); _addPos(posInput.value); posInput.value='';
      } else if (e.key === 'Backspace' && !posInput.value && _fiPositions.length) {
        _fiPositions.pop(); _renderPosChips();
      }
    });
    // Support typing/pasting comma-separated lists
    posInput.addEventListener('input', function() {
      if (posInput.value.indexOf(',') !== -1) {
        posInput.value.split(',').forEach(function(part){ _addPos(part); });
        posInput.value='';
      }
    });
  }

  if (mi) {
    mi.addEventListener('input', function() {
      if (mi.value.trim()) {
        _sndrDom = mi.value.trim(); if (gb) gb.disabled = false;
      } else { _sndrDom = null; if (gb) gb.disabled = true; }
    });
  }

  // Restore last session hint
  _getHint(function(hint) {
    if (!hint) return;
    var ci2 = document.getElementById('fi-company');
    if (hint.company && ci2 && !ci2.value) ci2.value = hint.company;
    if (hint.domain) {
      sndrShowDomainSection([{ _domain: hint.domain, name: hint.company || hint.domain }]);
      _sndrPattern = hint.pattern || null;
      if (hint.pattern) {
        var s = hint.sampleEmail ? ' &nbsp;·&nbsp; e.g. <strong>' + _escHtml(hint.sampleEmail) + '</strong>' : '';
        _setStatus('<span style="color:#059669">✓ Pattern: <strong>' + _escHtml(hint.pattern) + '@' + _escHtml(hint.domain) + '</strong>' + s + '</span>');
      }
    }
  });
}

if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', sndrFiInit); }
else { sndrFiInit(); }

// ─────────────────────────────────────────────────────────────────────────────
// LINKEDIN BUTTON — belt-and-suspenders binding
// ─────────────────────────────────────────────────────────────────────────────
(function bindLinkedInBtn() {
  function attach() {
    var btn = document.getElementById('fi-linkedin-btn');
    if (btn && !btn._sndrBound) {
      btn._sndrBound = true;
      btn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); window.sndrOpenLinkedIn(); });
    }
    // The Generate button relied on an inline onclick, which the extension CSP
    // (script-src 'self') blocks — bind it here like the LinkedIn button.
    var gbtn = document.getElementById('fi-generate-btn');
    if (gbtn && !gbtn._sndrBound) {
      gbtn._sndrBound = true;
      gbtn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); window.sndrGenerateEmails(); });
    }
  }
  attach();
  // Also re-attach whenever Find tab is shown
  var _g = window.goNav;
  if (typeof _g === 'function') {
    window.goNav = function(n) { _g(n); if (n==='find') setTimeout(attach, 100); };
  } else {
    Object.defineProperty(window, 'goNav', {
      configurable: true,
      set: function(fn) {
        var w = function(n) { fn(n); if (n==='find') setTimeout(attach, 100); };
        Object.defineProperty(window, 'goNav', { value: w, writable: true, configurable: true });
      }
    });
  }
})();