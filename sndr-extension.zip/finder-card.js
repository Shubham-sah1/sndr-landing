// ── SNDR Finder Card ─────────────────────────────────────────────────────────
// Handles: company autocomplete (Apollo), pattern lookup, LinkedIn redirect,
// and bulk email generation for all extracted contacts.
// ─────────────────────────────────────────────────────────────────────────────

var _sndrSel      = null;   // selected autocomplete company object
var _sndrDom      = null;   // selected domain for manual generate button
var _sndrPattern  = null;   // email pattern fetched from Apollo (e.g. {first}.{last})
var _sndrAcTimer  = null;

var _API = window.API_URL || 'https://sndr-f4rg.onrender.com';

// HTML-escape dynamic (server/Apollo/scraped) data before interpolating into innerHTML.
function _escHtml(s){ return String(s==null?'':s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

// ── safeId: same as dashboard-app.js ─────────────────────────────────────────
function _safeId(str) { return (str || '').replace(/[^a-z0-9]/gi, ''); }

// ── chrome.storage helper ─────────────────────────────────────────────────────
function _getHint(cb) {
  try { chrome.storage.local.get(['finderHint'], function(d) { cb(d.finderHint || null); }); }
  catch(e) { cb(null); }
}
function _setHint(obj) {
  try { chrome.storage.local.set({ finderHint: obj }); } catch(e) {}
}

// ── Status helpers ────────────────────────────────────────────────────────────
function _setStatus(html) {
  var el = document.getElementById('fi-gen-status'); if (el) el.innerHTML = html;
}
function _setBtn(id, html, disabled) {
  var el = document.getElementById(id);
  if (el) { el.innerHTML = html; el.disabled = !!disabled; }
}

// ─────────────────────────────────────────────────────────────────────────────
// APOLLO DOMAIN LOOKUP — called when company is selected (or pattern not in AC)
// ─────────────────────────────────────────────────────────────────────────────
function sndrLookupDomain(domain, company, knownPattern, knownSample) {
  if (!domain) return;

  sndrShowDomainSection([{ _domain: domain, name: company || domain }]);

  // If pattern was already returned by autocomplete, use it immediately — no extra API call
  if (knownPattern) {
    _sndrPattern = knownPattern;
    _setHint({ company: company || '', domain: domain, pattern: knownPattern, sampleEmail: knownSample || null });
    var s = knownSample ? ' &nbsp;·&nbsp; e.g. <strong>' + _escHtml(knownSample) + '</strong>' : '';
    _setStatus('<span style="color:#059669">✓ Pattern: <strong>' + _escHtml(knownPattern) + '@' + _escHtml(domain) + '</strong>' + s +
      ' <span style="color:var(--ol);font-size:11px">via Apollo</span></span>');
    return;
  }

  // No pattern yet — ask Apollo via backend
  _setStatus('<span style="color:var(--ol)">Looking up email pattern on Apollo for <strong>' + _escHtml(domain) + '</strong>…</span>');
  _setHint({ company: company || '', domain: domain, pattern: null });

  fetch(_API + '/finder/company-lookup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ domain: domain, company: company || '' })
  })
  .then(function(r) { return r.json(); })
  .then(function(data) {
    _sndrPattern = data.pattern || null;
    _setHint({ company: company || '', domain: domain, pattern: _sndrPattern, sampleEmail: data.sampleEmail || null });

    if (_sndrPattern) {
      var sample = data.sampleEmail ? ' &nbsp;·&nbsp; e.g. <strong>' + _escHtml(data.sampleEmail) + '</strong>' : '';
      _setStatus(
        '<span style="color:#059669">✓ Pattern: <strong>' + _escHtml(_sndrPattern) + '@' + _escHtml(domain) + '</strong>' +
        sample + ' <span style="color:var(--ol);font-size:11px">via Apollo</span></span>'
      );
    } else {
      _setStatus('<span style="color:#e67e00">⚠ No pattern found on Apollo for <strong>' + _escHtml(domain) +
        '</strong>. Common formats will be tried.</span>');
    }
  })
  .catch(function() {
    _setStatus('<span style="color:#ba1a1a">Backend offline — start the server.</span>');
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// OPEN LINKEDIN
// ─────────────────────────────────────────────────────────────────────────────
window.sndrOpenLinkedIn = function() {
  var co = (document.getElementById('fi-company') || {value:''}).value.trim();
  var po = (document.getElementById('fi-position') || {value:''}).value.trim();
  var cv = (document.getElementById('fi-country')  || {value:'IN'}).value;
  var ci = document.getElementById('fi-company');
  if (!co) {
    if (ci) {
      ci.style.borderColor = '#ba1a1a'; ci.style.boxShadow = '0 0 0 3px rgba(186,26,26,.15)'; ci.focus();
      setTimeout(function() { ci.style.borderColor=''; ci.style.boxShadow=''; }, 1800);
    }
    return;
  }

  var domain = (_sndrSel && _sndrSel._domain) || null;
  _setHint({ company: co, domain: domain, pattern: _sndrPattern });
  var url = sndrBuildLIUrl(co, po, cv, domain);

  // Visual feedback on button
  var lb = document.getElementById('fi-linkedin-btn');
  if (lb) { lb.style.opacity='0.7'; lb.style.pointerEvents='none'; setTimeout(function(){ lb.style.opacity=''; lb.style.pointerEvents=''; }, 2500); }

  // Always show fallback link
  _setStatus('Opening LinkedIn… <a href="' + url + '" target="_blank" rel="noopener noreferrer" ' +
    'style="color:var(--p);text-decoration:underline;font-weight:600">Click here if nothing opens</a>');

  // 4-layer open strategy
  var done = false;
  try { chrome.runtime.sendMessage({ type: 'OPEN_TAB', url: url }, function(res) { if (!chrome.runtime.lastError && res && res.ok) done = true; }); } catch(e) {}
  setTimeout(function() { if (done) return; try { chrome.tabs.create({ url: url }); done=true; } catch(e) {} }, 150);
  setTimeout(function() { if (done) return; try { var w=window.open(url,'_blank'); if(w) done=true; } catch(e) {} }, 300);
  setTimeout(function() {
    if (done) return;
    var a=document.createElement('a'); a.href=url; a.target='_blank'; a.rel='noopener noreferrer';
    document.body.appendChild(a); a.click(); setTimeout(function(){ a.parentNode&&a.parentNode.removeChild(a); }, 500);
  }, 450);
};

// ─────────────────────────────────────────────────────────────────────────────
// GENERATE EMAILS (manual — uses selected domain card or typed domain)
// ─────────────────────────────────────────────────────────────────────────────
window.sndrGenerateEmails = function() {
  var mi     = document.getElementById('fi-domain-manual');
  var domain = _sndrDom || (mi ? mi.value.trim() : '');
  if (!domain) return;
  var names = (window._findContacts || []).map(function(c){ return c.name; }).filter(Boolean);
  if (!names.length) {
    _setStatus('<span style="color:#ba1a1a">No contacts yet — go to LinkedIn and scroll the People page first.</span>');
    return;
  }
  _setBtn('fi-generate-btn', 'Generating…', true);
  _setStatus('Generating ' + names.length + ' emails for <strong>' + _escHtml(domain) + '</strong>…');
  fetch(_API + '/finder/generate-emails', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ domain: domain, pattern: _sndrPattern, names: names })
  }).then(function(r){ return r.json(); }).then(function(d){
    _setBtn('fi-generate-btn', 'Generate Emails', false);
    _applyEmailResults(d.emails || [], d.source || 'generated');
    _setStatus('<span style="color:#059669">✓ Generated ' + (d.found||0) + ' emails</span>');
  }).catch(function(){
    _setBtn('fi-generate-btn', 'Generate Emails', false);
    _setStatus('<span style="color:#ba1a1a">Backend offline.</span>');
  });
};

// ─────────────────────────────────────────────────────────────────────────────
// BULK FINDER — runs when Find tab opens (overrides autoFindAll)
// ─────────────────────────────────────────────────────────────────────────────
function _applyEmailResults(emails, src) {
  var contacts = window._findContacts || [];
  emails.forEach(function(e) {
    if (!e.email) return;
    var c   = contacts.find(function(x){ return x.name === e.name; });
    var id  = c ? (c.id || c.profileUrl || e.name) : e.name;
    var sid = _safeId(id);
    var el  = document.getElementById('fcr-' + sid);
    if (el) el.innerHTML = '<span class="fc-email">' + _escHtml(e.email) + '</span>' +
      '<span class="fc-src fc-src-hunter">' + _escHtml(src||'apollo') + '</span>';
    if (window._emailResults && id) window._emailResults[id] = { email: e.email, source: src||'apollo' };
  });
}

async function _sndrBulkFind(domain, pattern, company) {
  var contacts = window._findContacts || [];
  if (!contacts.length) return;

  var btn = document.getElementById('btn-find-all');
  function setBtn(html, dis) { if (btn) { btn.innerHTML=html; btn.disabled=!!dis; } }

  setBtn('<span class="mi" style="font-size:15px">hourglass_top</span>Getting pattern…', true);

  // If we already have the pattern (looked up when company was selected), skip company-lookup
  var pat    = pattern || null;
  var sample = null;
  var src    = 'apollo';

  if (!pat) {
    _setStatus('Asking Apollo for <strong>' + _escHtml(domain) + '</strong> email pattern…');
    try {
      var r1 = await fetch(_API + '/finder/company-lookup', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: domain, company: company || '' })
      });
      var d1 = await r1.json();
      pat    = d1.pattern || null;
      sample = d1.sampleEmail || null;
      src    = (d1.source || 'apollo').replace('_cache','');
    } catch(e) {
      _setStatus('<span style="color:#ba1a1a">Backend offline — run <strong>npm start</strong> in the backend folder.</span>');
      setBtn('<span class="mi" style="font-size:15px">search</span>Find All Emails', false);
      return;
    }
  } else {
    src = 'apollo';
  }

  if (!pat) {
    _setStatus('<span style="color:#e67e00">No email pattern found for <strong>' + _escHtml(domain) +
      '</strong>. Type domain manually above and click Generate.</span>');
    setBtn('<span class="mi" style="font-size:15px">search</span>Find All Emails', false);
    return;
  }

  var sampleTxt = sample ? ' &nbsp;·&nbsp; e.g. <strong>' + _escHtml(sample) + '</strong>' : '';
  _setStatus('✓ Pattern: <strong>' + _escHtml(pat) + '@' + _escHtml(domain) + '</strong>' + sampleTxt +
    ' <span style="color:var(--ol);font-size:11px">via ' + _escHtml(src) + '</span>');
  setBtn('<span class="mi" style="font-size:15px">hourglass_top</span>Generating ' + contacts.length + ' emails…', true);

  // Generate all emails
  var names = contacts.map(function(c){ return c.name; }).filter(Boolean);
  try {
    var r2  = await fetch(_API + '/finder/generate-emails', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: domain, pattern: pat, names: names })
    });
    var gen = await r2.json();
    var found = (gen.emails||[]).filter(function(e){ return e.email; }).length;
    _applyEmailResults(gen.emails || [], src);
    setBtn('<span class="mi" style="font-size:15px">check_circle</span>' + found + '/' + contacts.length + ' emails found', false);
    _setStatus('✓ <strong>' + _escHtml(pat) + '@' + _escHtml(domain) + '</strong>' + sampleTxt +
      ' &nbsp;·&nbsp; <strong>' + found + '</strong> emails generated' +
      ' <span style="color:var(--ol);font-size:11px">via ' + _escHtml(src) + '</span>');
  } catch(e) {
    _setStatus('<span style="color:#ba1a1a">Backend offline.</span>');
    setBtn('<span class="mi" style="font-size:15px">search</span>Find All Emails', false);
  }
}

// Override dashboard-app.js loadFindScreen so OUR bulk finder runs instead of autoFindAll
// This must run BEFORE the user navigates to the Find tab.
// Since finder-card.js loads after dashboard-app.js, window.loadFindScreen exists now.
(function overrideLoadFindScreen() {
  var _origLoad = window.loadFindScreen;
  if (typeof _origLoad !== 'function') return;

  window.loadFindScreen = function() {
    // Step 1: still render contact cards using original logic
    if (typeof chrome === 'undefined' || !chrome.storage) {
      if (typeof window.renderFindEmpty === 'function') window.renderFindEmpty();
      return;
    }
    chrome.storage.local.get(['extractedContacts'], function(data) {
      window._findContacts = data.extractedContacts || [];
      if (typeof window.renderFindScreen === 'function') window.renderFindScreen();

      if (!window._findContacts.length) return;

      // Step 2: read finderHint to get domain+pattern
      _getHint(function(hint) {
        var domain  = hint && hint.domain   ? hint.domain   : null;
        var pattern = hint && hint.pattern  ? hint.pattern  : null;
        var company = hint && hint.company  ? hint.company  : '';

        if (domain) {
          // Pre-fill the finder card with the company info
          var ci = document.getElementById('fi-company');
          if (ci && company && !ci.value) ci.value = company;
          sndrShowDomainSection([{ _domain: domain, name: company || domain }]);

          // Run bulk find after a short delay (cards need to render first)
          window._finding = false;
          setTimeout(function() { _sndrBulkFind(domain, pattern, company); }, 400);
        } else {
          // No hint — fall back to original per-person finder
          if (typeof window._origAutoFindAll === 'function') {
            setTimeout(window._origAutoFindAll, 800);
          } else if (typeof _origLoad === 'function') {
            // Let original handle it
          }
        }
      });
    });
  };

  // Keep a reference to the original autoFindAll as backup
  window._origAutoFindAll = window.autoFindAll;
})();

// ─────────────────────────────────────────────────────────────────────────────
// BUILD LINKEDIN URL
// ─────────────────────────────────────────────────────────────────────────────
function sndrBuildLIUrl(co, po, country, domain) {
  var slug = domain
    ? domain.replace(/\.(com|io|co|net|org|in|ai|co\.in|co\.uk|com\.au)$/i,'').replace(/\./g,'').toLowerCase().replace(/[^a-z0-9]/g,'')
    : co.toLowerCase().replace(/[^a-z0-9]/g,'');
  var geo = '';
  if      (country === 'IN') geo = '&geoUrn=%5B%22102713980%22%5D';
  else if (country === 'US') geo = '&geoUrn=%5B%22103644278%22%5D';
  else if (country === 'GB') geo = '&geoUrn=%5B%22101165590%22%5D';
  else if (country === 'SG') geo = '&geoUrn=%5B%22102454443%22%5D';
  else if (country === 'AE') geo = '&geoUrn=%5B%22104305776%22%5D';
  if (slug) {
    var u = 'https://www.linkedin.com/company/' + slug + '/people/';
    if (po) u += '?keywords=' + encodeURIComponent(po);
    return u;
  }
  var kw = po ? (po + ' at ' + co) : co;
  return 'https://www.linkedin.com/search/results/people/?keywords=' + encodeURIComponent(kw) + '&origin=FACETED_SEARCH' + geo;
}

// ─────────────────────────────────────────────────────────────────────────────
// DOMAIN SECTION UI
// ─────────────────────────────────────────────────────────────────────────────
function sndrShowDomainSection(opts) {
  var ds = document.getElementById('fi-domain-section');
  var dg = document.getElementById('fi-domain-grid');
  var gb = document.getElementById('fi-generate-btn');
  if (!ds || !dg) return;
  ds.style.display = 'block'; dg.innerHTML = ''; _sndrDom = null;
  if (gb) gb.disabled = true;
  opts.forEach(function(o) {
    if (!o._domain) return;
    var card = document.createElement('div'); card.className = 'fi-domain-card';
    card.innerHTML = '<div class="fi-dc-domain">' + _escHtml(o._domain) + '</div>' +
      '<div class="fi-dc-meta">' + (o._emailCount ? _escHtml(o._emailCount) + ' known emails' : _escHtml(o.description || '')) + '</div>';
    card.addEventListener('click', function() {
      document.querySelectorAll('.fi-domain-card').forEach(function(c){ c.classList.remove('sel'); });
      card.classList.add('sel'); _sndrDom = o._domain;
      var mi = document.getElementById('fi-domain-manual'); if (mi) mi.value = '';
      if (gb) gb.disabled = false;
    });
    dg.appendChild(card);
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// AUTOCOMPLETE
// ─────────────────────────────────────────────────────────────────────────────
function sndrRenderAC(opts) {
  var ac = document.getElementById('fi-autocomplete'); if (!ac) return;
  if (!opts || !opts.length) { ac.style.display = 'none'; return; }
  ac.innerHTML = '';
  opts.slice(0, 8).forEach(function(o) {
    var div = document.createElement('div'); div.className = 'fi-opt';
    var logo = o.logo
      ? '<img class="fi-opt-logo" src="' + _escHtml(o.logo) + '" onerror="this.hidden=true">'
      : '<div class="fi-opt-logo-fb">' + _escHtml(((o.name||'?')[0]||'?').toUpperCase()) + '</div>';
    // Show pattern badge if Apollo already returned it
    var patBadge = o.pattern
      ? '<span class="fi-opt-badge" style="background:#d1fae5;color:#065f46;font-size:10px">' + _escHtml(o.pattern) + '@' + _escHtml(o._domain) + '</span>'
      : '';
    div.innerHTML = logo +
      '<div style="flex:1;min-width:0"><div class="fi-opt-name">' + _escHtml(o.name||o._domain||'') + '</div>' +
      '<div class="fi-opt-desc">' + _escHtml(o.description||o._domain||'') + '</div></div>' +
      patBadge;
    div.addEventListener('mousedown', function(e) { e.preventDefault(); sndrSelectCo(o); });
    ac.appendChild(div);
  });
  ac.style.display = 'block';
}

function sndrSelectCo(o) {
  var ci = document.getElementById('fi-company'); var ac = document.getElementById('fi-autocomplete');
  if (ci) ci.value = o.name || o._domain || '';
  if (ac) ac.style.display = 'none';
  _sndrSel = o;
  // Pass pattern + sampleEmail if Apollo already returned them in autocomplete
  if (o._domain) sndrLookupDomain(o._domain, o.name || '', o.pattern || null, o.sampleEmail || null);
}

// ─────────────────────────────────────────────────────────────────────────────
// INIT — wire up input events
// ─────────────────────────────────────────────────────────────────────────────
function sndrFiInit() {
  var ci = document.getElementById('fi-company');
  var mi = document.getElementById('fi-domain-manual');
  var gb = document.getElementById('fi-generate-btn');

  if (ci) {
    ci.addEventListener('input', function() {
      clearTimeout(_sndrAcTimer);
      _sndrSel = null; _sndrPattern = null;
      var q = ci.value.trim(); var ac = document.getElementById('fi-autocomplete'); if (!ac) return;
      if (q.length < 2) { ac.style.display='none'; return; }
      _sndrAcTimer = setTimeout(function() {
        var cv = (document.getElementById('fi-country')||{value:''}).value;
        fetch(_API + '/finder/autocomplete?q=' + encodeURIComponent(q) + '&country=' + encodeURIComponent(cv||''))
          .then(function(r){ return r.json(); }).then(sndrRenderAC).catch(function(){ ac.style.display='none'; });
      }, 280);
    });
  }

  document.addEventListener('mousedown', function(e) {
    var wrap = document.getElementById('fi-company-wrap'); var ac = document.getElementById('fi-autocomplete');
    if (ac && wrap && !wrap.contains(e.target)) ac.style.display = 'none';
  });

  if (mi) {
    mi.addEventListener('input', function() {
      if (mi.value.trim()) {
        document.querySelectorAll('.fi-domain-card').forEach(function(c){ c.classList.remove('sel'); });
        _sndrDom = mi.value.trim(); if (gb) gb.disabled = false;
      } else { if (gb) gb.disabled = !_sndrDom; }
    });
  }

  // Restore last session hint
  _getHint(function(hint) {
    if (!hint) return;
    var ci2 = document.getElementById('fi-company');
    if (hint.company && ci2 && !ci2.value) ci2.value = hint.company;
    if (hint.domain) {
      sndrShowDomainSection([{ _domain: hint.domain, name: hint.company || hint.domain }]);
      _sndrPattern = hint.pattern || null;
      if (hint.pattern) {
        var s = hint.sampleEmail ? ' &nbsp;·&nbsp; e.g. <strong>' + _escHtml(hint.sampleEmail) + '</strong>' : '';
        _setStatus('<span style="color:#059669">✓ Pattern: <strong>' + _escHtml(hint.pattern) + '@' + _escHtml(hint.domain) + '</strong>' + s + '</span>');
      }
    }
  });
}

if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', sndrFiInit); }
else { sndrFiInit(); }

// ─────────────────────────────────────────────────────────────────────────────
// LINKEDIN BUTTON — belt-and-suspenders binding
// ─────────────────────────────────────────────────────────────────────────────
(function bindLinkedInBtn() {
  function attach() {
    var btn = document.getElementById('fi-linkedin-btn');
    if (btn && !btn._sndrBound) {
      btn._sndrBound = true;
      btn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); window.sndrOpenLinkedIn(); });
    }
  }
  attach();
  // Also re-attach whenever Find tab is shown
  var _g = window.goNav;
  if (typeof _g === 'function') {
    window.goNav = function(n) { _g(n); if (n==='find') setTimeout(attach, 100); };
  } else {
    Object.defineProperty(window, 'goNav', {
      configurable: true,
      set: function(fn) {
        var w = function(n) { fn(n); if (n==='find') setTimeout(attach, 100); };
        Object.defineProperty(window, 'goNav', { value: w, writable: true, configurable: true });
      }
    });
  }
})();