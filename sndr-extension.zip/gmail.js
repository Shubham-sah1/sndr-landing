(function(){if(window.__sndrGmailLoaded)return;window.__sndrGmailLoaded=!0;const l="data-sndr-tick";function a(e,r,t=[]){console[e==="error"?"error":e==="warn"?"warn":"log"](`[SNDR] ${r}`,...t);try{chrome.runtime.sendMessage({type:"DEBUG_LOG",level:e,message:r,args:t},()=>{chrome.runtime.lastError})}catch{}}a("log","Gmail read-receipt content script initialized");let f={},g=0;function p(){if(document.getElementById("__sndr-gmail-css"))return;const e=document.createElement("style");e.id="__sndr-gmail-css",e.textContent=`
      .sndr-tick-wrap {
        display: inline-flex;
        align-items: center;
        vertical-align: middle;
        margin-left: 5px;
        flex-shrink: 0;
        cursor: default;
      }
      .sndr-tick-wrap:hover::after {
        content: attr(data-sndr-tip);
        position: fixed;
        background: #0c1a2e;
        color: #6dff50;
        font-size: 11px;
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        padding: 4px 8px;
        border-radius: 5px;
        border: 1px solid rgba(109,255,80,0.25);
        white-space: nowrap;
        z-index: 9999999;
        pointer-events: none;
        transform: translateY(-24px);
      }
    `,document.head.appendChild(e)}function w(){return`<svg width="13" height="9" viewBox="0 0 13 9" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M1 4.5L4.5 8L12 1" stroke="#5a7a9a" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`}function m(e){return`<svg width="18" height="9" viewBox="0 0 18 9" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M1 4.5L4.5 8L12 1"   stroke="${e}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M6 4.5L9.5 8L17 1"   stroke="${e}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`}function b(e){for(const n of e.querySelectorAll("a[href]")){const o=(n.getAttribute("href")||"").match(/#(?:sent|all|inbox|starred|label\/sent|search)[/?]?([a-f0-9]{6,})/i);if(o)return o[1]}const r=e.querySelector("[data-legacy-message-id]");if(r)return r.getAttribute("data-legacy-message-id");const t=(e.id||"").match(/m_([a-f0-9]{6,})/i);return t?t[1]:null}function k(e){return e.querySelector("span.bog")||e.querySelector(".y6 > span")||e.querySelector("[data-thread-id] span")||e.querySelector(".Zt")}async function y(e){return e.length?new Promise(r=>{try{chrome.runtime.sendMessage({type:"GET_STATUSES",messageIds:e},t=>{chrome.runtime.lastError?(a("warn","Failed to fetch statuses via background:",[chrome.runtime.lastError.message]),r({})):r(t||{})})}catch{r({})}}):{}}function S(e,r){const t=f[r];if(!t||e.getAttribute(l)===t.status)return;const o=e.querySelector(".sndr-tick-wrap");o&&o.remove();const i=k(e);if(!i)return;let s,c;if(t.status==="replied")s=m("#63b3ed"),c="SNDR: replied";else if(t.status==="opened"){const _=t.openCount>1?` (${t.openCount}×)`:"";s=m("#6dff50"),c=`SNDR: opened${_}`}else s=w(),c="SNDR: sent";const u=document.createElement("span");u.className="sndr-tick-wrap",u.innerHTML=s,u.setAttribute("data-sndr-tip",c),i.insertAdjacentElement("afterend",u),e.setAttribute(l,t.status)}function E(){const e=[];let r=0;function t(n){if(n.attributes){r++;for(let o=0;o<n.attributes.length;o++){const i=n.attributes[o].name||"",s=n.attributes[o].value||"";s.includes("/t/open/")&&a("log",`Found image attribute containing tracking pattern: ${i} = ${s}`);const c=s.match(/\/t\/open\/([a-f0-9-]{36})/i);if(c){e.push(c[1]);break}}}}return document.querySelectorAll("img").forEach(t),e.length>0&&a("log",`Scanned ${r} images in frame, found matching contactIds: ${e.join(", ")}`),e}async function d(){p();try{const n=E(),o=Date.now();window.__sndrLastIgnoreSent||(window.__sndrLastIgnoreSent={}),n.forEach(function(i){const s=window.__sndrLastIgnoreSent[i]||0;o-s>1e4&&(window.__sndrLastIgnoreSent[i]=o,a("log",`Sending IGNORE_OPEN message for contact: ${i}`),chrome.runtime.sendMessage({type:"IGNORE_OPEN",contactId:i},function(c){chrome.runtime.lastError?a("warn",`Ignore open registration failed: ${chrome.runtime.lastError.message}`):a("log",`Ignore open registered successfully: ${i}`)}))})}catch(n){a("error",`Error scanning pixels: ${n.message}`)}const e=Array.from(document.querySelectorAll("tr.zA, tr[jslog][id]")).filter(n=>n.querySelector("span.bog, .y6, [data-legacy-message-id]"));if(!e.length)return;const r=new Map;for(const n of e){const o=b(n);o&&r.set(o,n)}if(!r.size)return;const t=Date.now();if(t-g>3e3){const n=await y([...r.keys()]);Object.assign(f,n),g=t}for(const[n,o]of r)S(o,n)}let h=null;new MutationObserver(()=>{clearTimeout(h),h=setTimeout(d,300)}).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("hashchange",()=>setTimeout(d,1200)),setTimeout(d,2500),setInterval(function(){document.hidden||d()},5e3)})();
