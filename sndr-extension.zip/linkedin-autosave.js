// linkedin-autosave.js — SNDR auto-save overlay
// Automatically saves LinkedIn profiles while scrolling.
// Hooks into the existing SNDR content script button without modifying it.
(function () {
  if (window.__sndrAutoSave) return;
  window.__sndrAutoSave = true;

  var BTN_ID   = '__mb-btn';
  var PANEL_ID = '__mb-panel';
  var saveTimer = null;
  var initTimer = null;

  // ── Consent gate ──────────────────────────────────────────────────────────
  // Auto-saving profiles while scrolling collects contact PII without an
  // explicit action, so it is OFF unless the user opts in (chrome.storage flag
  // 'autosave_enabled'). The manual extract button still works regardless.
  var autoSaveEnabled = false;
  function refreshAutoSaveFlag() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['autosave_enabled'], function (d) {
          autoSaveEnabled = !!(d && d.autosave_enabled);
        });
      }
    } catch (e) {}
  }
  refreshAutoSaveFlag();
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener(function (changes, area) {
        if (area === 'local' && changes.autosave_enabled) {
          autoSaveEnabled = !!changes.autosave_enabled.newValue;
        }
      });
    }
  } catch (e) {}

  // ── Auto-trigger the SNDR extract button when it has new profiles ──
  function tryAutoSave() {
    if (!autoSaveEnabled) return; // opt-in only
    var btn = document.getElementById(BTN_ID);
    if (!btn || btn.disabled) return;
    var text = (btn.textContent || '').trim();
    // Button shows "Extract N names" or "Add N names" when there are new profiles
    if (/^(Extract|Add)\s+\d+/i.test(text)) {
      btn.click();
    }
  }

  // ── Scroll handler: wait for SNDR's own 500ms debounce, then trigger ──
  document.addEventListener('scroll', function () {
    clearTimeout(saveTimer);
    // SNDR updates the button at +500ms; we click at +1200ms to stay behind it
    saveTimer = setTimeout(tryAutoSave, 1200);
  }, { passive: true, capture: true });

  // ── Also try on initial load and after SPA navigation ──
  function scheduleInit() {
    clearTimeout(initTimer);
    initTimer = setTimeout(tryAutoSave, 3000);
  }

  scheduleInit();

  // SPA navigation: re-trigger whenever the URL changes
  var lastHref = location.href;
  new MutationObserver(function () {
    if (location.href !== lastHref) {
      lastHref = location.href;
      scheduleInit();
    }
  }).observe(document.body, { childList: true, subtree: true });
})();
