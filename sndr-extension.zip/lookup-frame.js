// Runs only inside the hidden search-result frames that SNDR's offscreen page
// loads for email-format lookups (offscreen.js names them "sndr-lookup-…");
// on any normal Google/Bing/DuckDuckGo page it does nothing. Sends the page's
// text to the background worker, which reads the format from it.
(function () {
  if (window.top === window || !/^sndr-lookup-/.test(window.name || '')) return;

  // The offscreen page is never drawn, so innerText would return raw
  // textContent (scripts and CSS included). Collect visible-style text
  // instead: skip code, put each block element on its own line.
  var SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1, SVG: 1, IFRAME: 1, HEAD: 1, LINK: 1, META: 1, BUTTON: 1 };
  var BLOCK = /^(ADDRESS|ARTICLE|ASIDE|BLOCKQUOTE|BR|CITE|DD|DIV|DL|DT|FIGCAPTION|FIGURE|FOOTER|FORM|H[1-6]|HEADER|HR|LI|MAIN|NAV|OL|P|PRE|SECTION|TABLE|TD|TH|TR|UL)$/;
  function pageText() {
    var out = [];
    (function walk(node) {
      for (var n = node.firstChild; n; n = n.nextSibling) {
        if (n.nodeType === 3) { out.push(n.nodeValue); continue; }
        if (n.nodeType !== 1 || SKIP[n.tagName.toUpperCase()]) continue;
        var block = BLOCK.test(n.tagName.toUpperCase());
        if (block) out.push('\n');
        walk(n);
        if (block) out.push('\n');
      }
    })(document.body || document.documentElement);
    return out.join('')
      .replace(/[ \t ]+/g, ' ')
      .replace(/ *\n */g, '\n')
      .replace(/\n{2,}/g, '\n')
      .trim();
  }

  // Results can fill in after load (AI answers, script-rendered lists): send
  // once the text stops growing, or after 5 seconds at most.
  var start = Date.now(), last = -1, steady = 0;
  (function poll() {
    var text = pageText();
    steady = text.length === last ? steady + 1 : 0;
    last = text.length;
    if ((steady >= 2 && Date.now() - start >= 1200) || Date.now() - start >= 5000) {
      try { chrome.runtime.sendMessage({ type: 'LOOKUP_FRAME_TEXT', id: window.name, text: text }); } catch (e) {}
      return;
    }
    setTimeout(poll, 400);
  })();
})();
