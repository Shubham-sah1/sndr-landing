// Fixing the recipients in the campaign's Map Columns step, before writing
// the email. LinkedIn names arrive as "Kunal Joshi CA" or "Meera Iyer | HR",
// companies as "... Pvt Ltd", roles as whole headlines — and the first word
// of the name becomes {first_name}. Three ways to fix that, on the same rows
// the campaign is created from (parsedRows in dashboard.js):
//  • "View all contacts" shows every row, not just the first three;
//  • any cell except the email can be fixed by hand (click, type, Enter);
//  • SNDR AI rewrites the mapped Name / Company / Role columns the way the
//    user describes. It first lists every change it would make; nothing
//    changes until Apply, the changed cells are then tinted in the full list
//    for checking by hand, and Undo puts them back.
// Email addresses are never changed. Edits are saved with the campaign draft.
(function () {
  var BATCH = 100;             // the server takes up to 100 contacts per call
  var COLS = [['name', 'map-name-col', 'Name'], ['company', 'map-company-col', 'Company'], ['role', 'map-role-col', 'Role']];
  var lastRows = null;         // the parsedRows these marks belong to
  var pending = null;          // suggested changes waiting for Apply / Discard
  var undo = null;             // [{ r, c, prev }] from the last Apply

  function $(id) { return document.getElementById(id); }
  function esc(s) { return typeof escHtml === 'function' ? escHtml(s) : String(s == null ? '' : s).replace(/[&<>"']/g, function (ch) { return '&#' + ch.charCodeAt(0) + ';'; }); }
  function rows() { return typeof parsedRows !== 'undefined' ? parsedRows : []; }
  function headers() { return typeof parsedHeaders !== 'undefined' ? parsedHeaders : []; }
  function save() { if (typeof window.saveComposeState === 'function') window.saveComposeState(); }
  function redraw() { if (typeof setupMappingPreviewTable === 'function') setupMappingPreviewTable(); }
  function plural(n, one, many) { return n + ' ' + (n === 1 ? one : (many || one + 's')); }

  // The mapped columns SNDR AI may change: [{ key, idx, label }]. Never the email.
  function mapped() {
    var email = $('map-email-col') ? $('map-email-col').value : '';
    var out = [];
    COLS.forEach(function (c) {
      var sel = $(c[1]);
      var h = sel ? sel.value : '';
      var idx = h ? headers().indexOf(h) : -1;
      if (idx !== -1 && h !== email && !out.some(function (o) { return o.idx === idx; })) out.push({ key: c[0], idx: idx, label: c[2] });
    });
    return out;
  }

  function setCell(r, c, v) {
    var row = rows()[r];
    if (!row) return;
    while (row.length <= c) row.push('');
    row[c] = v;
  }

  // A different sheet (new upload, restored draft): marks and suggestions go.
  window._mapFixSync = function () {
    if (rows() === lastRows) return;
    lastRows = rows();
    window._mapShowAll = false;
    window._mapFixed = {};
    pending = null;
    undo = null;
    setResult('');
  };

  // What SNDR AI will touch, said plainly; chips for unmapped columns are off.
  window._mapFixRefresh = function () {
    var cols = mapped(), n = rows().length;
    var scope = $('map-fix-scope'), go = $('map-fix-go');
    if (scope) {
      scope.textContent = cols.length
        ? 'SNDR AI will rewrite the ' + listWords(cols.map(function (c) { return c.label; })) + ' column' + (cols.length > 1 ? 's' : '') +
          ' of all ' + plural(n, 'contact') + ' the way you describe. Email addresses are never changed.'
        : 'Pick a Name, Company or Role column above to use SNDR AI.';
    }
    if (go && !go._busy) go.disabled = !cols.length || !n;
    document.querySelectorAll('#map-fix .fi-fix-chip').forEach(function (b) {
      if (b._busy) return;
      b.disabled = !cols.some(function (c) { return c.key === b.getAttribute('data-col'); });
    });
  };
  function listWords(a) { return a.length < 2 ? a.join('') : a.slice(0, -1).join(', ') + ' and ' + a[a.length - 1]; }

  // ── Fixing a cell by hand ────────────────────────────────────────────────
  var CELL = '#map-table-preview td[contenteditable]';
  document.addEventListener('focusin', function (ev) {
    var td = ev.target.closest && ev.target.closest(CELL);
    if (td) td.setAttribute('data-orig', td.textContent);
  });
  document.addEventListener('keydown', function (ev) {
    var td = ev.target.closest && ev.target.closest(CELL);
    if (!td) return;
    if (ev.key === 'Enter') { ev.preventDefault(); td.blur(); }
    else if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); td.textContent = td.getAttribute('data-orig') || ''; td.blur(); }
  });
  document.addEventListener('focusout', function (ev) {
    var td = ev.target.closest && ev.target.closest(CELL);
    if (!td) return;
    var r = +td.getAttribute('data-r'), c = +td.getAttribute('data-c');
    var v = td.textContent.replace(/\s+/g, ' ').trim();
    if (td.textContent !== v) td.textContent = v;
    var row = rows()[r];
    if (!row || (row[c] == null ? '' : String(row[c])) === v) return;
    setCell(r, c, v);
    window._mapFixed = window._mapFixed || {};
    window._mapFixed[r + ':' + c] = true;
    td.classList.add('cell-fixed');
    save();
  });

  // ── View all ─────────────────────────────────────────────────────────────
  document.addEventListener('click', function (ev) {
    if (!ev.target.closest || !ev.target.closest('#map-view-all')) return;
    window._mapShowAll = !window._mapShowAll;
    redraw();
  });

  // ── Fix with AI ──────────────────────────────────────────────────────────
  function setResult(html) { var el = $('map-fix-result'); if (el) el.innerHTML = html; }
  function busy(on, text) {
    var go = $('map-fix-go'), input = $('map-fix-input');
    if (go) { go._busy = on; go.disabled = on; go.innerHTML = '<span class="mi" style="font-size:15px">auto_awesome</span>' + (on ? esc(text || 'Fixing…') : 'Fix with AI'); }
    if (input) input.disabled = on;
    document.querySelectorAll('#map-fix .fi-fix-chip').forEach(function (b) { b._busy = on; b.disabled = on; });
    if (!on) window._mapFixRefresh();
  }

  async function runFix(instruction) {
    instruction = String(instruction || '').trim();
    var cols = mapped(), all = rows();
    if (!instruction) { if ($('map-fix-input')) $('map-fix-input').focus(); return; }
    if (!cols.length || !all.length) return;
    pending = null;
    setResult('');
    var changes = [];
    try {
      for (var start = 0; start < all.length; start += BATCH) {
        var part = all.slice(start, start + BATCH);
        busy(true, all.length > BATCH ? 'Fixing ' + Math.min(start + BATCH, all.length) + ' of ' + all.length + '…' : 'Fixing…');
        var res = await apiCall('POST', '/api/ai/fix-contacts', {
          instruction: instruction,
          contacts: part.map(function (row) {
            var o = {};
            cols.forEach(function (c) { o[c.key] = row[c.idx] == null ? '' : String(row[c.idx]); });
            return o;
          }),
        }, false, 90000);
        (res && res.changes || []).forEach(function (ch) {
          var r = start + ch.i, row = all[r];
          if (!row) return;
          cols.forEach(function (c) {
            if (typeof ch[c.key] !== 'string') return;
            var from = row[c.idx] == null ? '' : String(row[c.idx]);
            if (ch[c.key] !== from) changes.push({ r: r, c: c.idx, label: c.label, from: from, to: ch[c.key] });
          });
        });
      }
    } catch (err) {
      busy(false);
      setResult('<div class="fi-fix-err">' + esc(err && err.message ? err.message : 'SNDR AI is unavailable right now. Try again in a minute.') + '</div>');
      return;
    }
    busy(false);
    if (typeof window.sndrTrack === 'function') window.sndrTrack('ai_used', { feature: 'fix_contacts', count: all.length, changed: changes.length });
    if (!changes.length) { setResult('<div class="fi-fix-note">Nothing to change for that.</div>'); return; }
    pending = changes;
    showPreview(changes);
  }

  // Every change it would make, before anything changes. The same change for
  // several people ("Carnelian Asset Management and Advisors Pvt Ltd →
  // Carnelian") is listed once with how many.
  function showPreview(changes) {
    var lines = [], seen = {};
    changes.forEach(function (e) {
      var k = e.label + '\u0000' + e.from + '\u0000' + e.to;
      if (seen[k]) { seen[k].n++; return; }
      seen[k] = { label: e.label, from: e.from, to: e.to, n: 1 };
      lines.push(seen[k]);
    });
    var people = {};
    changes.forEach(function (e) { people[e.r] = true; });
    var nPeople = Object.keys(people).length;
    setResult(
      '<div class="fi-fix-preview">' +
        '<div class="fi-fix-title">SNDR AI would make ' + plural(changes.length, 'change') + ' for ' + plural(nPeople, 'contact') + '. Nothing has changed yet.</div>' +
        '<ul class="fi-fix-list">' + lines.map(function (l) {
          return '<li><span class="fi-fix-col">' + esc(l.label) + '</span><span class="fi-fix-from">' + esc(l.from || '(empty)') + '</span>' +
            '<span class="mi" aria-hidden="true">arrow_forward</span><span class="fi-fix-to">' + esc(l.to) + '</span>' +
            (l.n > 1 ? '<span class="fi-fix-n">' + l.n + ' people</span>' : '') + '</li>';
        }).join('') + '</ul>' +
        '<div class="fi-fix-actions">' +
          '<button type="button" class="fi-act-btn fi-act-csv" id="map-fix-discard">Discard</button>' +
          '<button type="button" class="fi-act-btn fi-act-camp" id="map-fix-apply">Apply ' + plural(changes.length, 'change') + '</button>' +
        '</div>' +
      '</div>');
    $('map-fix-discard').addEventListener('click', function () { pending = null; setResult(''); });
    $('map-fix-apply').addEventListener('click', applyPending);
    $('map-fix-apply').focus();
  }

  function applyPending() {
    if (!pending) return;
    var all = rows(), done = [];
    window._mapFixed = window._mapFixed || {};
    pending.forEach(function (e) {
      var row = all[e.r];
      var now = row && row[e.c] != null ? String(row[e.c]) : '';
      if (!row || now !== e.from) return; // fixed by hand since: keep the hand fix
      done.push({ r: e.r, c: e.c, prev: now, wasFixed: !!window._mapFixed[e.r + ':' + e.c] });
      setCell(e.r, e.c, e.to);
      window._mapFixed[e.r + ':' + e.c] = true;
    });
    pending = null;
    undo = done;
    window._mapShowAll = true; // so every change can be checked, and fixed by hand
    redraw();
    save();
    var people = {};
    done.forEach(function (d) { people[d.r] = true; });
    setResult('<div class="fi-fix-note">Changed ' + plural(Object.keys(people).length, 'contact') + '. The changes are highlighted in the full list above; click any cell to fix it. ' +
      '<button type="button" class="fi-fix-undo" id="map-fix-review">Review them</button> · <button type="button" class="fi-fix-undo" id="map-fix-undo">Undo</button></div>');
    $('map-fix-review').addEventListener('click', function () {
      var wrap = $('map-table-wrap');
      if (wrap) wrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    $('map-fix-undo').addEventListener('click', function () {
      if (!undo) return;
      undo.forEach(function (d) {
        setCell(d.r, d.c, d.prev);
        if (!d.wasFixed && window._mapFixed) delete window._mapFixed[d.r + ':' + d.c];
      });
      undo = null;
      redraw();
      save();
      setResult('<div class="fi-fix-note">Undone.</div>');
    });
  }

  function wire() {
    var form = $('map-fix-form');
    if (!form || form._wired) return;
    form._wired = true;
    form.addEventListener('submit', function (ev) { ev.preventDefault(); runFix($('map-fix-input').value); });
    // The box grows to show the whole instruction; Enter asks (Shift+Enter is
    // a new line).
    var input = $('map-fix-input');
    function fit() { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight + 2, 120) + 'px'; }
    input.addEventListener('input', fit);
    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); runFix(input.value); }
    });
    // A chip puts its exact instruction in the box, so it's clear what will be
    // asked before clicking Fix with AI.
    document.querySelectorAll('#map-fix .fi-fix-chip').forEach(function (b) {
      b.addEventListener('click', function () {
        input.value = b.getAttribute('data-fix');
        fit();
        input.focus();
      });
    });
    ['map-email-col', 'map-name-col', 'map-company-col', 'map-role-col'].forEach(function (id) {
      var sel = $(id);
      if (sel) sel.addEventListener('change', function () { pending = null; setResult(''); redraw(); });
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
})();
