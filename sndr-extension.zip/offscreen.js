// Invisible page that hosts the search-result pages for email-format lookups
// (see hiddenFrameText in src/background.js), so no tab ever opens. Each
// lookup is one iframe named with its lookup id; lookup-frame.js reads that
// name from inside the frame and reports the rendered text back.
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || typeof msg.id !== 'string' || msg.id.indexOf('sndr-lookup-') !== 0) return;
  if (msg.type === 'OFFSCREEN_LOAD_FRAME') {
    var frame = document.createElement('iframe');
    frame.id = msg.id;
    frame.name = msg.id;
    // Desktop-sized, so results lay out the way they do in a normal window.
    frame.width = '1280';
    frame.height = '2000';
    frame.src = msg.url;
    document.body.appendChild(frame);
    sendResponse({ ok: true });
  } else if (msg.type === 'OFFSCREEN_REMOVE_FRAME') {
    var old = document.getElementById(msg.id);
    if (old) old.remove();
    sendResponse({ ok: true });
  }
});
