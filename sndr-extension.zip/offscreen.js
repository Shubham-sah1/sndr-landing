// Invisible page that hosts pages the extension reads without opening a tab
// (see src/background.js): search results for email-format lookups
// ("sndr-lookup-…", read by lookup-frame.js) and the Gmail inbox for
// background reply checks ("sndr-gmail-…", read by src/content/gmail.js).
// Each one is an iframe named with its id; the script inside the frame reads
// that name and reports back.
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || typeof msg.id !== 'string' || !/^sndr-(lookup|gmail)-/.test(msg.id)) return;
  if (msg.type === 'OFFSCREEN_LOAD_FRAME') {
    var frame = document.createElement('iframe');
    frame.id = msg.id;
    frame.name = msg.id;
    // Desktop-sized, so pages lay out the way they do in a normal window.
    frame.width = '1280';
    frame.height = '2000';
    // Gmail runs normally (scripts, its own sign-in) but can't navigate this page.
    if (msg.id.indexOf('sndr-gmail-') === 0) frame.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms allow-popups');
    frame.src = msg.url;
    document.body.appendChild(frame);
    sendResponse({ ok: true });
  } else if (msg.type === 'OFFSCREEN_REMOVE_FRAME') {
    var old = document.getElementById(msg.id);
    if (old) old.remove();
    sendResponse({ ok: true });
  }
});
