// Real-person name check, shared by the LinkedIn scraper (content script, see
// manifest.json) and the Find screen (dashboard.html). LinkedIn cards also
// carry headlines, team pages and company labels ("Strategy & Ops") that can
// win the name pick; anything that isn't a person's name never reaches the
// contact list or gets an email generated for it.
(function (root) {
  // Words that appear in headlines, team/department labels and company cards
  // but are never part of someone's name. Words that are also real names or
  // surnames (Grace, King, Page, Young, Rich…) are deliberately left out.
  var NOT_NAME_WORDS = (
    // functions / departments
    'strategy strategic ops operations operation marketing sales growth business development bd ' +
    'product products finance financial accounts accounting hr human resources resource talent acquisition ' +
    'recruitment recruiting recruiter recruiters hiring careers career jobs job people culture team teams ' +
    'department dept division unit office desk support services service customer customers success care ' +
    'helpdesk admin administration legal compliance risk audit tax treasury procurement purchase supply chain ' +
    'logistics analytics analysis data insights research design engineering technology tech infra ' +
    'infrastructure security quality qa brand branding communications communication comms pr media content ' +
    'social digital partnerships partnership alliances investor investors relations relationship ' +
    // roles
    'head lead leader leadership manager managers management director directors chief officer executive ' +
    'president vp svp avp evp gm ceo cto cfo coo cmo cpo chro cxo founder founders cofounder co-founder owner ' +
    'associate analyst consultant specialist coordinator intern interns trainee fresher student recruiter ' +
    'developer engineer designer architect scientist advisor adviser mentor coach trainer professor lecturer ' +
    'accountant auditor entrepreneur freelancer freelance member members employee employees staff ' +
    'volunteer ambassador evangelist generalist apprentice assistant secretary supervisor administrator ' +
    'strategist operator representative agent broker software senior junior principal graduate aspiring ' +
    'certified frontend backend stack ' +
    // organisations / pages
    'company inc llc llp ltd limited pvt private corp corporation holdings ventures venture capital ' +
    'partners labs lab studio studios agency solutions technologies systems global international ' +
    'foundation trust society association council institute university college school academy club ' +
    'community network official hq headquarters news updates info contact hello enquiry enquiries ' +
    'bank banking fund funds investments securities advisors advisory consulting consultancy realty ' +
    'properties motors foods pharma healthcare hospital clinic linkedin ' +
    // filler words that only appear in phrases
    'the and for of at in with from by our your we us all'
  ).split(' ');
  var NOT_NAME = {};
  NOT_NAME_WORDS.forEach(function (w) { if (w) NOT_NAME[w] = true; });

  // Symbols and digits that never appear in a person's display name.
  var BAD_CHARS = /[&/\\|+@#$%^*=<>{}[\]~_:;!?"“”()0-9]/;
  var EMOJI = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/gu;

  // Display-name cleanup: drop emoji and anything after a comma
  // ("Ankit Sharma, CFA" -> "Ankit Sharma").
  function cleanPersonName(raw) {
    return String(raw || '')
      .replace(EMOJI, '')
      .split(',')[0]
      .replace(/\s+/g, ' ')
      .trim();
  }

  function isPersonName(raw) {
    var n = cleanPersonName(raw);
    if (n.length < 2 || n.length > 60) return false;
    if (BAD_CHARS.test(n)) return false;
    var words = n.split(' ');
    if (words.length > 5) return false;
    for (var i = 0; i < words.length; i++) {
      var w = words[i].toLowerCase().replace(/^[.'’-]+|[.'’-]+$/g, '');
      if (!w || !/\p{L}/u.test(w)) return false;
      if (NOT_NAME[w]) return false;
    }
    return true;
  }

  // Saved contacts minus anything that isn't a person (entries saved before
  // this check existed, or by an older scraper).
  function onlyPeople(list) {
    return (list || []).filter(function (c) { return c && isPersonName(c.name); });
  }

  root.sndrIsPersonName = isPersonName;
  root.sndrCleanPersonName = cleanPersonName;
  root.sndrOnlyPeople = onlyPeople;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { isPersonName: isPersonName, cleanPersonName: cleanPersonName, onlyPeople: onlyPeople };
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
