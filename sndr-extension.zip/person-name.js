// Real-person name check, shared by the LinkedIn scraper (content script, see
// manifest.json) and the Find screen (dashboard.html). LinkedIn cards also
// carry headlines, team pages and company labels ("Strategy & Ops") that can
// win the name pick; anything that isn't a person's name never reaches the
// contact list or gets an email generated for it.
(function (root) {
  // Words that appear in headlines, team/department labels and company cards
  // but are never part of someone's name. Words that are also real names or
  // surnames (Grace, King, Page, Young, Rich…) are deliberately left out.
  var NOT_NAME_WORDS = (
    // functions / departments
    'strategy strategic ops operations operation marketing sales growth business development bd ' +
    'product products finance financial accounts accounting hr human resources resource talent acquisition ' +
    'recruitment recruiting recruiter recruiters hiring careers career jobs job people culture team teams ' +
    'department dept division unit office desk support services service customer customers success care ' +
    'helpdesk admin administration legal compliance risk audit tax treasury procurement purchase supply chain ' +
    'logistics analytics analysis data insights research design engineering technology tech infra ' +
    'infrastructure security quality qa brand branding communications communication comms pr media content ' +
    'social digital partnerships partnership alliances investor investors relations relationship ' +
    // roles
    'head lead leader leadership manager managers management director directors chief officer executive ' +
    'president vp svp avp evp gm ceo cto cfo coo cmo cpo chro cxo founder founders cofounder co-founder owner ' +
    'associate analyst consultant specialist coordinator intern interns trainee fresher student recruiter ' +
    'developer engineer designer architect scientist advisor adviser mentor coach trainer professor lecturer ' +
    'accountant auditor entrepreneur freelancer freelance member members employee employees staff ' +
    'volunteer ambassador evangelist generalist apprentice assistant secretary supervisor administrator ' +
    'strategist operator representative agent broker software senior junior principal graduate aspiring ' +
    'certified frontend backend stack ' +
    // organisations / pages
    'company inc llc llp ltd limited pvt private corp corporation holdings ventures venture capital ' +
    'partners labs lab studio studios agency solutions technologies systems global international ' +
    'foundation trust society association council institute university college school academy club ' +
    'community network official hq headquarters news updates info contact hello enquiry enquiries ' +
    'bank banking fund funds investments securities advisors advisory consulting consultancy realty ' +
    'properties motors foods pharma healthcare hospital clinic linkedin ' +
    // filler words that only appear in phrases
    'the and for of at in with from by our your we us all'
  ).split(' ');
  var NOT_NAME = {};
  NOT_NAME_WORDS.forEach(function (w) { if (w) NOT_NAME[w] = true; });

  // Symbols and digits that never appear in a person's display name.
  var BAD_CHARS = /[&/\\|+@#$%^*=<>{}[\]~_:;!?"“”()0-9]/;
  var EMOJI = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/gu;

  // Display-name cleanup: drop emoji and anything after a comma
  // ("Ankit Sharma, CFA" -> "Ankit Sharma").
  function cleanPersonName(raw) {
    return String(raw || '')
      .replace(EMOJI, '')
      .split(',')[0]
      .replace(/\s+/g, ' ')
      .trim();
  }

  function isPersonName(raw) {
    var n = cleanPersonName(raw);
    if (n.length < 2 || n.length > 60) return false;
    if (BAD_CHARS.test(n)) return false;
    var words = n.split(' ');
    if (words.length > 5) return false;
    for (var i = 0; i < words.length; i++) {
      var w = words[i].toLowerCase().replace(/^[.'’-]+|[.'’-]+$/g, '');
      if (!w || !/\p{L}/u.test(w)) return false;
      if (NOT_NAME[w]) return false;
    }
    return true;
  }

  // ── The name in the profile address ──────────────────────────────────────
  // LinkedIn addresses usually spell the person's name
  // (/in/aishwarya-ramakrishnan-1a2b3c). A headline never matches it, so it
  // settles which captured text is the name. Only an address LinkedIn made
  // itself (it ends in an id with digits) is trusted to PROVE a capture is
  // not the name, or to supply the name: a self-chosen address can be
  // anything (/in/food-lover). Hidden members' ids (/in/ACoAA…) tell nothing.
  var SLUG_NOISE = { official: 1, mba: 1, phd: 1, pmp: 1, cfa: 1, cpa: 1, acca: 1, the: 1, real: 1, india: 1, iii: 1 };

  function profileSlug(url) {
    var m = /\/in\/([^/?#]+)/i.exec(String(url || ''));
    if (!m) return null;
    var slug = m[1];
    try { slug = decodeURIComponent(slug); } catch (e) {}
    return /^acoa/i.test(slug) ? null : slug.toLowerCase();
  }

  function profileSlugTokens(url) {
    var slug = profileSlug(url);
    return slug ? slug.split(/[-_.]+/).filter(function (t) { return /^[a-z]{2,}$/.test(t); }) : [];
  }

  // "aishwarya-ramakrishnan-1a2b3c": name parts, then LinkedIn's own id.
  function isGeneratedSlug(url) {
    var parts = (profileSlug(url) || '').split('-');
    return parts.length >= 3 && /\d/.test(parts[parts.length - 1]);
  }

  function fold(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  }

  // true: the name matches the address; false: LinkedIn's own address spells
  // a name and this isn't it; null: can't tell (no name in the address, a
  // self-chosen address, or a name in a non-Latin script).
  function nameMatchesProfile(name, url) {
    var tokens = profileSlugTokens(url);
    if (!tokens.length) return null;
    var words = fold(cleanPersonName(name)).split(/[^a-z]+/).filter(function (w) { return w.length >= 2; });
    if (!words.length) return null;
    var joined = tokens.join('');
    var initials = words.map(function (w) { return w.charAt(0); }).join('');
    var hit = tokens.indexOf(initials) !== -1 || words.some(function (w) {
      return tokens.indexOf(w) !== -1 || (w.length >= 4 && joined.indexOf(w) !== -1);
    });
    if (hit) return true;
    return isGeneratedSlug(url) && nameFromProfile(url) ? false : null;
  }

  // "aishwarya-ramakrishnan-1a2b3c" -> "Aishwarya Ramakrishnan", or null when
  // the address isn't LinkedIn's own or doesn't hold a first and last name.
  function nameFromProfile(url) {
    if (!isGeneratedSlug(url)) return null;
    var parts = profileSlugTokens(url).filter(function (t) { return t.length >= 3 && !SLUG_NOISE[t]; }).slice(0, 3);
    if (parts.length < 2) return null;
    var name = parts.map(function (t) { return t.charAt(0).toUpperCase() + t.slice(1); }).join(' ');
    return isPersonName(name) ? name : null;
  }

  // Saved contacts with anything that isn't a person's name fixed or removed
  // (entries saved before these checks existed, or by an older scraper): a
  // headline is replaced by the name in the profile address when it holds
  // one, otherwise the entry is dropped.
  function onlyPeople(list) {
    var out = [];
    (list || []).forEach(function (c) {
      if (!c) return;
      var ok = isPersonName(c.name) && nameMatchesProfile(c.name, c.profileUrl) !== false;
      if (ok) { out.push(c); return; }
      var fromUrl = nameFromProfile(c.profileUrl);
      if (fromUrl) out.push(Object.assign({}, c, { name: fromUrl }));
    });
    return out;
  }

  root.sndrIsPersonName = isPersonName;
  root.sndrCleanPersonName = cleanPersonName;
  root.sndrNameMatchesProfile = nameMatchesProfile;
  root.sndrNameFromProfile = nameFromProfile;
  root.sndrOnlyPeople = onlyPeople;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { isPersonName: isPersonName, cleanPersonName: cleanPersonName, onlyPeople: onlyPeople,
      nameMatchesProfile: nameMatchesProfile, nameFromProfile: nameFromProfile };
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
