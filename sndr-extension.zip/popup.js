var API = 'https://sndr-f4rg.onrender.com';
var authToken = null;
var currentAccount = null;

// HTML-escape dynamic (server/user) data before interpolating into innerHTML.
function escHtml(s){ return String(s==null?'':s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

async function initApi() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    await new Promise(function(resolve) {
      chrome.storage.local.get(['custom_api_url'], async function(data) {
        if (data.custom_api_url) {
          API = data.custom_api_url;
          console.log('[SNDR] Popup using API URL:', API);
        }
        resolve();
      });
    });
  }
}

var authMode = 'signup'; // 'signup' | 'login'

function updateAuthUI() {
  var authTitle     = document.getElementById('auth-title');
  var authSub       = document.getElementById('auth-sub');
  var authSubmitBtn = document.getElementById('btn-auth-submit');
  var authToggleBtn = document.getElementById('btn-auth-toggle');
  var authToggleMsg = document.getElementById('auth-toggle-msg');
  var groupEmail    = document.getElementById('group-email');
  var authUsername  = document.getElementById('auth-username');
  var authEmailEl   = document.getElementById('auth-email');
  var btnForgotPopup = document.getElementById('btn-forgot-password-popup');

  var usernameText = document.getElementById('lbl-username-text');
  var usernameRequired = document.getElementById('lbl-username-required');
  var usernameHelp = document.getElementById('lbl-username-help');
  var passwordRequired = document.getElementById('lbl-password-required');
  var passwordHelp = document.getElementById('lbl-password-help');
  var emailRequired = document.getElementById('lbl-email-required');

  if (authMode === 'signup') {
    if (authTitle) authTitle.textContent = 'Create your account';
    if (authSub) authSub.textContent = 'Sign up to manage your campaigns';
    if (authSubmitBtn) authSubmitBtn.textContent = 'Sign Up';
    if (authToggleMsg) authToggleMsg.textContent = 'Already have an account?';
    if (authToggleBtn) authToggleBtn.textContent = 'Log in';
    if (groupEmail) groupEmail.style.display = 'flex';
    if (authEmailEl) authEmailEl.required = true;
    if (btnForgotPopup) btnForgotPopup.style.display = 'none';

    if (usernameText) usernameText.textContent = 'Username';
    if (usernameRequired) usernameRequired.style.display = '';
    if (usernameHelp) usernameHelp.style.display = '';
    if (passwordRequired) passwordRequired.style.display = '';
    if (passwordHelp) passwordHelp.style.display = '';
    if (emailRequired) emailRequired.style.display = '';
    if (authUsername) authUsername.placeholder = 'e.g. johndoe';
  } else {
    if (authTitle) authTitle.textContent = 'Log in to your account';
    if (authSub) authSub.textContent = 'Log in to your SNDR account';
    if (authSubmitBtn) authSubmitBtn.textContent = 'Log In';
    if (authToggleMsg) authToggleMsg.textContent = "Don't have an account?";
    if (authToggleBtn) authToggleBtn.textContent = 'Sign up';
    if (groupEmail) groupEmail.style.display = 'none';
    if (authEmailEl) authEmailEl.required = false;
    if (btnForgotPopup) btnForgotPopup.style.display = 'inline-block';

    if (usernameText) usernameText.textContent = 'Username or Email';
    if (usernameRequired) usernameRequired.style.display = '';
    if (usernameHelp) usernameHelp.style.display = 'none';
    if (passwordRequired) passwordRequired.style.display = '';
    if (passwordHelp) passwordHelp.style.display = 'none';
    if (emailRequired) emailRequired.style.display = 'none';
    if (authUsername) authUsername.placeholder = 'e.g. johndoe or john@company.com';
  }
}

function authFetch(url, options) {
  options = options || {};
  options.headers = options.headers || {};
  if (authToken) {
    options.headers['Authorization'] = 'Bearer ' + authToken;
  }
  return fetch(url, options);
}

function openDashboard(){
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
}

document.getElementById('btn-dash').addEventListener('click', openDashboard);

document.getElementById('btn-signout').addEventListener('click', async function(){
  try {
    await authFetch(API + '/auth/logout', { method: 'POST' }).catch(function(){});
  } catch(e) {}
  localStorage.removeItem('sndr_session');
  chrome.storage.local.clear(function(){
    authToken = null;
    checkSession();
  });
});

// ── Session & Auth UI ──

var authContainer = document.getElementById('auth-container');
var mainHdr       = document.getElementById('main-hdr');
var bodyContainer = document.getElementById('body');
var mainFooter    = document.getElementById('main-footer');

var authForm      = document.getElementById('auth-form');
var authTitle     = document.getElementById('auth-title');
var authError     = document.getElementById('auth-error');
var authUsername  = document.getElementById('auth-username');
var authEmailEl   = document.getElementById('auth-email');
var authPassword  = document.getElementById('auth-password');
var authSubmitBtn = document.getElementById('btn-auth-submit');
var authToggleBtn = document.getElementById('btn-auth-toggle');
var authToggleMsg = document.getElementById('auth-toggle-msg');
var groupEmail    = document.getElementById('group-email');
var lblUsername   = document.getElementById('lbl-username');
var btnForgotPopup= document.getElementById('btn-forgot-password-popup');

authToggleBtn.addEventListener('click', function() {
  authMode = (authMode === 'login') ? 'signup' : 'login';
  updateAuthUI();
  authError.style.display = 'none';
});

if (btnForgotPopup) {
  btnForgotPopup.addEventListener('click', function(e) {
    e.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html?view=forgot') });
  });
}

authForm.addEventListener('submit', function(e) {
  e.preventDefault();
  var username = authUsername ? authUsername.value.trim() : '';
  var password = authPassword.value;
  var email = authEmailEl ? authEmailEl.value.trim() : '';

  if (authMode === 'login') {
    if (!username || !password) {
      showAuthError('Username/Email and password required');
      return;
    }
  } else {
    if (!username || !email || !password) {
      showAuthError('Username, Email, and password required');
      return;
    }
  }

  authError.style.display = 'none';
  authSubmitBtn.disabled = true;
  authSubmitBtn.textContent = 'Please wait...';

  var endpoint = authMode === 'login' ? '/auth/login' : '/auth/signup';
  var payload = authMode === 'login'
    ? { username: username, password: password }
    : { username: username, email: email, password: password };

  fetch(API + endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  .then(function(r) {
    return r.json().then(function(d) {
      if (!r.ok) throw new Error(d.error || 'Authentication failed');
      return d;
    });
  })
  .then(function(sessionData) {
    // Token persists only in chrome.storage.local (source of truth); no localStorage copy.
    chrome.storage.local.set({ session: sessionData }, function() {
      authToken = sessionData.token;
      checkSession();
    });
  })
  .catch(function(err) {
    showAuthError(err.message);
  })
  .finally(function() {
    authSubmitBtn.disabled = false;
    authSubmitBtn.textContent = authMode === 'login' ? 'Log In' : 'Sign Up';
  });
});

function showAuthError(msg) {
  authError.textContent = msg;
  authError.style.display = 'block';
}

function checkSession() {
  chrome.storage.local.get(['session'], function(data) {
    if (data.session && data.session.token) {
      authToken = data.session.token;
      authContainer.style.display = 'none';
      mainHdr.style.display = 'block';
      bodyContainer.style.display = 'block';
      mainFooter.style.display = 'flex';

      // Set greeting + avatar initials
      var greetingEl = document.getElementById('u-greeting');
      var avInitials = document.getElementById('user-av-initials');
      if (greetingEl && data.session.username) {
        greetingEl.textContent = 'Hi, ' + data.session.username + '!';
      }
      if (avInitials && data.session.username) {
        avInitials.textContent = data.session.username.substring(0, 2).toUpperCase();
      }

      // Load account details
      loadAccount();
    } else {
      authToken = null;
      mainHdr.style.display = 'none';
      bodyContainer.style.display = 'none';
      mainFooter.style.display = 'none';
      authContainer.style.display = 'flex';
      updateAuthUI();
    }
  });
}

// ── Load account ──
function loadAccount(){
  authFetch(API + '/auth/accounts')
    .then(function(r) {
      if (r.status === 401 || r.status === 403) {
        localStorage.removeItem('sndr_session');
        chrome.storage.local.clear(function(){
          authToken = null;
          checkSession();
        });
        throw new Error('Unauthorized');
      }
      return r.json();
    })
    .then(function(accounts) {
      var dot = document.getElementById('acct-dot');
      if (accounts.length > 0) {
        currentAccount = accounts[0];
        document.getElementById('user-email').textContent = currentAccount.email;
        document.getElementById('acct-status').textContent = '· Connected';
        if (dot) dot.style.backgroundColor = '#22c55e'; // Green
        var isPro = currentAccount.plan === 'pro';
        var badge = document.getElementById('plan-badge');
        badge.textContent = isPro ? 'PRO' : 'FREE';
        if (isPro) badge.classList.add('pro'); else badge.classList.remove('pro');
        loadUsage(currentAccount.id);
        loadCampaigns(currentAccount.id);

        chrome.storage.local.get(['session'], function(data) {
          var greetingEl = document.getElementById('u-greeting');
          var avInitials = document.getElementById('user-av-initials');
          var username = (data.session && data.session.username) || '';
          var displayName = currentAccount.name || username;
          if (greetingEl) {
            greetingEl.textContent = 'Hi, ' + displayName + '!';
          }
          if (avInitials && displayName) {
            avInitials.textContent = displayName.substring(0, 2).toUpperCase();
          }
        });
      } else {
        document.getElementById('user-email').textContent = 'Gmail not connected';
        document.getElementById('acct-status').textContent = '';
        if (dot) dot.style.backgroundColor = '#cbd5e1'; // Grey
        showNotConnected();
      }
    })
    .catch(function(err) {
      if (err.message === 'Unauthorized') return;
      showBackendOffline();
    });
}

// ── Usage ──
function loadUsage(accountId){
  authFetch(API + '/auth/accounts/' + accountId + '/usage')
    .then(function(r){ return r.json(); })
    .then(function(d){
      var used  = d.weeklySends || d.todaySends || 0;
      var limit = d.weeklyLimit || d.dailyLimit || 50;
      document.getElementById('s-quota').textContent = used + '/' + limit;
    }).catch(function(){});
}

// ── Campaigns ──
function loadCampaigns(accountId){
  authFetch(API + '/campaigns?account_id=' + accountId)
    .then(function(r){
      if (r.status === 401 || r.status === 403) {
        localStorage.removeItem('sndr_session');
        chrome.storage.local.clear(function(){ checkSession(); });
        throw new Error('Unauthorized');
      }
      return r.json();
    })
    .then(function(camps){
      var body = document.getElementById('body');
      if (!camps || !camps.length) {
        body.innerHTML =
          '<div class="empty">' +
            '<span class="mi">rocket_launch</span>' +
            '<div class="empty-title">No campaigns yet</div>' +
            '<div class="empty-sub">Create your first campaign in the dashboard.</div>' +
            '<button class="btn-dash" id="btn-create-campaign-popup" style="margin-top:14px;">Create Campaign</button>' +
          '</div>';
        document.getElementById('btn-create-campaign-popup').addEventListener('click', openDashboard);
        return;
      }
      body.innerHTML = '<div class="sect-lbl">Campaigns</div>';
      var totalSent = 0, totalOpened = 0;
      var loaded = 0;
      camps.forEach(function(c){
        authFetch(API + '/campaigns/' + c.id + '/stats')
          .then(function(r){ return r.json(); })
          .then(function(s){
            totalSent   += Number(s.sent   || c.sent   || 0);
            totalOpened += Number(s.opened || c.opened || 0);
            loaded++;
            if (loaded === camps.length) {
              document.getElementById('s-sent').textContent   = totalSent.toLocaleString();
              document.getElementById('s-opened').textContent = totalOpened.toLocaleString();
            }
            renderCard(c, s);
          })
          .catch(function(){ renderCard(c, {}); });
      });
    })
    .catch(function(err){
      if (err.message === 'Unauthorized') return;
      showBackendOffline();
    });
}

function renderCard(c, s){
  var body   = document.getElementById('body');
  var total  = Number(s.total   || c.total   || 0);
  var sent   = Number(s.sent    || c.sent    || 0);
  var opened = Number(s.opened  || c.opened  || 0);
  var status = c.status  || 'draft';

  var badge = status === 'sent' || status === 'completed'
    ? '<span class="b-done">Completed</span>'
    : status === 'sending'
    ? '<span class="b-live"><span class="live-dot"></span>Live</span>'
    : '<span class="b-draft">Draft</span>';

  var card = document.createElement('div');
  card.className = 'camp-card';
  card.innerHTML =
    '<div class="camp-top">' +
      '<div class="camp-name">' + escHtml(c.name || 'Untitled') + '</div>' +
      badge +
    '</div>' +
    '<div class="camp-stats">' +
      '<div class="cs"><div class="cv">' + total + '</div><div class="cl">Total</div></div>' +
      '<div class="cs"><div class="cv' + (sent === 0 ? ' muted' : '') + '">' + sent + '</div><div class="cl">Sent</div></div>' +
      '<div class="cs"><div class="cv' + (opened === 0 ? ' muted' : '') + '">' + opened + '</div><div class="cl">Opened</div></div>' +
    '</div>';
  body.appendChild(card);
}

function showBackendOffline(){
  document.getElementById('body').innerHTML =
    '<div class="empty">' +
      '<span class="mi" style="color:#fca5a5">wifi_off</span>' +
      '<div class="empty-title">Backend offline</div>' +
      '<div class="empty-sub">Make sure the SNDR backend is running.</div>' +
    '</div>';
}

// ── Connect Gmail ──
function connectGmail() {
  authFetch(API + '/auth/url')
    .then(function(r) {
      if (!r.ok) throw new Error('Could not get auth URL');
      return r.json();
    })
    .then(function(data) {
      // Open OAuth tab and watch for it to close
      chrome.tabs.create({ url: data.url }, function(tab) {
        watchOAuthTab(tab.id);
      });
    })
    .catch(function(err) {
      alert('Error: ' + err.message + '\nMake sure the backend is running.');
    });
}

function watchOAuthTab(tabId) {
  // Poll for tab close or callback completion
  function onTabUpdated(id, changeInfo, tab) {
    if (id !== tabId) return;
    // Check if the tab URL contains the callback success page
    if (changeInfo.status === 'complete' && tab.url &&
        (tab.url.includes('/auth/callback') || tab.url.includes('localhost:3000/auth/callback'))) {
      // Wait a moment for backend to process, then reload accounts
      setTimeout(function() {
        chrome.tabs.remove(tabId, function() {});
        loadAccount();
        // Refresh the header email
        chrome.storage.local.get(['session'], function(data) {
          if (data.session && data.session.token) {
            authToken = data.session.token;
          }
        });
      }, 1500);
      chrome.tabs.onUpdated.removeListener(onTabUpdated);
      chrome.tabs.onRemoved.removeListener(onTabRemoved);
    }
  }

  function onTabRemoved(id) {
    if (id !== tabId) return;
    // Tab was closed by user — refresh accounts anyway
    setTimeout(function() { loadAccount(); }, 500);
    chrome.tabs.onUpdated.removeListener(onTabUpdated);
    chrome.tabs.onRemoved.removeListener(onTabRemoved);
  }

  chrome.tabs.onUpdated.addListener(onTabUpdated);
  chrome.tabs.onRemoved.addListener(onTabRemoved);
}

function showNotConnected(){
  document.getElementById('body').innerHTML =
    '<div class="empty">' +
      '<span class="mi">account_circle</span>' +
      '<div class="empty-title">No Gmail account</div>' +
      '<div class="empty-sub">Connect your Google account to start sending campaigns.</div>' +
      '<button class="btn-connect" id="btn-connect">Connect Gmail Account</button>' +
    '</div>';
  document.getElementById('btn-connect').addEventListener('click', connectGmail);
}

// Password visibility toggle
var btnTogglePasswordPopup = document.getElementById('btn-toggle-password-popup');
var authPasswordInput = document.getElementById('auth-password');
if (btnTogglePasswordPopup && authPasswordInput) {
  btnTogglePasswordPopup.addEventListener('click', function(e) {
    e.preventDefault();
    var isPass = authPasswordInput.type === 'password';
    authPasswordInput.type = isPass ? 'text' : 'password';
    var icon = btnTogglePasswordPopup.querySelector('.mi');
    if (icon) {
      icon.textContent = isPass ? 'visibility_off' : 'visibility';
    }
  });
}

// Start app
// Purge any legacy localStorage copy of the session token (now stored only in chrome.storage.local).
try { localStorage.removeItem('sndr_session'); } catch (e) {}
initApi().then(checkSession);
