// Same safe response.json() as dashboard-boot.js: a non-JSON body becomes a
// readable error naming the request, never "Unexpected token '<'".
(function () {
  if (typeof Response === 'undefined' || Response.prototype.__sndrSafeJson) return;
  Response.prototype.__sndrSafeJson = true;
  Response.prototype.json = function () {
    var res = this;
    return res.text().then(function (raw) {
      try { return JSON.parse(raw); }
      catch (e) {
        var where = '';
        try { where = new URL(res.url).pathname + ', '; } catch (_) {}
        throw new Error('The SNDR server sent an unexpected response (' + where + 'HTTP ' + res.status + '). Please try again in a moment.');
      }
    });
  };
})();

var API = 'https://api.sndr.co.in';
var authToken = null;
var currentAccount = null;

// HTML-escape dynamic (server/user) data before interpolating into innerHTML.
function escHtml(s){ return String(s==null?'':s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

async function initApi() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    await new Promise(function(resolve) {
      chrome.storage.local.get(['custom_api_url'], async function(data) {
        // Saved by a pre-AWS build: the retired Render host only serves an
        // HTML "Service Suspended" page now, so drop it and use the default.
        if (data.custom_api_url && data.custom_api_url.indexOf('onrender.com') !== -1) {
          chrome.storage.local.remove('custom_api_url');
        } else if (data.custom_api_url) {
          API = data.custom_api_url;
          console.log('[SNDR] Popup using API URL:', API);
        }
        resolve();
      });
    });
  }
}

var authMode = 'signup'; // 'signup' | 'login'

function updateAuthUI() {
  var authTitle     = document.getElementById('auth-title');
  var authSub       = document.getElementById('auth-sub');
  var authSubmitBtn = document.getElementById('btn-auth-submit');
  var authToggleBtn = document.getElementById('btn-auth-toggle');
  var authToggleMsg = document.getElementById('auth-toggle-msg');
  var groupEmail    = document.getElementById('group-email');
  var authUsername  = document.getElementById('auth-username');
  var authEmailEl   = document.getElementById('auth-email');
  var btnForgotPopup = document.getElementById('btn-forgot-password-popup');

  var usernameText = document.getElementById('lbl-username-text');
  var usernameRequired = document.getElementById('lbl-username-required');
  var usernameHelp = document.getElementById('lbl-username-help');
  var passwordRequired = document.getElementById('lbl-password-required');
  var passwordHelp = document.getElementById('lbl-password-help');
  var emailRequired = document.getElementById('lbl-email-required');

  if (authMode === 'signup') {
    if (authTitle) authTitle.textContent = 'Create your account';
    if (authSub) authSub.textContent = 'Sign up to manage your campaigns';
    if (authSubmitBtn) authSubmitBtn.textContent = 'Sign Up';
    if (authToggleMsg) authToggleMsg.textContent = 'Already have an account?';
    if (authToggleBtn) authToggleBtn.textContent = 'Log in';
    if (groupEmail) groupEmail.style.display = 'flex';
    if (authEmailEl) authEmailEl.required = true;
    if (btnForgotPopup) btnForgotPopup.style.display = 'none';

    if (usernameText) usernameText.textContent = 'Username';
    if (usernameRequired) usernameRequired.style.display = '';
    if (usernameHelp) usernameHelp.style.display = '';
    if (passwordRequired) passwordRequired.style.display = '';
    if (passwordHelp) passwordHelp.style.display = '';
    if (emailRequired) emailRequired.style.display = '';
    if (authUsername) authUsername.placeholder = 'e.g. johndoe';
  } else {
    if (authTitle) authTitle.textContent = 'Log in to your account';
    if (authSub) authSub.textContent = 'Log in to your SNDR account';
    if (authSubmitBtn) authSubmitBtn.textContent = 'Log In';
    if (authToggleMsg) authToggleMsg.textContent = "Don't have an account?";
    if (authToggleBtn) authToggleBtn.textContent = 'Sign up';
    if (groupEmail) groupEmail.style.display = 'none';
    if (authEmailEl) authEmailEl.required = false;
    if (btnForgotPopup) btnForgotPopup.style.display = 'inline-block';

    if (usernameText) usernameText.textContent = 'Username or Email';
    if (usernameRequired) usernameRequired.style.display = '';
    if (usernameHelp) usernameHelp.style.display = 'none';
    if (passwordRequired) passwordRequired.style.display = '';
    if (passwordHelp) passwordHelp.style.display = 'none';
    if (emailRequired) emailRequired.style.display = 'none';
    if (authUsername) authUsername.placeholder = 'e.g. johndoe or john@company.com';
  }
}

function authFetch(url, options) {
  options = options || {};
  options.headers = options.headers || {};
  if (authToken) {
    options.headers['Authorization'] = 'Bearer ' + authToken;
  }
  return fetch(url, options);
}

function openDashboard(){
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
}

document.getElementById('btn-dash').addEventListener('click', openDashboard);

document.getElementById('btn-signout').addEventListener('click', async function(){
  try {
    await authFetch(API + '/auth/logout', { method: 'POST' }).catch(function(){});
  } catch(e) {}
  localStorage.removeItem('sndr_session');
  chrome.storage.local.clear(function(){
    authToken = null;
    checkSession();
  });
});

// ── Session & Auth UI ──

var authContainer = document.getElementById('auth-container');
var mainHdr       = document.getElementById('main-hdr');
var bodyContainer = document.getElementById('body');
var mainFooter    = document.getElementById('main-footer');

var authForm      = document.getElementById('auth-form');
var authTitle     = document.getElementById('auth-title');
var authError     = document.getElementById('auth-error');
var authUsername  = document.getElementById('auth-username');
var authEmailEl   = document.getElementById('auth-email');
var authPassword  = document.getElementById('auth-password');
var authSubmitBtn = document.getElementById('btn-auth-submit');
var authToggleBtn = document.getElementById('btn-auth-toggle');
var authToggleMsg = document.getElementById('auth-toggle-msg');
var groupEmail    = document.getElementById('group-email');
var lblUsername   = document.getElementById('lbl-username');
var btnForgotPopup= document.getElementById('btn-forgot-password-popup');

authToggleBtn.addEventListener('click', function() {
  authMode = (authMode === 'login') ? 'signup' : 'login';
  updateAuthUI();
  authError.style.display = 'none';
});

if (btnForgotPopup) {
  btnForgotPopup.addEventListener('click', function(e) {
    e.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html?view=forgot') });
  });
}

authForm.addEventListener('submit', function(e) {
  e.preventDefault();
  var username = authUsername ? authUsername.value.trim() : '';
  var password = authPassword.value;
  var email = authEmailEl ? authEmailEl.value.trim() : '';

  if (authMode === 'login') {
    if (!username || !password) {
      showAuthError('Username/Email and password required');
      return;
    }
  } else {
    if (!username || !email || !password) {
      showAuthError('Username, Email, and password required');
      return;
    }
  }

  authError.style.display = 'none';
  authSubmitBtn.disabled = true;
  authSubmitBtn.textContent = 'Please wait...';

  var endpoint = authMode === 'login' ? '/auth/login' : '/auth/signup';
  var payload = authMode === 'login'
    ? { username: username, password: password }
    : { username: username, email: email, password: password };

  fetch(API + endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  .then(function(r) {
    // The server may be asleep (Render free-tier spin-down) or restarting, in
    // which case it returns an HTML error page, not JSON. Parsing that as JSON
    // threw "Unexpected token '<'", which surfaced as a scary login error.
    // Detect a non-JSON body and show something actionable instead.
    return r.text().then(function(raw) {
      var d;
      try { d = JSON.parse(raw); }
      catch (e) {
        throw new Error('The SNDR server is waking up or briefly unavailable. Please wait a few seconds and try again.');
      }
      if (!r.ok) throw new Error(d.error || 'Authentication failed');
      return d;
    });
  })
  .then(function(sessionData) {
    // Token persists only in chrome.storage.local (source of truth); no localStorage copy.
    chrome.storage.local.set({ session: sessionData }, function() {
      authToken = sessionData.token;
      checkSession();
    });
  })
  .catch(function(err) {
    showAuthError(err.message);
  })
  .finally(function() {
    authSubmitBtn.disabled = false;
    authSubmitBtn.textContent = authMode === 'login' ? 'Log In' : 'Sign Up';
  });
});

function showAuthError(msg) {
  authError.textContent = msg;
  authError.style.display = 'block';
}

function checkSession() {
  chrome.storage.local.get(['session'], function(data) {
    if (data.session && data.session.token) {
      authToken = data.session.token;
      authContainer.style.display = 'none';
      mainHdr.style.display = 'block';
      bodyContainer.style.display = 'block';
      mainFooter.style.display = 'flex';

      // Set greeting + avatar initials
      var greetingEl = document.getElementById('u-greeting');
      var avInitials = document.getElementById('user-av-initials');
      if (greetingEl && data.session.username) {
        greetingEl.textContent = 'Hi, ' + data.session.username + '!';
      }
      if (avInitials && data.session.username) {
        avInitials.textContent = data.session.username.substring(0, 2).toUpperCase();
      }

      // Load account details
      loadAccount();
    } else {
      authToken = null;
      mainHdr.style.display = 'none';
      bodyContainer.style.display = 'none';
      mainFooter.style.display = 'none';
      authContainer.style.display = 'flex';
      updateAuthUI();
    }
  });
}

// ── Load account ──
function loadAccount(){
  authFetch(API + '/auth/accounts')
    .then(function(r) {
      // Only a 401 means the session is dead; 403 is a permission error.
      if (r.status === 401) {
        localStorage.removeItem('sndr_session');
        chrome.storage.local.clear(function(){
          authToken = null;
          checkSession();
        });
        throw new Error('Unauthorized');
      }
      return r.json();
    })
    .then(function(accounts) {
      var dot = document.getElementById('acct-dot');
      if (accounts.length > 0) {
        currentAccount = accounts[0];
        // `connected` is absent on older backends — treat missing as connected.
        var isConn = currentAccount.connected === undefined || currentAccount.connected === null
          ? true : (currentAccount.connected === true || Number(currentAccount.connected) === 1);
        document.getElementById('user-email').textContent = currentAccount.email;
        document.getElementById('acct-status').textContent = isConn ? '· Connected' : '· Disconnected';
        if (dot) dot.style.backgroundColor = isConn ? '#22c55e' : '#f59e0b'; // green / amber
        var isPro = currentAccount.plan === 'pro';
        var badge = document.getElementById('plan-badge');
        badge.textContent = isPro ? 'PRO' : 'FREE';
        if (isPro) badge.classList.add('pro'); else badge.classList.remove('pro');
        loadUsage(currentAccount.id);
        loadCampaigns(currentAccount.id);

        chrome.storage.local.get(['session'], function(data) {
          var greetingEl = document.getElementById('u-greeting');
          var avInitials = document.getElementById('user-av-initials');
          var username = (data.session && data.session.username) || '';
          var displayName = currentAccount.name || username;
          if (greetingEl) {
            greetingEl.textContent = 'Hi, ' + displayName + '!';
          }
          if (avInitials && displayName) {
            avInitials.textContent = displayName.substring(0, 2).toUpperCase();
          }
        });
      } else {
        document.getElementById('user-email').textContent = 'Gmail not connected';
        document.getElementById('acct-status').textContent = '';
        if (dot) dot.style.backgroundColor = '#cbd5e1'; // Grey
        showNotConnected();
      }
    })
    .catch(function(err) {
      if (err.message === 'Unauthorized') return;
      showBackendOffline();
    });
}

// ── Usage ──
function loadUsage(accountId){
  authFetch(API + '/auth/accounts/' + accountId + '/usage')
    .then(function(r){ return r.json(); })
    .then(function(d){
      var used  = d.weeklySends || d.todaySends || 0;
      var limit = d.weeklyLimit || d.dailyLimit || 50;
      document.getElementById('s-quota').textContent = used + '/' + limit;
    }).catch(function(){});
}

// ── Campaigns ──
function loadCampaigns(accountId){
  authFetch(API + '/campaigns?account_id=' + accountId)
    .then(function(r){
      if (r.status === 401) {
        localStorage.removeItem('sndr_session');
        chrome.storage.local.clear(function(){ checkSession(); });
        throw new Error('Unauthorized');
      }
      return r.json();
    })
    .then(function(camps){
      var body = document.getElementById('body');
      if (!camps || !camps.length) {
        body.innerHTML =
          '<div class="empty">' +
            '<span class="mi">rocket_launch</span>' +
            '<div class="empty-title">No campaigns yet</div>' +
            '<div class="empty-sub">Create your first campaign in the dashboard.</div>' +
            '<button class="btn-dash" id="btn-create-campaign-popup" style="margin-top:14px;">Create Campaign</button>' +
          '</div>';
        document.getElementById('btn-create-campaign-popup').addEventListener('click', openDashboard);
        return;
      }
      body.innerHTML = '<div class="sect-lbl">Campaigns</div>';
      // The /campaigns list already includes per-campaign stats — the old code
      // fired one extra /stats request per campaign and appended cards in
      // whichever order the responses landed (random order, N wasted requests).
      var totalSent = 0, totalOpened = 0;
      camps.forEach(function(c){
        var s = c.stats || {};
        totalSent   += Number(s.sent   || 0);
        totalOpened += Number(s.opened || 0);
        renderCard(c, s);
      });
      document.getElementById('s-sent').textContent   = totalSent.toLocaleString();
      document.getElementById('s-opened').textContent = totalOpened.toLocaleString();
    })
    .catch(function(err){
      if (err.message === 'Unauthorized') return;
      showBackendOffline();
    });
}

function renderCard(c, s){
  var body   = document.getElementById('body');
  var total  = Number(s.total   || c.total   || 0);
  var sent   = Number(s.sent    || c.sent    || 0);
  var opened = Number(s.opened  || c.opened  || 0);
  var failed = Number(s.failed  || 0);
  var status = c.status  || 'draft';

  var st = status === 'sending' ? ['green', 'Sending']
    : status === 'scheduled' ? ['indigo', 'Scheduled']
    : status === 'paused' ? ['amber', c.paused_reason === 'daily_limit' ? 'Continues tomorrow' : 'Paused']
    : status === 'draft' ? ['', 'Draft']
    : failed > 0 ? ['red', failed + ' failed']
    : ['', 'Done'];
  var pct = total > 0 ? Math.min(100, Math.round(sent / total * 100)) : 0;

  // A card opens this campaign's own page in the dashboard.
  var card = document.createElement('button');
  card.type = 'button';
  card.className = 'camp-card';
  card.innerHTML =
    '<div class="camp-top">' +
      '<div class="camp-name">' + escHtml(c.name || 'Untitled') + '</div>' +
      '<span class="pc-st' + (st[0] === 'red' ? ' red' : '') + '"><span class="pc-dot ' + st[0] + '"></span>' + escHtml(st[1]) + '</span>' +
    '</div>' +
    '<div class="pc-bar"><span style="width:' + pct + '%;' + (status === 'sent' ? 'background:#94a3b8' : '') + '"></span></div>' +
    '<div class="pc-meta"><span>' + sent + ' of ' + total + ' sent</span><span>' + (sent ? Math.round(opened / sent * 100) : 0) + '% opened</span></div>';
  card.addEventListener('click', function() {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') + '#nav=campaign&campaign=' + encodeURIComponent(c.id) });
  });
  body.appendChild(card);
}

function showBackendOffline(){
  document.getElementById('body').innerHTML =
    '<div class="empty">' +
      '<span class="mi" style="color:#fca5a5">wifi_off</span>' +
      '<div class="empty-title">Backend offline</div>' +
      '<div class="empty-sub">Make sure the SNDR backend is running.</div>' +
    '</div>';
}

// ── Connect Gmail ──
function connectGmail() {
  authFetch(API + '/auth/url')
    .then(function(r) {
      if (!r.ok) throw new Error('Could not get auth URL');
      return r.json();
    })
    .then(function(data) {
      // Open OAuth tab and watch for it to close
      chrome.tabs.create({ url: data.url }, function(tab) {
        watchOAuthTab(tab.id);
      });
    })
    .catch(function(err) {
      alert('Error: ' + err.message + '\nMake sure the backend is running.');
    });
}

function watchOAuthTab(tabId) {
  // Poll for tab close or callback completion
  function onTabUpdated(id, changeInfo, tab) {
    if (id !== tabId) return;
    // Check if the tab URL contains the callback success page
    if (changeInfo.status === 'complete' && tab.url &&
        (tab.url.includes('/auth/callback') || tab.url.includes('localhost:3000/auth/callback'))) {
      // Wait a moment for backend to process, then reload accounts
      setTimeout(function() {
        chrome.tabs.remove(tabId, function() {});
        loadAccount();
        // Refresh the header email
        chrome.storage.local.get(['session'], function(data) {
          if (data.session && data.session.token) {
            authToken = data.session.token;
          }
        });
      }, 1500);
      chrome.tabs.onUpdated.removeListener(onTabUpdated);
      chrome.tabs.onRemoved.removeListener(onTabRemoved);
    }
  }

  function onTabRemoved(id) {
    if (id !== tabId) return;
    // Tab was closed by user — refresh accounts anyway
    setTimeout(function() { loadAccount(); }, 500);
    chrome.tabs.onUpdated.removeListener(onTabUpdated);
    chrome.tabs.onRemoved.removeListener(onTabRemoved);
  }

  chrome.tabs.onUpdated.addListener(onTabUpdated);
  chrome.tabs.onRemoved.addListener(onTabRemoved);
}

function showNotConnected(){
  document.getElementById('body').innerHTML =
    '<div class="empty">' +
      '<span class="mi">account_circle</span>' +
      '<div class="empty-title">No Gmail account</div>' +
      '<div class="empty-sub">Connect your Google account to start sending campaigns.</div>' +
      '<button class="btn-connect" id="btn-connect"><svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">' +
        '<path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>' +
        '<path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>' +
        '<path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>' +
        '<path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>' +
        '</svg>Continue with Google</button>' +
    '</div>';
  document.getElementById('btn-connect').addEventListener('click', connectGmail);
}

// Password visibility toggle
var btnTogglePasswordPopup = document.getElementById('btn-toggle-password-popup');
var authPasswordInput = document.getElementById('auth-password');
if (btnTogglePasswordPopup && authPasswordInput) {
  btnTogglePasswordPopup.addEventListener('click', function(e) {
    e.preventDefault();
    var isPass = authPasswordInput.type === 'password';
    authPasswordInput.type = isPass ? 'text' : 'password';
    var icon = btnTogglePasswordPopup.querySelector('.mi');
    if (icon) {
      icon.textContent = isPass ? 'visibility_off' : 'visibility';
    }
  });
}

// Start app
// Purge any legacy localStorage copy of the session token (now stored only in chrome.storage.local).
try { localStorage.removeItem('sndr_session'); } catch (e) {}
initApi().then(checkSession);
