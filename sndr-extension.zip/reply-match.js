// Spots replies and bounces to SNDR emails among the rows of the user's Gmail
// inbox, shared by the Gmail content script (src/content/gmail.js) and tests.
// SNDR doesn't read the inbox through Google: the extension looks at the
// Gmail page the user has open and reports only rows from people SNDR is
// waiting to hear from.
//
// rows:  [{ threadId, senders: [email], snippet, time (ms or null) }]
// watch: { self: the Gmail address, contacts: [{ id, email, threadId, sentAt (s), copied: [email] }] }
// ->     [{ contactId, kind: 'reply' | 'bounce', snippet, at (s or null), how: 'thread' | 'sender' }]
(function (root) {
  var DAEMON = /^(mailer-daemon|postmaster)@/i;

  function lc(s) { return String(s || '').trim().toLowerCase(); }

  // Gmail shows a message's full date in the date cell's title, e.g.
  // "Tue, Oct 27, 2026, 10:32 AM" or "27 Oct 2026, 10:32". Null if unreadable
  // (another UI language): then only same-thread matches count.
  function parseGmailDate(title) {
    if (!title) return null;
    var t = String(title).replace(/ | /g, ' ').replace(/^[A-Za-z]{3},\s*/, '').replace(/,(\s*\d{1,2}:\d{2})/, '$1');
    var ms = Date.parse(t);
    if (isNaN(ms)) ms = Date.parse(title);
    return isNaN(ms) ? null : ms;
  }

  // Gmail's thread ids: data-legacy-thread-id is the API's hex id; the newer
  // data-thread-id is "#thread-f:<decimal>" — the same number.
  function threadHex(legacy, modern) {
    if (legacy && /^[0-9a-f]{8,}$/i.test(legacy)) return lc(legacy);
    var m = /thread-f:(\d+)/.exec(modern || '');
    if (m && typeof BigInt === 'function') { try { return BigInt(m[1]).toString(16); } catch (e) {} }
    return null;
  }

  function match(rows, watch) {
    var self = lc(watch && watch.self);
    var contacts = (watch && watch.contacts) || [];
    var byThread = {}, byEmail = {};
    contacts.forEach(function (c) {
      if (c.threadId) byThread[lc(c.threadId)] = c;
      var e = lc(c.email);
      (byEmail[e] = byEmail[e] || []).push(c);
    });
    // The contact a message from `email` at `sec` answers: the latest one
    // emailed before it.
    function latestBefore(list, sec) {
      var best = null;
      (list || []).forEach(function (c) {
        if (sec != null && Number(c.sentAt) > sec + 60) return;
        if (!best || Number(c.sentAt) > Number(best.sentAt)) best = c;
      });
      return best;
    }

    var found = {};
    function add(c, kind, row, sec, how) {
      var prev = found[c.id];
      if (prev && (prev.kind === 'bounce' || kind === 'reply')) return; // a bounce outranks a reply
      found[c.id] = { contactId: c.id, kind: kind, snippet: String(row.snippet || '').trim().slice(0, 300), at: sec, how: how };
    }

    (rows || []).forEach(function (row) {
      var senders = (row.senders || []).map(lc).filter(Boolean);
      var others = senders.filter(function (e) { return e !== self; });
      if (!others.length) return; // only the user's own messages: nothing new
      var sec = row.time ? Math.floor(row.time / 1000) : null;
      var daemon = others.some(function (e) { return DAEMON.test(e); });
      var c = row.threadId && byThread[lc(row.threadId)];

      if (c) {
        // A thread SNDR started. Anyone but the user, the campaign's Cc/Bcc
        // and the mail system counts as a reply.
        if (daemon) return add(c, 'bounce', row, sec, 'thread');
        var copied = (c.copied || []).map(lc);
        if (others.some(function (e) { return copied.indexOf(e) === -1; })) add(c, 'reply', row, sec, 'thread');
        return;
      }
      if (daemon) {
        // A bounce in another thread names the address it couldn't reach.
        var text = lc(row.snippet);
        Object.keys(byEmail).forEach(function (e) {
          if (text.indexOf(e) === -1) return;
          var b = latestBefore(byEmail[e], sec);
          if (b) add(b, 'bounce', row, sec, 'sender');
        });
        return;
      }
      // The person wrote back in a new thread. Needs a readable date after the
      // send, so an old email from them doesn't count as a reply.
      if (sec == null) return;
      others.forEach(function (e) {
        var r = latestBefore(byEmail[e], sec);
        if (r && sec >= Number(r.sentAt)) add(r, 'reply', row, sec, 'sender');
      });
    });
    return Object.keys(found).map(function (k) { return found[k]; });
  }

  var api = { match: match, parseGmailDate: parseGmailDate, threadHex: threadHex };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.sndrReplyMatch = api;
})(typeof window !== 'undefined' ? window : this);
