// The SNDR tutorial video, played in the dashboard: sidebar → Tutorial, and
// the button on the empty Find Emails screen ([data-tutorial]). The video is
// hosted on the website (landing/tutorial.mp4) so the extension download
// stays small; the subtitles are part of the picture.
(function () {
  var SRC = 'https://www.sndr.co.in/tutorial.mp4';
  var POSTER = 'https://www.sndr.co.in/tutorial-poster.jpg';

  function open() {
    if (document.getElementById('tut-bg')) return;
    var bg = document.createElement('div');
    bg.id = 'tut-bg';
    bg.className = 'fc-confirm-bg tut-bg';
    bg.innerHTML =
      '<div class="tut-card" role="dialog" aria-modal="true" aria-label="How to use SNDR">' +
        '<div class="tut-top"><span class="tut-title"><span class="mi" aria-hidden="true">smart_display</span>How to use SNDR</span>' +
          '<span class="tut-len">4 min</span>' +
          '<button type="button" class="tut-x" aria-label="Close"><span class="mi" aria-hidden="true">close</span></button></div>' +
        '<video class="tut-video" controls autoplay playsinline preload="metadata" poster="' + POSTER + '" src="' + SRC + '"></video>' +
        '<div class="tut-err" role="alert" hidden>The video couldn\'t load. Check your connection, or ' +
          '<a href="' + SRC + '" target="_blank" rel="noopener">open it in a new tab</a>.</div>' +
      '</div>';
    document.body.appendChild(bg);
    var video = bg.querySelector('video');
    function close() {
      try { video.pause(); } catch (e) {}
      bg.remove();
      document.removeEventListener('keydown', onKey, true);
    }
    function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }
    document.addEventListener('keydown', onKey, true);
    bg.addEventListener('mousedown', function (e) { if (e.target === bg) close(); });
    bg.querySelector('.tut-x').addEventListener('click', close);
    video.addEventListener('error', function () { bg.querySelector('.tut-err').hidden = false; });
    if (typeof window.sndrTrack === 'function') window.sndrTrack('tutorial_opened', {});
    video.focus();
  }
  window.sndrOpenTutorial = open;

  document.addEventListener('click', function (e) {
    var t = e.target.closest && e.target.closest('#nav-tutorial, [data-tutorial]');
    if (t) { e.preventDefault(); open(); }
  });
})();
