// Usage reporting for the founders' analytics (signed-in users only). Loaded
// by the dashboard before dashboard.js. Events go through the background
// worker, which batches them to POST /auth/events with the user's session;
// only the event types the server accepts are ever sent, and never any
// email content. See backend/services/events.js.
(function () {
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
    window.sndrTrack = function () {};
    return;
  }
  function send(msg) { try { chrome.runtime.sendMessage(msg, function () { void chrome.runtime.lastError; }); } catch (e) {} }

  var page = 'dashboard';
  window.sndrTrack = function (type, detail) { send({ type: 'TRACK', event: { type: type, detail: detail || {}, ts: Math.floor(Date.now() / 1000) } }); };
  // The screen the user is on, for "online now" (called by goNav).
  window.sndrSetScreen = function (screen) {
    page = 'dashboard:' + screen;
    send({ type: 'PRESENCE', page: page });
    window.sndrTrack('view', { screen: screen });
  };

  // "Still here" once a minute while the dashboard is visible.
  setInterval(function () { if (document.visibilityState === 'visible') send({ type: 'PRESENCE', page: page }); }, 60000);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') send({ type: 'PRESENCE', page: page }); });

  window.sndrTrack('dashboard_open');

  // AI chat and CV analysis are called from several places (dashboard.js,
  // bot.js); noting them here covers all of them. At most once per 10s each.
  var lastAi = {};
  var FEATURES = [[/\/api\/ai\/cv-chat\b/, 'cv_chat'], [/\/api\/ai\/chat\b/, 'ai_chat'], [/\/api\/ai\/analyse-cv\b/, 'cv_analysis']];
  var origFetch = window.fetch;
  window.fetch = function (input) {
    try {
      var url = typeof input === 'string' ? input : (input && input.url) || '';
      if (/\/api\/cv\/upload\b/.test(url)) window.sndrTrack('cv_uploaded');
      for (var i = 0; i < FEATURES.length; i++) {
        if (FEATURES[i][0].test(url)) {
          var f = FEATURES[i][1], now = Date.now();
          if (!lastAi[f] || now - lastAi[f] > 10000) { lastAi[f] = now; window.sndrTrack('ai_used', { feature: f }); }
          break;
        }
      }
    } catch (e) {}
    return origFetch.apply(this, arguments);
  };
})();
